####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import os
import shutil
import time
import random
from flowork_kernel.api_contract import BaseModule
from tkinter import ttk, StringVar, BooleanVar, filedialog
from flowork_kernel.ui_shell import shared_properties

class CopyFileModule(BaseModule):
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)
        self.logger("Modul 'Salin File' berhasil diinisialisasi.", "INFO")

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        copy_mode = config.get('copy_mode', 'file')
        source_path = config.get('source_path')
        destination_path = config.get('destination_path')

        if not source_path or not destination_path:
            raise ValueError("Path sumber dan tujuan tidak boleh kosong.")

        try:
            if copy_mode == 'file':
                overwrite = config.get('overwrite', False)
                if not os.path.isfile(source_path):
                    raise FileNotFoundError(f"File sumber tidak ditemukan atau bukan file: {source_path}")

                if os.path.isdir(destination_path):
                    final_destination = os.path.join(destination_path, os.path.basename(source_path))
                else:
                    final_destination = destination_path

                if mode == 'SIMULATE':
                    status_updater(f"Simulasi: Salin '{source_path}' ke '{final_destination}'", "WARN")
                    payload['destination_path'] = final_destination
                    return payload

                if os.path.exists(final_destination) and not overwrite:
                    raise FileExistsError(f"File tujuan sudah ada dan opsi 'timpa' tidak aktif: {final_destination}")

                os.makedirs(os.path.dirname(final_destination), exist_ok=True)
                shutil.copy2(source_path, final_destination)
                status_updater("Salin File Selesai", "SUCCESS")
                self.logger(f"File berhasil disalin ke: {final_destination}", "SUCCESS")
                payload['destination_path'] = final_destination

            elif copy_mode == 'folder':
                use_history = config.get('use_history', True)
                node_id = config.get('__internal_node_id')

                if not os.path.isdir(source_path):
                    raise NotADirectoryError(f"Path Sumber harus berupa folder untuk mode ini: {source_path}")

                if use_history:
                    history_key = f"copy_history_{node_id}"
                    previous_history = self.kernel.state.get(history_key, {})
                    new_history = {"files": {}}
                    files_copied_count = 0
                    is_full_copy = not previous_history.get('files')

                    if is_full_copy: self.logger(f"Memulai Salin Penuh dari '{source_path}'.", "INFO")
                    else: self.logger(f"Memulai Salin Inkremental dari '{source_path}'.", "INFO")

                    for dirpath, _, filenames in os.walk(source_path):
                        for filename in filenames:
                            source_file_path = os.path.join(dirpath, filename)
                            relative_path = os.path.relpath(source_file_path, source_path)
                            destination_file_path = os.path.join(destination_path, relative_path)
                            current_mtime = os.path.getmtime(source_file_path)
                            new_history["files"][relative_path] = current_mtime

                            copy_this_file = False
                            if is_full_copy: copy_this_file = True
                            else:
                                if relative_path not in previous_history["files"]: copy_this_file = True
                                elif current_mtime > previous_history["files"][relative_path]: copy_this_file = True

                            if copy_this_file:
                                if mode == 'SIMULATE':
                                    status_updater(f"Simulasi: Salin '{relative_path}'", "WARN")
                                else:
                                    status_updater(f"Menyalin: {relative_path}", "INFO")
                                    os.makedirs(os.path.dirname(destination_file_path), exist_ok=True)
                                    shutil.copy2(source_file_path, destination_file_path)
                                files_copied_count += 1

                    if mode == 'EXECUTE': self.kernel.state.set(history_key, new_history)
                    status_updater(f"Selesai: {files_copied_count} file disalin.", "SUCCESS")

                else:
                    if mode == 'SIMULATE':
                        status_updater(f"Simulasi: Salin isi '{source_path}' ke '{destination_path}'", "WARN")
                    else:
                        shutil.copytree(source_path, destination_path, dirs_exist_ok=True)
                        status_updater("Salin Folder Selesai (Timpa Semua)", "SUCCESS")

                payload['destination_path'] = destination_path

        except Exception as e:
            self.logger(f"Gagal dalam operasi penyalinan: {e}", "ERROR")
            status_updater(f"Error: {e}", "ERROR")
            raise e

        return payload

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        config = get_current_config()
        created_vars = {}

        settings_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_copy_title'))
        settings_frame.pack(fill="x", padx=5, pady=(5,0))

        mode_frame = ttk.Frame(settings_frame)
        mode_frame.pack(fill='x', padx=10, pady=5)
        ttk.Label(mode_frame, text=self.loc.get('copy_mode_label')).pack(side='left', padx=(0,10))
        copy_mode_var = StringVar(value=config.get('copy_mode', 'file'))
        created_vars['copy_mode'] = copy_mode_var

        source_frame = ttk.Frame(settings_frame)
        source_frame.pack(fill='x', padx=10, pady=(5,0))
        source_label = ttk.Label(source_frame)
        source_label.pack(fill='x', anchor='w')
        source_entry_frame = ttk.Frame(source_frame)
        source_entry_frame.pack(fill='x', expand=True, pady=(2,10))
        source_path_var = StringVar(value=config.get('source_path', ''))
        ttk.Entry(source_entry_frame, textvariable=source_path_var).pack(side='left', fill='x', expand=True)
        created_vars['source_path'] = source_path_var
        browse_button = ttk.Button(source_entry_frame, style="secondary.TButton")
        browse_button.pack(side='left', padx=(5,0))

        options_frame = ttk.Frame(settings_frame, padding=(10,0))
        options_frame.pack(fill='x')
        created_vars['overwrite'] = BooleanVar(value=config.get('overwrite', False))
        overwrite_check = ttk.Checkbutton(options_frame, text=self.loc.get('overwrite_label'), variable=created_vars['overwrite'])
        created_vars['use_history'] = BooleanVar(value=config.get('use_history', True))
        history_check = ttk.Checkbutton(options_frame, text=self.loc.get('use_history_label'), variable=created_vars['use_history'])

        def _update_ui_based_on_mode():
            if copy_mode_var.get() == 'file':
                source_label.config(text=self.loc.get('source_path_file_label'))
                browse_button.config(text=self.loc.get('browse_file_button'), command=lambda: source_path_var.set(filedialog.askopenfilename(title=self.loc.get('browse_file_title')) or source_path_var.get()))
                history_check.pack_forget()
                overwrite_check.pack(anchor='w')
            else: # mode folder
                source_label.config(text=self.loc.get('source_path_folder_label'))
                browse_button.config(text=self.loc.get('browse_folder_button'), command=lambda: source_path_var.set(filedialog.askdirectory(title=self.loc.get('browse_folder_title')) or source_path_var.get()))
                overwrite_check.pack_forget()
                history_check.pack(anchor='w')

        ttk.Radiobutton(mode_frame, text=self.loc.get('copy_mode_file'), variable=copy_mode_var, value='file', command=_update_ui_based_on_mode).pack(side='left', padx=5)
        ttk.Radiobutton(mode_frame, text=self.loc.get('copy_mode_folder'), variable=copy_mode_var, value='folder', command=_update_ui_based_on_mode).pack(side='left', padx=5)

        dest_frame = ttk.Frame(settings_frame)
        dest_frame.pack(fill='x', padx=10, pady=(5,0))
        ttk.Label(dest_frame, text=self.loc.get('destination_path_label')).pack(fill='x', anchor='w')
        dest_entry_frame = ttk.Frame(dest_frame)
        dest_entry_frame.pack(fill='x', expand=True, pady=(2,10))
        destination_path_var = StringVar(value=config.get('destination_path', ''))
        ttk.Entry(dest_entry_frame, textvariable=destination_path_var).pack(side='left', fill='x', expand=True)
        created_vars['destination_path'] = destination_path_var
        ttk.Button(dest_entry_frame, text=self.loc.get('browse_folder_button'), style="secondary.TButton", command=lambda: destination_path_var.set(filedialog.askdirectory(title=self.loc.get('browse_folder_title_dest')) or destination_path_var.get())).pack(side='left', padx=(5,0))

        _update_ui_based_on_mode()

        ttk.Separator(parent_frame).pack(fill='x', pady=5)
        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, config, self.loc)
        created_vars.update(debug_vars)

        return created_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################