####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
from flowork_kernel.api_contract import BaseModule
from flowork_kernel.ui_shell.shared_properties import create_debug_and_reliability_ui
import ttkbootstrap as ttk
from tkinter import StringVar

class Processor(BaseModule):
    """
    Processor untuk modul Custom Variable.
    Menambahkan key-value pair yang ditentukan pengguna ke dalam payload.
    """
    TIER = "free"

    def __init__(self, module_id: str, services: dict):
        super().__init__(module_id, services)
        self.logger = services.get("logger")
        self.loc = services.get("loc")

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        if not isinstance(payload, dict):
            self.logger(f"Payload bukan dictionary, modul '{self.manifest.get('name')}' tidak dapat menambahkan variabel. Melewati.", "WARN")
            return {"payload": payload, "output_name": "output"}

        var_name = config.get('variable_name', '').strip()
        var_value = config.get('variable_value', '')

        if var_name:
            payload[var_name] = var_value
            status_updater(f"Menambahkan: {var_name}", "SUCCESS")
            self.logger(self.loc.get('log_custom_variable_added', var_name=var_name, var_value=var_value), "INFO")
        else:
            status_updater("Nama variabel kosong", "WARN")
            self.logger(self.loc.get('log_custom_variable_name_empty'), "WARN")

        return {"payload": payload, "output_name": "output"}

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        config = get_current_config()
        created_vars = {}

        main_props_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_custom_variable_title'))
        main_props_frame.pack(fill='x', padx=5, pady=(5, 10), expand=True)

        name_frame = ttk.Frame(main_props_frame)
        name_frame.pack(fill='x', padx=10, pady=(5, 5))
        ttk.Label(name_frame, text=self.loc.get('prop_custom_variable_name_label', fallback="Nama Variabel (Key):")).pack(anchor='w')
        created_vars['variable_name'] = ttk.StringVar(value=config.get('variable_name', ''))
        ttk.Entry(name_frame, textvariable=created_vars['variable_name']).pack(fill='x', expand=True)

        value_frame = ttk.Frame(main_props_frame)
        value_frame.pack(fill='x', padx=10, pady=(5, 10))
        ttk.Label(value_frame, text=self.loc.get('prop_custom_variable_value_label', fallback="Isi Variabel (Value):")).pack(anchor='w')
        created_vars['variable_value'] = ttk.StringVar(value=config.get('variable_value', ''))
        ttk.Entry(value_frame, textvariable=created_vars['variable_value']).pack(fill='x', expand=True)

        debug_vars = create_debug_and_reliability_ui(parent_frame, config, self.loc)
        created_vars.update(debug_vars)

        return created_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################