####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
from flowork_kernel.api_contract import BaseModule
import json
import ttkbootstrap as ttk
from tkinter import scrolledtext
from flowork_kernel.ui_shell import shared_properties

class DebugPopupModule(BaseModule):
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)

    def _show_popup_on_ui_thread(self, title, data_string):
        popup = ttk.Toplevel(title=title)
        popup.geometry("600x400")
        txt_area = scrolledtext.ScrolledText(popup, wrap="word", width=70, height=20)
        txt_area.pack(expand=True, fill="both", padx=10, pady=10)
        txt_area.insert("1.0", data_string)
        txt_area.config(state="disabled")
        popup.transient()
        popup.grab_set()
        popup.wait_window()

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        status_updater("Menyiapkan popup...", "INFO")


        try:
            payload_str = json.dumps(payload, indent=4, ensure_ascii=False)
        except Exception:
            payload_str = str(payload)

        popup_title = "Output Debug dari Node Sebelumnya"
        ui_callback(self._show_popup_on_ui_thread, popup_title, payload_str)
        status_updater("Popup ditampilkan", "SUCCESS")
        return payload

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        """
        Membuat UI Properti dengan memanggil pustaka standar.
        """
        property_vars = {}
        current_config = get_current_config()

        ttk.Label(parent_frame,
                  text="Modul ini tidak memiliki pengaturan khusus.\nCukup hubungkan ke output node lain untuk melihat datanya.",
                  wraplength=400, justify="center", bootstyle="info").pack(pady=10, padx=10)

        ttk.Separator(parent_frame).pack(fill='x', pady=10)
        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, current_config, self.loc)
        loop_vars = shared_properties.create_loop_settings_ui(parent_frame, current_config, self.loc, available_vars)

        property_vars.update(debug_vars)
        property_vars.update(loop_vars)

        return property_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################