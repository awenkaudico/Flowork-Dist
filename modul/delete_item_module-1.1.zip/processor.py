####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import os
import shutil
import time
import random
from flowork_kernel.api_contract import BaseModule
from tkinter import ttk, StringVar, BooleanVar, filedialog
from flowork_kernel.ui_shell import shared_properties

class DeleteItemModule(BaseModule):
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)
        self.logger("Modul 'Hapus File/Folder' berhasil diinisialisasi.", "INFO")

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        target_path = config.get('target_path')
        delete_mode = config.get('delete_mode', 'file')
        ignore_not_found = config.get('ignore_not_found', True)

        if not target_path:
            raise ValueError("Path target untuk dihapus tidak boleh kosong.")

        if not os.path.exists(target_path):
            if ignore_not_found:
                msg = f"Item di '{target_path}' tidak ditemukan, dilewati sesuai konfigurasi."
                self.logger(msg, "WARN")
                status_updater("Tidak Ditemukan", "WARN")
                payload['deleted_path'] = target_path # Tetap teruskan path untuk konsistensi
                return payload
            else:
                raise FileNotFoundError(f"Item yang akan dihapus tidak ditemukan di: {target_path}")

        if mode == 'SIMULATE':
            status_updater(f"Simulasi: Hapus '{target_path}'", "WARN")
            self.logger(f"SIMULASI: Seharusnya menghapus item di '{target_path}'.", "WARN")
            payload['deleted_path'] = target_path
            return payload

        try:
            status_updater(f"Menghapus...", "INFO")
            self.logger(f"Mencoba menghapus '{target_path}'...", "INFO")

            if delete_mode == 'file':
                if not os.path.isfile(target_path):
                    raise IsADirectoryError(f"Target adalah folder, tapi mode diatur ke 'Hapus File'. Gunakan mode 'Hapus Folder'. Path: {target_path}")
                os.remove(target_path)
                self.logger(f"File '{target_path}' berhasil dihapus.", "SUCCESS")

            elif delete_mode == 'folder':
                if not os.path.isdir(target_path):
                    raise NotADirectoryError(f"Target adalah file, tapi mode diatur ke 'Hapus Folder'. Gunakan mode 'Hapus File'. Path: {target_path}")
                shutil.rmtree(target_path)
                self.logger(f"Folder '{target_path}' dan seluruh isinya berhasil dihapus.", "SUCCESS")

            status_updater("Hapus Selesai", "SUCCESS")
            payload['deleted_path'] = target_path

        except Exception as e:
            self.logger(f"Gagal menghapus item: {e}", "ERROR")
            status_updater(f"Error: {e}", "ERROR")
            raise e

        return payload

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        config = get_current_config()
        created_vars = {}

        settings_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_delete_title'))
        settings_frame.pack(fill="x", padx=5, pady=(5,0))

        mode_frame = ttk.Frame(settings_frame)
        mode_frame.pack(fill='x', padx=10, pady=5)
        ttk.Label(mode_frame, text=self.loc.get('delete_mode_label', fallback="Mode Penghapusan:")).pack(side='left', padx=(0,10))

        delete_mode_var = StringVar(value=config.get('delete_mode', 'file'))
        created_vars['delete_mode'] = delete_mode_var

        source_frame = ttk.Frame(settings_frame)
        source_frame.pack(fill='x', padx=10, pady=(5,0))
        source_label = ttk.Label(source_frame)
        source_label.pack(fill='x', anchor='w')

        source_entry_frame = ttk.Frame(source_frame)
        source_entry_frame.pack(fill='x', expand=True, pady=(2,10))

        target_path_var = StringVar(value=config.get('target_path', ''))
        ttk.Entry(source_entry_frame, textvariable=target_path_var).pack(side='left', fill='x', expand=True)
        created_vars['target_path'] = target_path_var

        browse_button = ttk.Button(source_entry_frame, style="secondary.TButton")
        browse_button.pack(side='left', padx=(5,0))

        def _update_source_ui():
            if delete_mode_var.get() == 'file':
                source_label.config(text=self.loc.get('target_path_file_label'))
                browse_button.config(text=self.loc.get('browse_file_button'), command=lambda: target_path_var.set(filedialog.askopenfilename(title=self.loc.get('browse_file_title_delete')) or target_path_var.get()))
            else: # mode folder
                source_label.config(text=self.loc.get('target_path_folder_label'))
                browse_button.config(text=self.loc.get('browse_folder_button'), command=lambda: target_path_var.set(filedialog.askdirectory(title=self.loc.get('browse_folder_title_delete')) or target_path_var.get()))

        ttk.Radiobutton(mode_frame, text=self.loc.get('delete_mode_file'), variable=delete_mode_var, value='file', command=_update_source_ui).pack(side='left', padx=5)
        ttk.Radiobutton(mode_frame, text=self.loc.get('delete_mode_folder'), variable=delete_mode_var, value='folder', command=_update_source_ui).pack(side='left', padx=5)
        _update_source_ui()

        ignore_var = BooleanVar(value=config.get('ignore_not_found', True))
        ttk.Checkbutton(settings_frame, text=self.loc.get('ignore_not_found_label'), variable=ignore_var).pack(anchor='w', padx=10, pady=(0,10))
        created_vars['ignore_not_found'] = ignore_var

        ttk.Separator(parent_frame).pack(fill='x', pady=5)
        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, config, self.loc)
        created_vars.update(debug_vars)

        return created_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################