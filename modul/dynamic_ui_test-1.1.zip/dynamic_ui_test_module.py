####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from flowork_kernel.api_contract import BaseModule, BaseUIProvider
from flowork_kernel.ui_shell.custom_tab import CustomTab # Kita akan menggunakan CustomTab yang sudah ada

class DynamicUITestModule(BaseModule, BaseUIProvider):
    """
    Modul contoh ini mengimplementasikan BaseUIProvider untuk mendemonstrasikan
    penambahan tab UI dan item menu secara dinamis.
    """
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)
        self.logger(f"Modul Tes UI Dinamis '{self.module_id}' diinisialisasi.", "DEBUG")

    def on_load(self):
        """
        Dipanggil saat modul dimuat atau aplikasi dimulai.
        """
        self.logger(f"Modul Tes UI Dinamis '{self.module_id}' (v1.1.0) dimuat (on_load).", "INFO")

    def on_unload(self):
        """
        Dipanggil saat modul di-nonaktifkan atau aplikasi ditutup.
        """
        self.logger(f"Modul Tes UI Dinamis '{self.module_id}' di-nonaktifkan (on_unload).", "INFO")

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        """
        Metode ini tidak melakukan apa-apa karena ini adalah modul layanan.
        (Tapi sebagai turunan BaseModule, tetap harus diimplementasikan).
        """
        self.logger("Metode 'execute' dipanggil di Modul Tes UI Dinamis.", "INFO")
        status_updater("Selesai (Modul UI)", "SUCCESS")
        return payload

    def get_ui_tabs(self):
        """
        Mengembalikan daftar definisi tab kustom yang akan ditambahkan ke UI utama.
        """
        self.logger(f"Modul '{self.module_id}' menyediakan definisi tab UI.", "INFO")
        return [
            {
                "key": "dynamic_test_tab", # Kunci unik untuk tab ini
                "title": self.loc.get('dynamic_test_tab_title', fallback="Tab Tes Dinamis"),
                "frame_class": CustomTab
            }
        ]

    def get_menu_items(self):
        """
        Mengembalikan daftar definisi item menu yang akan ditambahkan ke menubar utama.
        """
        self.logger(f"Modul '{self.module_id}' menyediakan definisi item menu UI.", "INFO")
        return [
            {
                "parent": "Bantuan", # Menentukan menu utama tempat item ini akan muncul
                "label": self.loc.get('open_dynamic_test_tab_menu', fallback="Buka Tab Tes Dinamis"),
                "command": lambda: self.kernel.create_ui_tab_by_key("dynamic_test_tab"),
                "add_separator": True
            }
        ]
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################