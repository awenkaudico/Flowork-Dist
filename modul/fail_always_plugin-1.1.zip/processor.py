####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
from flowork_kernel.api_contract import BaseModule
from typing import Dict, Any
from flowork_kernel.ui_shell import shared_properties
import ttkbootstrap as ttk

class FailAlwaysPlugin(BaseModule):
    """
    FailAlwaysPlugin adalah sebuah plugin sederhana yang dirancang khusus
    untuk selalu menghasilkan kegagalan (error) saat dieksekusi.
    """
    TIER = "free"

    def __init__(self, module_id: str, services: Dict[str, Any]):
        super().__init__(module_id, services)
        self.logger(f"Modul 'Fail Always' ({self.module_id}) berhasil diinisialisasi.", "INFO")

    def execute(self, payload: Dict[str, Any], config: Dict[str, Any], status_updater: Any, ui_callback: Any, mode: str = 'EXECUTE') -> Dict[str, Any]:
        self.logger(self.loc.get('fail_always_executing_message', fallback="Modul 'Selalu Gagal' sedang mencoba beraksi..."), "WARN")
        status_updater(self.loc.get('fail_always_status_failing', fallback="Memulai kegagalan..."), "WARN")

        self.kernel.stop_workflow_execution()

        raise Exception(self.loc.get('fail_always_error_message', fallback="Sengaja GAGAL! Ini adalah kesalahan yang disimulasikan."))

    def create_properties_ui(self, parent_frame: Any, get_current_config: Any, available_vars: Dict[str, Any]) -> dict:
        """
        Meskipun tidak ada properti khusus, kita tetap tampilkan UI standar.
        """
        property_vars = {}
        current_config = get_current_config()

        ttk.Label(parent_frame,
                  text="Modul ini tidak memiliki pengaturan khusus.\nTujuannya hanya untuk selalu gagal saat dieksekusi.",
                  wraplength=400, justify="center", bootstyle="info").pack(pady=10, padx=10)

        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, current_config, self.loc)
        property_vars.update(debug_vars)

        return property_vars

    def on_install(self):
        self.logger(self.loc.get('fail_always_install_message', fallback="Modul 'Fail Always' berhasil diinstal!"), "SUCCESS")

    def on_load(self):
        self.logger(self.loc.get('fail_always_load_message', fallback="Modul 'Fail Always' dimuat dan siap untuk gagal."), "INFO")

    def on_unload(self):
        self.logger(self.loc.get('fail_always_unload_message', fallback="Modul 'Fail Always' dinonaktifkan."), "INFO")
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################