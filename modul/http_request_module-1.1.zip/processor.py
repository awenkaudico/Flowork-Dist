####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import json
import requests
import re
from flowork_kernel.api_contract import BaseModule
from tkinter import ttk, StringVar, Text
from flowork_kernel.ui_shell import shared_properties

class HttpRequestModule(BaseModule):
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)
        self.logger("Modul 'HTTP Request' berhasil diinisialisasi.", "INFO")

    def get_nested_value(self, payload, key_path):
        if not isinstance(key_path, str): return None
        keys = key_path.split('.')
        value = payload
        try:
            for key in keys:
                value = value[key]
            return value
        except (KeyError, TypeError):
            return None

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        url_mode = config.get('url_mode', 'manual')
        url = ""

        if url_mode == 'auto':
            variable_source = config.get('variable_source_url', '')
            if not variable_source:
                raise ValueError("Sumber variabel untuk URL otomatis belum dipilih.")

            url = self.get_nested_value(payload, variable_source)
            if not url or not isinstance(url, str):
                raise ValueError(f"Nilai dari variabel '{variable_source}' kosong atau bukan teks.")

            if not url.lower().startswith('http://') and not url.lower().startswith('https://'):
                raise ValueError(f"Nilai dari '{variable_source}' ('{url}') bukan URL yang valid. Harus diawali 'http://' atau 'https://'.")

            status_updater(f"URL dari payload: {url[:50]}...", "INFO")
        else:
            url = config.get('manual_url', '')

        if not url:
            raise ValueError("URL tujuan tidak boleh kosong.")

        method = config.get('method', 'GET').upper()

        headers_config = config.get('headers', '{}')
        headers = {}
        if isinstance(headers_config, dict):
            headers = headers_config
        elif isinstance(headers_config, str) and headers_config.strip():
            try:
                valid_json_string = headers_config.replace("'", '"')
                headers = json.loads(valid_json_string)
            except json.JSONDecodeError:
                raise ValueError("Format JSON pada Headers tidak valid.")

        body_str = config.get('body', '')
        auth_type = config.get('auth_type', 'none')

        auth = None
        if auth_type == 'bearer':
            token = config.get('bearer_token', '')
            if token: headers['Authorization'] = f'Bearer {token}'
        elif auth_type == 'basic':
            user = config.get('basic_user', '')
            password = config.get('basic_pass', '')
            auth = (user, password)

        if mode == 'SIMULATE':
            status_updater(f"Simulasi: {method} ke {url}", "WARN")
            payload.update({'response_status_code': 200,'response_headers': {'Content-Type': 'application/json'},'response_body': {'message': 'Ini adalah respons simulasi'}})
            return payload

        try:
            status_updater(f"{method} ke {url[:70]}...", "INFO")
            response = requests.request(method=method, url=url, headers=headers, data=body_str.encode('utf-8'), auth=auth, timeout=config.get('timeout_seconds') or 30)
            status_updater(f"Respons: {response.status_code}", "SUCCESS" if response.ok else "ERROR")

            try:
                response_body = response.json()
            except json.JSONDecodeError:
                response_body = response.text

            payload.update({'response_status_code': response.status_code,'response_headers': dict(response.headers),'response_body': response_body})
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            self.logger(f"Gagal melakukan HTTP Request: {e}", "ERROR")
            status_updater(f"Error: {e}", "ERROR")
            raise e
        return payload

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        config = get_current_config()
        created_vars = {}
        notebook = ttk.Notebook(parent_frame)
        notebook.pack(fill="both", expand=True, padx=5, pady=5)
        main_tab = ttk.Frame(notebook, padding=10)
        notebook.add(main_tab, text=self.loc.get('prop_tab_main', fallback="Utama"))
        url_mode_frame = ttk.LabelFrame(main_tab, text=self.loc.get('prop_url_mode_label'), padding=(10, 5))
        url_mode_frame.pack(fill='x', pady=(0, 10))
        url_mode_var = StringVar(value=config.get('url_mode', 'manual'))
        created_vars['url_mode'] = url_mode_var
        auto_frame = ttk.Frame(url_mode_frame)
        manual_frame = ttk.Frame(url_mode_frame)
        def _toggle_url_mode_ui():
            if url_mode_var.get() == 'auto':
                manual_frame.pack_forget()
                auto_frame.pack(fill='x', pady=5)
            else:
                auto_frame.pack_forget()
                manual_frame.pack(fill='x', pady=5)
        ttk.Radiobutton(url_mode_frame, text=self.loc.get('mode_auto_label'), variable=url_mode_var, value='auto', command=_toggle_url_mode_ui).pack(anchor='w', padx=5)
        ttk.Radiobutton(url_mode_frame, text=self.loc.get('mode_manual_label'), variable=url_mode_var, value='manual', command=_toggle_url_mode_ui).pack(anchor='w', padx=5)
        ttk.Separator(url_mode_frame).pack(fill='x', pady=5)
        ttk.Label(auto_frame, text=self.loc.get('prop_variable_source_url_label')).pack(anchor='w')
        variable_source_url_var = StringVar(value=config.get('variable_source_url', ''))
        ttk.Combobox(auto_frame, textvariable=variable_source_url_var, values=list(available_vars.keys()), state="readonly").pack(fill='x')
        created_vars['variable_source_url'] = variable_source_url_var
        ttk.Label(manual_frame, text=self.loc.get('prop_label_url')).pack(anchor='w')
        manual_url_var = StringVar(value=config.get('manual_url', 'https://jsonplaceholder.typicode.com/todos/1'))
        ttk.Entry(manual_frame, textvariable=manual_url_var).pack(fill='x', expand=True)
        created_vars['manual_url'] = manual_url_var
        _toggle_url_mode_ui()
        method_label = ttk.Label(main_tab, text=self.loc.get('prop_label_method'))
        method_label.pack(anchor='w', pady=(10,0))
        method_var = StringVar(value=config.get('method', 'GET'))
        ttk.Combobox(main_tab, textvariable=method_var, values=['GET', 'POST', 'PUT', 'DELETE', 'PATCH'], state='readonly').pack(fill='x', expand=True)
        created_vars['method'] = method_var
        headers_tab = ttk.Frame(notebook, padding=10)
        notebook.add(headers_tab, text=self.loc.get('prop_tab_headers', fallback="Headers"))
        ttk.Label(headers_tab, text=self.loc.get('prop_label_headers_json')).pack(anchor='w')
        headers_text = Text(headers_tab, height=8, font=("Consolas", 9))
        headers_text.pack(fill='both', expand=True, pady=(5,0))
        headers_text.insert('1.0', config.get('headers', '{\n    "Content-Type": "application/json"\n}'))
        created_vars['headers'] = headers_text
        body_tab = ttk.Frame(notebook, padding=10)
        notebook.add(body_tab, text=self.loc.get('prop_tab_body', fallback="Body"))
        ttk.Label(body_tab, text=self.loc.get('prop_label_body_json')).pack(anchor='w')
        body_text = Text(body_tab, height=8, font=("Consolas", 9))
        body_text.pack(fill='both', expand=True, pady=(5,0))
        body_text.insert('1.0', config.get('body', ''))
        created_vars['body'] = body_text
        auth_tab = ttk.Frame(notebook, padding=10)
        notebook.add(auth_tab, text=self.loc.get('prop_tab_auth', fallback="Otentikasi"))
        auth_type_var = StringVar(value=config.get('auth_type', 'none'))
        created_vars['auth_type'] = auth_type_var
        ttk.Label(auth_tab, text=self.loc.get('prop_label_auth_type')).pack(anchor='w')
        auth_combo = ttk.Combobox(auth_tab, textvariable=auth_type_var, values=['none', 'bearer', 'basic'], state='readonly')
        auth_combo.pack(fill='x', expand=True, pady=(2,10))
        bearer_frame_auth = ttk.Frame(auth_tab)
        basic_frame_auth = ttk.Frame(auth_tab)
        ttk.Label(bearer_frame_auth, text=self.loc.get('prop_label_bearer_token')).pack(anchor='w')
        bearer_token_var = StringVar(value=config.get('bearer_token', ''))
        ttk.Entry(bearer_frame_auth, textvariable=bearer_token_var, show='*').pack(fill='x', expand=True)
        created_vars['bearer_token'] = bearer_token_var
        ttk.Label(basic_frame_auth, text=self.loc.get('prop_label_basic_user')).pack(anchor='w')
        basic_user_var = StringVar(value=config.get('basic_user', ''))
        ttk.Entry(basic_frame_auth, textvariable=basic_user_var).pack(fill='x', expand=True, pady=(0,5))
        created_vars['basic_user'] = basic_user_var
        ttk.Label(basic_frame_auth, text=self.loc.get('prop_label_basic_pass')).pack(anchor='w')
        basic_pass_var = StringVar(value=config.get('basic_pass', ''))
        ttk.Entry(basic_frame_auth, textvariable=basic_pass_var, show='*').pack(fill='x', expand=True)
        created_vars['basic_pass'] = basic_pass_var
        def _toggle_auth_ui(*args):
            bearer_frame_auth.pack_forget()
            basic_frame_auth.pack_forget()
            if auth_type_var.get() == 'bearer': bearer_frame_auth.pack(fill='x', expand=True)
            elif auth_type_var.get() == 'basic': basic_frame_auth.pack(fill='x', expand=True)
        auth_type_var.trace_add('write', _toggle_auth_ui)
        _toggle_auth_ui()
        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, config, self.loc)
        loop_vars = shared_properties.create_loop_settings_ui(parent_frame, config, self.loc, available_vars)
        created_vars.update(debug_vars)
        created_vars.update(loop_vars)
        return created_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################