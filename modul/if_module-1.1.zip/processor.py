####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
from flowork_kernel.api_contract import BaseModule
import ttkbootstrap as ttk
from tkinter import StringVar

from flowork_kernel.ui_shell.shared_properties import create_debug_and_reliability_ui, create_loop_settings_ui
from flowork_kernel.api_contract import EnumVarWrapper


class IfModule(BaseModule):
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)

    def _to_number(self, value):
        try:
            return int(value)
        except (ValueError, TypeError):
            try:
                return float(value)
            except (ValueError, TypeError):
                return None

    def get_nested_value(self, payload, key_path):
        if not isinstance(key_path, str):
            return None
        keys = key_path.split('.')
        value = payload
        for key in keys:
            if isinstance(value, dict):
                value = value.get(key)
            else:
                self.logger(f"Mencoba akses '{key}' pada non-dictionary. Jalur: '{key_path}'.", "WARN")
                return None
        return value

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        variable_path = config.get("variable_to_check", "")
        operator = config.get("comparison_operator", "==")
        compare_value_str = str(config.get("value_to_compare", ""))

        actual_value = self.get_nested_value(payload, variable_path)

        if actual_value is None:
            status_updater(f"Variabel '{variable_path}' tidak ditemukan.", "ERROR")
            return {"payload": payload, "output_name": "false"}

        condition_met = False
        try:
            num_actual = self._to_number(actual_value)
            num_compare = self._to_number(compare_value_str)

            is_string_comparison = isinstance(actual_value, str)

            if operator == "==":
                condition_met = str(actual_value).lower() == compare_value_str.lower() if is_string_comparison else actual_value == compare_value_str
            elif operator == "!=":
                condition_met = str(actual_value).lower() != compare_value_str.lower() if is_string_comparison else actual_value != compare_value_str
            elif operator == ">":
                condition_met = (num_actual is not None and num_compare is not None and num_actual > num_compare)
            elif operator == "<":
                condition_met = (num_actual is not None and num_compare is not None and num_actual < num_compare)
            elif operator == ">=":
                condition_met = (num_actual is not None and num_compare is not None and num_actual >= num_compare)
            elif operator == "<=":
                condition_met = (num_actual is not None and num_compare is not None and num_actual <= num_compare)
            elif operator == "contains":
                condition_met = is_string_comparison and compare_value_str.lower() in str(actual_value).lower()
            elif operator == "not contains":
                condition_met = is_string_comparison and compare_value_str.lower() not in str(actual_value).lower()
            elif operator == "starts_with":
                condition_met = is_string_comparison and str(actual_value).lower().startswith(compare_value_str.lower())
            elif operator == "ends_with":
                condition_met = is_string_comparison and str(actual_value).lower().endswith(compare_value_str.lower())
            elif operator == "is empty":
                condition_met = not actual_value
            elif operator == "is not empty":
                condition_met = bool(actual_value)
            elif operator == "is number":
                condition_met = num_actual is not None
            elif operator == "is not number":
                condition_met = num_actual is None
        except Exception as e:
            self.logger(f"Error saat membandingkan: {e}", "ERROR")
            condition_met = False

        status_updater(f"Hasil: {condition_met}", "INFO")
        return {"payload": payload, "output_name": "true" if condition_met else "false"}

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        property_vars = {}
        current_config = get_current_config()

        if not available_vars or all(k in ['data', 'history'] for k in available_vars.keys()):
            ttk.Label(parent_frame, text="MODUL INI PERLU DIHUBUNGKAN:\nSilakan sambungkan input dari node lain untuk mendeteksi variabel secara otomatis.", wraplength=400, justify="center", bootstyle="warning").pack(pady=20, padx=10)
        else:
            ttk.Label(parent_frame, text=self.loc.get('prop_if_variable_label', fallback="Variabel yang Dicek:")).pack(fill='x', padx=5, pady=(10,0))
            variable_var = StringVar(value=current_config.get('variable_to_check', ''))
            property_vars['variable_to_check'] = variable_var
            ttk.Combobox(parent_frame, textvariable=variable_var, values=list(available_vars.keys())).pack(fill='x', padx=5)

            ttk.Label(parent_frame, text=self.loc.get('prop_if_operator_label', fallback="Operator Pembanding:")).pack(fill='x', padx=5, pady=(10,0))
            OPERATOR_MAP = [
                {"label": "Sama Dengan (==)", "value": "=="}, {"label": "Tidak Sama Dengan (!=)", "value": "!="},
                {"label": "Mengandung Teks", "value": "contains"}, {"label": "Tidak Mengandung Teks", "value": "not contains"},
                {"label": "Lebih Besar Dari (>)", "value": ">"}, {"label": "Lebih Kecil Dari (<)", "value": "<"},
                {"label": "Lebih Besar / Sama (>=)", "value": ">="}, {"label": "Lebih Kecil / Sama (<=)", "value": "<="},
                {"label": "Diawali Dengan", "value": "starts_with"}, {"label": "Diakhiri Dengan", "value": "ends_with"},
                {"label": "Kosong", "value": "is empty"}, {"label": "Tidak Kosong", "value": "is not empty"},
                {"label": "Angka", "value": "is number"}, {"label": "Bukan Angka", "value": "is not number"}
            ]
            label_to_value = {item['label']: item['value'] for item in OPERATOR_MAP}
            value_to_label = {item['value']: item['label'] for item in OPERATOR_MAP}
            operator_string_var = StringVar()
            operator_wrapper = EnumVarWrapper(operator_string_var, label_to_value, value_to_label)
            operator_wrapper.set(current_config.get('comparison_operator', '=='))
            property_vars['comparison_operator'] = operator_wrapper
            ttk.Combobox(parent_frame, textvariable=operator_string_var, values=list(label_to_value.keys()), state="readonly").pack(fill='x', padx=5)

            ttk.Label(parent_frame, text=self.loc.get('prop_if_value_label', fallback="Nilai Pembanding:")).pack(fill='x', padx=5, pady=(10,0))
            value_var = StringVar(value=current_config.get('value_to_compare', ''))
            property_vars['value_to_compare'] = value_var
            ttk.Entry(parent_frame, textvariable=value_var).pack(fill='x', padx=5)

        ttk.Separator(parent_frame).pack(fill='x', pady=15, padx=5)
        debug_vars = create_debug_and_reliability_ui(parent_frame, current_config, self.loc)
        property_vars.update(debug_vars)
        loop_vars = create_loop_settings_ui(parent_frame, current_config, self.loc, available_vars)
        property_vars.update(loop_vars)

        return property_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################