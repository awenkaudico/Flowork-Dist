####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import json
import threading
from flowork_kernel.api_contract import BaseModule
from flowork_kernel.ui_shell.shared_properties import create_debug_and_reliability_ui
import ttkbootstrap as ttk
from tkinter import IntVar

class Processor(BaseModule):
    """
    Processor untuk modul Join. Menunggu semua input sebelum melanjutkan.
    """
    TIER = "free"

    def __init__(self, module_id: str, services: dict):
        super().__init__(module_id, services)
        self.state_manager = services.get("state_manager")
        self.logger = services.get("logger")
        self.loc = services.get("loc")
        self.lock = threading.Lock()

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        node_instance_id = config.get('__internal_node_id')
        if not node_instance_id:
            self.logger("FATAL: Tidak dapat menemukan ID unik node. Modul Join tidak dapat berfungsi.", "ERROR")
            raise ValueError("Join module requires a unique node ID from the executor.")

        if payload is None and mode != 'SIMULATE':
             self.logger(f"Modul Join '{node_instance_id}' dieksekusi tanpa payload input. Seharusnya ini tidak terjadi.", "WARN")

        with self.lock:
            if mode == 'SIMULATE':
                status_updater("Simulasi: Menggabungkan dan melanjutkan", "WARN")
                return {"payload": payload, "output_name": "output"}

            state_key = f"join_module_state::{node_instance_id}"
            current_state = self.state_manager.get(state_key, {'received_payloads': []})
            current_state['received_payloads'].append(payload)
            self.logger(f"Node Join '{node_instance_id}' menerima sebuah payload. Total diterima: {len(current_state['received_payloads'])}.", "DEBUG")

            try:
                expected_inputs = int(config.get('expected_inputs', 2))
            except (ValueError, TypeError):
                expected_inputs = 2
                self.logger(f"Konfigurasi 'expected_inputs' untuk node Join '{node_instance_id}' tidak valid. Menggunakan default 2.", "WARN")

            received_count = len(current_state['received_payloads'])
            status_updater(self.loc.get('status_join_waiting', received=received_count, total=expected_inputs), "INFO")

            if received_count >= expected_inputs:
                self.logger(self.loc.get('log_join_complete', count=received_count, node_id=node_instance_id), "SUCCESS")
                final_payload = {}
                base_history_set = False
                for p_load in current_state['received_payloads']:
                    actual_data_payload = p_load
                    if isinstance(p_load, dict) and 'payload' in p_load and 'output_name' in p_load:
                        actual_data_payload = p_load['payload']
                    if not base_history_set and isinstance(actual_data_payload, dict):
                        final_payload['history'] = actual_data_payload.get('history', [])
                        base_history_set = True
                    if isinstance(actual_data_payload, dict):
                        data_to_merge = {k: v for k, v in actual_data_payload.items() if k != 'history'}
                        final_payload.update(data_to_merge)
                if 'history' not in final_payload:
                    final_payload['history'] = []
                self.logger(f"Payload gabungan: {json.dumps(final_payload, indent=2)}", "DETAIL")
                self.state_manager.delete(state_key)
                return {"payload": final_payload, "output_name": "output"}
            else:
                self.state_manager.set(state_key, current_state)
                return None

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        config = get_current_config()
        created_vars = {}
        join_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_join_title'))
        join_frame.pack(fill='x', padx=5, pady=(5, 10), expand=True)
        prop_frame = ttk.Frame(join_frame)
        prop_frame.pack(fill='x', padx=10, pady=10)
        ttk.Label(prop_frame, text=self.loc.get('prop_join_expected_inputs', fallback="Jumlah Input yang Diharapkan:")).pack(side='left')
        created_vars['expected_inputs'] = ttk.IntVar(value=config.get('expected_inputs', 2))
        ttk.Entry(prop_frame, textvariable=created_vars['expected_inputs'], width=5).pack(side='left', padx=5)
        debug_vars = create_debug_and_reliability_ui(parent_frame, config, self.loc)
        created_vars.update(debug_vars)
        return created_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################