####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import os
import shutil
import time
import random
from flowork_kernel.api_contract import BaseModule
from tkinter import ttk, StringVar, BooleanVar, filedialog
from flowork_kernel.ui_shell import shared_properties

class MoveFileModule(BaseModule):
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)
        self.logger("Modul 'Pindahkan File/Folder' berhasil diinisialisasi.", "INFO")

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        source_path = config.get('source_path')
        destination_path = config.get('destination_path')
        overwrite = config.get('overwrite', False)

        if not source_path or not destination_path:
            raise ValueError("Path sumber dan tujuan tidak boleh kosong.")

        if not os.path.exists(source_path):
            raise FileNotFoundError(f"File atau folder sumber tidak ditemukan di: {source_path}")

        final_path = os.path.join(destination_path, os.path.basename(source_path))

        if mode == 'SIMULATE':
            status_updater(f"Simulasi: Pindah '{source_path}' ke '{destination_path}'", "WARN")
            self.logger(f"SIMULASI: Seharusnya memindahkan '{source_path}' ke '{destination_path}'.", "WARN")
            payload['new_path'] = final_path
            return payload

        try:
            status_updater(f"Memindahkan...", "INFO")
            self.logger(f"Memindahkan '{source_path}' ke '{destination_path}'...", "INFO")

            if os.path.exists(final_path):
                if overwrite:
                    self.logger(f"Tujuan '{final_path}' sudah ada. Menimpa...", "WARN")
                    if os.path.isdir(final_path):
                        shutil.rmtree(final_path)
                    else:
                        os.remove(final_path)
                else:
                    raise FileExistsError(f"Destination path '{final_path}' already exists and overwrite is not enabled.")

            if not os.path.isdir(destination_path):
                 os.makedirs(destination_path, exist_ok=True)

            shutil.move(source_path, destination_path)

            status_updater("Pindah Selesai", "SUCCESS")
            self.logger(f"Berhasil dipindahkan. Lokasi baru di: {final_path}", "SUCCESS")
            payload['new_path'] = final_path

            if config.get('enable_sleep', False) and mode == 'EXECUTE':
                sleep_duration = 0
                sleep_type = config.get('sleep_type', 'static')
                if sleep_type == "static":
                    sleep_duration = config.get('static_duration', 1)
                    status_updater(f"Menjeda {sleep_duration} dtk...", "INFO")
                elif sleep_type == "random_range":
                    min_d, max_d = config.get('random_min', 1), config.get('random_max', 5)
                    sleep_duration = random.randint(min_d, max_d)
                    status_updater(f"Menjeda acak {sleep_duration} dtk...", "INFO")
                if sleep_duration > 0:
                    time.sleep(sleep_duration)
                    status_updater("Jeda Selesai", "SUCCESS")

        except Exception as e:
            self.logger(f"Gagal memindahkan: {e}", "ERROR")
            status_updater(f"Error: {e}", "ERROR")
            raise e

        return payload

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        config = get_current_config()
        created_vars = {}

        settings_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_move_title'))
        settings_frame.pack(fill="x", padx=5, pady=(5,0))

        mode_frame = ttk.Frame(settings_frame)
        mode_frame.pack(fill='x', padx=10, pady=5)
        ttk.Label(mode_frame, text=self.loc.get('move_mode_label', fallback="Mode Pemindahan:")).pack(side='left', padx=(0,10))

        move_mode_var = StringVar(value=config.get('move_mode', 'file'))
        created_vars['move_mode'] = move_mode_var

        source_frame = ttk.Frame(settings_frame)
        source_frame.pack(fill='x', padx=10, pady=(5,0))
        source_label = ttk.Label(source_frame)
        source_label.pack(fill='x', anchor='w')

        source_entry_frame = ttk.Frame(source_frame)
        source_entry_frame.pack(fill='x', expand=True, pady=(2,10))

        source_path_var = StringVar(value=config.get('source_path', ''))
        ttk.Entry(source_entry_frame, textvariable=source_path_var).pack(side='left', fill='x', expand=True)
        created_vars['source_path'] = source_path_var

        browse_button = ttk.Button(source_entry_frame, style="secondary.TButton")
        browse_button.pack(side='left', padx=(5,0))

        def _update_source_ui():
            if move_mode_var.get() == 'file':
                source_label.config(text=self.loc.get('source_path_file_label'))
                browse_button.config(text=self.loc.get('browse_file_button'), command=lambda: source_path_var.set(filedialog.askopenfilename(title=self.loc.get('browse_file_title')) or source_path_var.get()))
            else: # mode folder
                source_label.config(text=self.loc.get('source_path_folder_label'))
                browse_button.config(text=self.loc.get('browse_folder_button'), command=lambda: source_path_var.set(filedialog.askdirectory(title=self.loc.get('browse_folder_title')) or source_path_var.get()))

        ttk.Radiobutton(mode_frame, text=self.loc.get('move_mode_file'), variable=move_mode_var, value='file', command=_update_source_ui).pack(side='left', padx=5)
        ttk.Radiobutton(mode_frame, text=self.loc.get('move_mode_folder'), variable=move_mode_var, value='folder', command=_update_source_ui).pack(side='left', padx=5)
        _update_source_ui()

        dest_frame = ttk.Frame(settings_frame)
        dest_frame.pack(fill='x', padx=10, pady=(5,10))
        ttk.Label(dest_frame, text=self.loc.get('destination_folder_label', fallback="Path Folder Tujuan:")).pack(fill='x', anchor='w')
        dest_entry_frame = ttk.Frame(dest_frame)
        dest_entry_frame.pack(fill='x', expand=True, pady=(2,10))

        destination_path_var = StringVar(value=config.get('destination_path', ''))
        ttk.Entry(dest_entry_frame, textvariable=destination_path_var).pack(side='left', fill='x', expand=True)
        created_vars['destination_path'] = destination_path_var

        def browse_dest_folder():
            destination_path_var.set(filedialog.askdirectory(title=self.loc.get('browse_folder_title_dest')) or destination_path_var.get())
        ttk.Button(dest_entry_frame, text=self.loc.get('browse_folder_button'), command=browse_dest_folder, style="secondary.TButton").pack(side='left', padx=(5,0))

        overwrite_var = BooleanVar(value=config.get('overwrite', False))
        ttk.Checkbutton(settings_frame, text=self.loc.get('prop_move_overwrite_label'), variable=overwrite_var).pack(anchor='w', padx=10, pady=(0,10))
        created_vars['overwrite'] = overwrite_var

        ttk.Separator(parent_frame).pack(fill='x', pady=5)
        loop_vars = shared_properties.create_loop_settings_ui(parent_frame, config, self.loc, available_vars)
        created_vars.update(loop_vars)
        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, config, self.loc)
        created_vars.update(debug_vars)

        return created_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################