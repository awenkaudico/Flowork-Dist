####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from flowork_kernel.api_contract import BaseModule
from flowork_kernel.ui_shell import shared_properties

class ReceiverModule(BaseModule):
    """
    Modul yang secara pasif mendengarkan event dari Event Bus yang
    ditujukan untuk ID uniknya.
    """
    TIER = "free"

    def on_load(self):
        """
        Saat modul dimuat oleh kernel, daftarkan diri ke Event Bus.
        Ini adalah metode siklus hidup yang sangat penting untuk listener.
        """
        event_to_listen = f"CUSTOM_MESSAGE_FOR_{self.module_id}"
        self.logger(f"Modul '{self.module_id}' mulai mendengarkan event '{event_to_listen}'", "INFO")

        self.event_bus.subscribe(
            event_name=event_to_listen,
            subscriber_id=self.module_id,
            callback=self.handle_received_event
        )

    def handle_received_event(self, event_data):
        """Callback yang akan dieksekusi ketika event yang didengarkan diterima."""
        publisher = event_data.get('publisher_id', 'Tidak dikenal')
        log_message = self.loc.get('receiver_log_message', id=self.module_id, publisher=publisher)

        self.logger("--- EVENT DITERIMA ---", "SUCCESS")
        self.logger(log_message, "SUCCESS")
        self.logger(f"DATA: {event_data}", "DETAIL")
        self.logger("----------------------", "SUCCESS")

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        """Menampilkan informasi agar ID-nya mudah disalin."""
        config = get_current_config()
        created_vars = {}

        info_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_receiver_title'))
        info_frame.pack(fill='x', padx=5, pady=10)

        id_info_text = self.loc.get('receiver_id_info', id=self.module_id)
        ttk.Label(info_frame, text=id_info_text, wraplength=400, justify="left").pack(anchor='w', padx=10, pady=10)

        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, config, self.loc)
        created_vars.update(debug_vars)

        return created_vars

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        """Modul ini pasif, hanya meneruskan data jika ada di alur kerja visual."""
        status_updater(self.loc.get('receiver_status_listening'), "INFO")
        return payload
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################