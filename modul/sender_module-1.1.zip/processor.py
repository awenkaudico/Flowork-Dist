####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import StringVar
from flowork_kernel.api_contract import BaseModule
from flowork_kernel.ui_shell import shared_properties

class SenderModule(BaseModule):
    """
    Modul yang bertugas menerbitkan event ke modul lain secara nirkabel
    menggunakan Event Bus.
    """
    TIER = "free"

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        """Membuat UI untuk memasukkan ID modul penerima."""
        config = get_current_config()
        created_vars = {}

        receiver_id_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_sender_title'))
        receiver_id_frame.pack(fill='x', padx=5, pady=10)

        ttk.Label(receiver_id_frame, text=self.loc.get('sender_receiver_id_label')).pack(anchor='w', padx=10, pady=(5,0))

        created_vars['receiver_id'] = ttk.StringVar(value=config.get('receiver_id', ''))
        id_entry = ttk.Entry(receiver_id_frame, textvariable=created_vars['receiver_id'])
        id_entry.pack(fill='x', expand=True, pady=(2, 5), padx=10)
        id_entry.insert(0, self.loc.get('sender_receiver_id_placeholder'))


        help_text = self.loc.get('sender_receiver_id_help')
        ttk.Label(receiver_id_frame, text=help_text, font=("Helvetica", 8, "italic"), wraplength=400, justify='left').pack(anchor='w', pady=(0,5), padx=10)

        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, config, self.loc)
        created_vars.update(debug_vars)

        return created_vars

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        """Menerbitkan event ke Event Bus."""
        receiver_id = config.get('receiver_id')

        if not receiver_id:
            msg = self.loc.get('sender_error_no_id')
            self.logger(msg, "WARN")
            status_updater(msg, "WARN")
            return payload # Tetap lanjutkan alur kerja

        event_name = f"CUSTOM_MESSAGE_FOR_{receiver_id}"

        self.logger(f"Mengirim event '{event_name}' dengan payload...", "INFO")
        status_updater(self.loc.get('sender_status_sending', id=receiver_id[:8]), "INFO")

        self.event_bus.publish(
            event_name=event_name,
            event_data=payload,
            publisher_id=self.module_id
        )

        status_updater(self.loc.get('sender_status_sent'), "SUCCESS")
        return payload
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################