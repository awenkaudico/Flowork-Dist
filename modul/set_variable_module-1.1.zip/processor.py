####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
from flowork_kernel.api_contract import BaseModule
from flowork_kernel.ui_shell import shared_properties
import ttkbootstrap as ttk
from tkinter import StringVar

class SetVariableModule(BaseModule):
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)
        self.default_values = {
            "var_judul": "Berita Hari Ini",
            "var_nama": "John Doe",
            "var_konten": "Isi konten atau artikel.",
            "var_id_unik": "ID-001",
            "var_status": "PENDING",
            "var_url": "https://jsonplaceholder.typicode.com/todos/1",
            "var_path_file": "C:/path/to/your/file.txt",
            "var_kategori": "Umum",
            "var_tanggal": "2025-01-15",
            "var_catatan": "Catatan tambahan di sini."
        }

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        status_updater("Mengatur variabel...", "INFO")

        new_data = {
            "judul": config.get("var_judul", self.default_values["var_judul"]),
            "nama": config.get("var_nama", self.default_values["var_nama"]),
            "konten": config.get("var_konten", self.default_values["var_konten"]),
            "id_unik": config.get("var_id_unik", self.default_values["var_id_unik"]),
            "status": config.get("var_status", self.default_values["var_status"]),
            "url": config.get("var_url", self.default_values["var_url"]),
            "path_file": config.get("var_path_file", self.default_values["var_path_file"]),
            "kategori": config.get("var_kategori", self.default_values["var_kategori"]),
            "tanggal": config.get("var_tanggal", self.default_values["var_tanggal"]),
            "catatan": config.get("var_catatan", self.default_values["var_catatan"])
        }

        if isinstance(payload, dict):
            payload.update(new_data)
        else:
            payload = new_data

        if hasattr(self, 'logger'):
            log_message = "Variabel berhasil diatur:\n" + "\n".join([f"  - {k}: '{v}'" for k, v in new_data.items() if v])
            self.logger(log_message, "DETAIL")

        status_updater("Variabel berhasil diatur", "SUCCESS")

        if mode == 'EXECUTE':
            if hasattr(self, 'event_bus'):
                self.publish_event("VARIABLES_SET", new_data)
        else:
            if hasattr(self, 'logger'):
                self.logger("SIMULASI: Event 'VARIABLES_SET' tidak diterbitkan.", "WARN")

        return payload

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        """Membuat UI Properti yang sesuai standar baru."""
        property_vars = {}
        current_config = get_current_config()

        main_props_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('module_set_variable_prop_title'))
        main_props_frame.pack(fill='x', padx=5, pady=(5, 10), expand=True)

        properties_to_create = [
            {"id": "var_judul", "label_key": "prop_label_judul"},
            {"id": "var_nama", "label_key": "prop_label_nama"},
            {"id": "var_konten", "label_key": "prop_label_konten"},
            {"id": "var_id_unik", "label_key": "prop_label_id_unik"},
            {"id": "var_status", "label_key": "prop_label_status"},
            {"id": "var_url", "label_key": "prop_label_url"},
            {"id": "var_path_file", "label_key": "prop_label_path_file"},
            {"id": "var_kategori", "label_key": "prop_label_kategori"},
            {"id": "var_tanggal", "label_key": "prop_label_tanggal"},
            {"id": "var_catatan", "label_key": "prop_label_catatan"}
        ]

        for prop in properties_to_create:
            prop_id = prop["id"]
            label_text = self.loc.get(prop["label_key"])
            default_value = self.default_values.get(prop_id, "")

            ttk.Label(main_props_frame, text=f"{label_text}:").pack(fill='x', padx=10, pady=(5,0))
            saved_value = current_config.get(prop_id, default_value)
            entry_var = ttk.StringVar(value=saved_value)
            property_vars[prop_id] = entry_var
            ttk.Entry(main_props_frame, textvariable=entry_var).pack(fill='x', padx=10)

        ttk.Separator(parent_frame).pack(fill='x', pady=10)
        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, current_config, self.loc)
        loop_vars = shared_properties.create_loop_settings_ui(parent_frame, current_config, self.loc, available_vars)

        property_vars.update(debug_vars)
        property_vars.update(loop_vars)

        return property_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################