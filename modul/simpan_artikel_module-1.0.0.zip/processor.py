####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import os
from flowork_kernel.api_contract import BaseModule
from flowork_kernel.ui_shell.shared_properties import create_debug_and_reliability_ui
import ttkbootstrap as ttk
from tkinter import StringVar, BooleanVar, filedialog

class SimpanArtikelModule(BaseModule):
    """
    Modul untuk menyimpan konten teks (artikel) ke dalam sebuah file .txt.
    """
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)

    def get_nested_value(self, payload, key_path):
        """Helper untuk mengambil nilai dari nested dictionary di payload."""
        if not isinstance(key_path, str): return None
        keys = key_path.split('.')
        value = payload
        for key in keys:
            if isinstance(value, dict):
                value = value.get(key)
            else:
                return None
        return value

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        content_key = config.get('content_key', 'generated_article')
        output_folder = config.get('output_folder')
        filename_mode = config.get('filename_mode', 'manual')
        overwrite = config.get('overwrite', False)

        if not output_folder:
            raise ValueError("Folder output belum ditentukan di properti node.")

        content = self.get_nested_value(payload, content_key)
        if not content or not isinstance(content, str):
            raise ValueError(f"Payload dengan kunci '{content_key}' tidak ditemukan atau bukan teks.")

        filename = ""
        if filename_mode == 'manual':
            filename = config.get('manual_filename', 'artikel_baru')
        else: # dinamis
            filename_key = config.get('dynamic_filename_key', '')
            if not filename_key:
                raise ValueError("Kunci payload untuk nama file dinamis belum diatur.")
            filename = str(self.get_nested_value(payload, filename_key) or "artikel_tanpa_judul")
            # Membersihkan nama file dari karakter yang tidak valid
            filename = "".join(c for c in filename if c.isalnum() or c in (' ', '_', '-')).rstrip()

        if not filename:
            raise ValueError("Nama file tidak boleh kosong.")

        if not filename.lower().endswith('.txt'):
            filename += ".txt"

        full_path = os.path.join(output_folder, filename)

        if mode == 'SIMULATE':
            status_updater(f"Simulasi: Simpan ke '{full_path}'", "SUCCESS")
            payload['file_path_txt'] = full_path
            return payload

        try:
            status_updater(f"Menyimpan ke '{filename}'...", "INFO")

            if os.path.exists(full_path) and not overwrite:
                raise FileExistsError(f"File '{full_path}' sudah ada. Aktifkan opsi 'Timpa' jika ingin menimpanya.")

            os.makedirs(output_folder, exist_ok=True)

            with open(full_path, 'w', encoding='utf-8') as f:
                f.write(content)

            status_updater(f"Berhasil disimpan!", "SUCCESS")
            self.logger(f"Artikel berhasil disimpan di: {full_path}", "SUCCESS")
            payload['file_path_txt'] = full_path

        except Exception as e:
            self.logger(f"Gagal menyimpan file: {e}", "ERROR")
            status_updater(f"Error: {e}", "ERROR")
            raise e

        return payload

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        config = get_current_config()
        created_vars = {}

        # --- Frame untuk Input ---
        input_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_input_settings_title'))
        input_frame.pack(fill='x', padx=5, pady=10)
        ttk.Label(input_frame, text=self.loc.get('prop_content_key_label')).pack(anchor='w', padx=10, pady=(5,0))
        content_key_sv = StringVar(value=config.get('content_key', 'generated_article'))
        ttk.Combobox(input_frame, textvariable=content_key_sv, values=list(available_vars.keys())).pack(fill='x', padx=10, pady=(0,10))
        created_vars['content_key'] = content_key_sv

        # --- Frame untuk Output ---
        output_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_output_settings_title'))
        output_frame.pack(fill='x', padx=5, pady=5)

        # Folder Output
        ttk.Label(output_frame, text=self.loc.get('prop_output_folder_label')).pack(anchor='w', padx=10, pady=(5,0))
        folder_entry_frame = ttk.Frame(output_frame)
        folder_entry_frame.pack(fill='x', padx=10, pady=(0,10))
        output_folder_sv = StringVar(value=config.get('output_folder', ''))
        ttk.Entry(folder_entry_frame, textvariable=output_folder_sv).pack(side='left', fill='x', expand=True)
        ttk.Button(folder_entry_frame, text=self.loc.get('browse_folder_button'), style="secondary.TButton", command=lambda: output_folder_sv.set(filedialog.askdirectory() or output_folder_sv.get())).pack(side='left', padx=(5,0))
        created_vars['output_folder'] = output_folder_sv

        # Mode Nama File
        filename_mode_frame = ttk.Frame(output_frame)
        filename_mode_frame.pack(fill='x', padx=10, pady=5)
        filename_mode_sv = StringVar(value=config.get('filename_mode', 'manual'))
        created_vars['filename_mode'] = filename_mode_sv
        manual_radio = ttk.Radiobutton(filename_mode_frame, text=self.loc.get('prop_filename_mode_manual'), variable=filename_mode_sv, value='manual')
        manual_radio.pack(side='left', padx=(0,10))
        dynamic_radio = ttk.Radiobutton(filename_mode_frame, text=self.loc.get('prop_filename_mode_dynamic'), variable=filename_mode_sv, value='dynamic')
        dynamic_radio.pack(side='left')

        # Detail untuk setiap mode
        manual_frame = ttk.Frame(output_frame)
        dynamic_frame = ttk.Frame(output_frame)

        # Manual
        ttk.Label(manual_frame, text=self.loc.get('prop_manual_filename_label')).pack(anchor='w', padx=10, pady=(5,0))
        manual_filename_sv = StringVar(value=config.get('manual_filename', 'artikel_hasil_gemini'))
        ttk.Entry(manual_frame, textvariable=manual_filename_sv).pack(fill='x', padx=10, pady=(0,10))
        created_vars['manual_filename'] = manual_filename_sv

        # Dynamic
        ttk.Label(dynamic_frame, text=self.loc.get('prop_dynamic_filename_key_label')).pack(anchor='w', padx=10, pady=(5,0))
        dynamic_filename_key_sv = StringVar(value=config.get('dynamic_filename_key', ''))
        ttk.Combobox(dynamic_frame, textvariable=dynamic_filename_key_sv, values=list(available_vars.keys())).pack(fill='x', padx=10, pady=(0,10))
        created_vars['dynamic_filename_key'] = dynamic_filename_key_sv

        def toggle_filename_mode(*args):
            if filename_mode_sv.get() == 'manual':
                dynamic_frame.pack_forget()
                manual_frame.pack(fill='x')
            else:
                manual_frame.pack_forget()
                dynamic_frame.pack(fill='x')

        filename_mode_sv.trace_add('write', toggle_filename_mode)
        toggle_filename_mode()

        # Opsi Timpa
        overwrite_sv = BooleanVar(value=config.get('overwrite', False))
        ttk.Checkbutton(output_frame, text=self.loc.get('prop_overwrite_label'), variable=overwrite_sv).pack(anchor='w', padx=10, pady=10)
        created_vars['overwrite'] = overwrite_sv

        debug_vars = create_debug_and_reliability_ui(parent_frame, config, self.loc)
        created_vars.update(debug_vars)
        return created_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################