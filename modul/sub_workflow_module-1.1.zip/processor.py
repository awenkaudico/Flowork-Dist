####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import Listbox, Scrollbar, SINGLE, END, messagebox
from flowork_kernel.api_contract import BaseModule
import json
from flowork_kernel.ui_shell import shared_properties

class SubWorkflowModule(BaseModule):
    """
    Modul yang berfungsi untuk menjalankan alur kerja lain (dari preset)
    sebagai sebuah sub-rutin.
    """
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)

    def execute(self, payload: dict, config: dict, status_updater, ui_callback, mode: str = 'EXECUTE'):
        """
        Mengeksekusi preset sub-workflow yang dipilih.
        """
        ordered_presets = config.get('execution_order', [])
        node_id = config.get('__internal_node_id', 'sub_workflow_node')

        if not ordered_presets:
            status_updater("Tidak ada preset dikonfigurasi", "ERROR")
            raise ValueError("Tidak ada preset yang dikonfigurasi untuk dieksekusi di SubWorkflow.")

        final_payload = payload
        total_presets = len(ordered_presets)

        for i, preset_name in enumerate(ordered_presets):
            status_updater(f"Menjalankan preset {i+1}/{total_presets}: {preset_name}", "INFO")

            workflow_data = self.kernel.preset_manager.get_preset_data(preset_name)
            if not workflow_data:
                status_updater(f"Preset '{preset_name}' tidak ditemukan", "ERROR")
                raise FileNotFoundError(f"Preset '{preset_name}' yang dipilih tidak ditemukan.")

            if not workflow_data.get('nodes'):
                status_updater(f"Preset '{preset_name}' kosong", "WARN")
                self.logger(f"Peringatan: Preset '{preset_name}' kosong (tidak ada node). Dilewati.", "WARN")
                continue

            nodes = {node['id']: node for node in workflow_data.get('nodes', [])}
            connections = {conn['id']: conn for conn in workflow_data.get('connections', [])}

            try:
                sub_context_id = f"{node_id}_sub_{preset_name}"

                current_payload = self.kernel.workflow_executor.execute_workflow_synchronous(
                    nodes=nodes,
                    connections=connections,
                    initial_payload=final_payload,
                    logger=self.logger,
                    status_updater=lambda n_id, msg, lvl: self.logger(f"[{preset_name}] Node {n_id}: {msg}", lvl.upper()),
                    highlighter=lambda *args: None,
                    ui_callback=ui_callback,
                    workflow_context_id=sub_context_id,
                    mode=mode
                )

                final_payload = current_payload

                if isinstance(final_payload, Exception):
                    raise final_payload

            except Exception as e:
                self.logger(f"Sub-workflow '{preset_name}' gagal dengan error: {e}", "ERROR")
                status_updater(f"Error di '{preset_name}'", "ERROR")
                raise e

        status_updater(f"Semua {total_presets} preset selesai", "SUCCESS")
        return {"output_name": "success", "payload": final_payload}

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        """
        Membuat UI kustom untuk memilih dan mengurutkan preset yang akan dieksekusi.
        """
        config = get_current_config()
        created_vars = {}

        main_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('subworkflow_prop_title'))
        main_frame.pack(fill='both', expand=True, padx=5, pady=5)

        left_frame = ttk.Frame(main_frame)
        left_frame.pack(side='left', fill='both', expand=True, padx=(0, 5))
        ttk.Label(left_frame, text=self.loc.get('available_presets_label', fallback="Preset Tersedia:")).pack(anchor='w')
        all_presets = self.kernel.preset_manager.get_preset_list()
        available_listbox = Listbox(left_frame, selectmode=SINGLE, exportselection=False)
        for preset in all_presets:
            available_listbox.insert(END, preset)
        available_listbox.pack(fill='both', expand=True, padx=5, pady=5)

        mid_frame = ttk.Frame(main_frame)
        mid_frame.pack(side='left', fill='y', padx=5)
        add_button = ttk.Button(mid_frame, text=">", width=3)
        add_all_button = ttk.Button(mid_frame, text=">>", width=3)
        remove_button = ttk.Button(mid_frame, text="<", width=3)
        remove_all_button = ttk.Button(mid_frame, text="<<", width=3)
        add_button.pack(pady=5, anchor='center')
        add_all_button.pack(pady=5, anchor='center')
        remove_button.pack(pady=5, anchor='center')
        remove_all_button.pack(pady=5, anchor='center')

        right_frame = ttk.LabelFrame(main_frame, text=self.loc.get('execution_order_label', fallback="Urutan Eksekusi:"))
        right_frame.pack(side='left', fill='both', expand=True, padx=(5, 0))
        execution_listbox = Listbox(right_frame, selectmode=SINGLE, exportselection=False)
        execution_listbox.pack(fill='both', expand=True, padx=5, pady=5)

        order_frame = ttk.Frame(main_frame)
        order_frame.pack(side='left', fill='y', padx=5)
        move_up_button = ttk.Button(order_frame, text="▲", width=3)
        move_down_button = ttk.Button(order_frame, text="▼", width=3)
        move_up_button.pack(pady=5, anchor='center')
        move_down_button.pack(pady=5, anchor='center')

        initial_order = config.get('execution_order', [])
        for item in initial_order:
            execution_listbox.insert(END, item)

        def add_selected():
            selected_indices = available_listbox.curselection()
            if not selected_indices: return
            for i in selected_indices:
                item = available_listbox.get(i)
                if item not in execution_listbox.get(0, END):
                    execution_listbox.insert(END, item)
        def add_all():
            all_items = available_listbox.get(0, END)
            current_exec_items = execution_listbox.get(0, END)
            for item in all_items:
                if item not in current_exec_items:
                    execution_listbox.insert(END, item)
        def remove_selected():
            selected_indices = execution_listbox.curselection()
            if not selected_indices: return
            for i in reversed(selected_indices):
                execution_listbox.delete(i)
        def remove_all():
            execution_listbox.delete(0, END)
        def move_up():
            selected_indices = execution_listbox.curselection()
            if not selected_indices: return
            for i in selected_indices:
                if i > 0:
                    item = execution_listbox.get(i)
                    execution_listbox.delete(i)
                    execution_listbox.insert(i-1, item)
                    execution_listbox.selection_set(i-1)
        def move_down():
            selected_indices = execution_listbox.curselection()
            if not selected_indices: return
            for i in reversed(selected_indices):
                if i < execution_listbox.size() - 1:
                    item = execution_listbox.get(i)
                    execution_listbox.delete(i)
                    execution_listbox.insert(i+1, item)
                    execution_listbox.selection_set(i+1)

        add_button.config(command=add_selected)
        add_all_button.config(command=add_all)
        remove_button.config(command=remove_selected)
        remove_all_button.config(command=remove_all)
        move_up_button.config(command=move_up)
        move_down_button.config(command=move_down)

        created_vars['execution_order_widget'] = execution_listbox
        created_vars['execution_order'] = ttk.StringVar(value=json.dumps(config.get('execution_order', [])))
        def on_save_proxy():
            items = execution_listbox.get(0, END)
            created_vars['execution_order'].set(json.dumps(list(items)))
        parent_frame.on_save_proxy = on_save_proxy

        ttk.Separator(parent_frame).pack(fill='x', pady=10, padx=5)
        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, config, self.loc)
        loop_vars = shared_properties.create_loop_settings_ui(parent_frame, config, self.loc, available_vars)
        created_vars.update(debug_vars)
        created_vars.update(loop_vars)

        return created_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################