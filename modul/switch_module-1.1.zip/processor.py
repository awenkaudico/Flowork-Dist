####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
from flowork_kernel.api_contract import BaseModule
from flowork_kernel.api_contract import EnumVarWrapper
from flowork_kernel.ui_shell.shared_properties import create_debug_and_reliability_ui, create_loop_settings_ui
import ttkbootstrap as ttk
from tkinter import StringVar, BooleanVar

class Processor(BaseModule):
    """
    Mengevaluasi nilai dari sebuah variabel terhadap serangkaian kasus/aturan
    dan mengarahkan payload ke port output yang aturannya pertama kali terpenuhi.
    """
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)
        self.case_widgets = []

    def _to_number(self, value):
        try: return int(value)
        except (ValueError, TypeError):
            try: return float(value)
            except (ValueError, TypeError): return None

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        input_variable = config.get('input_variable')
        cases = config.get('cases', [])
        use_default = config.get('default_output', True)

        if not input_variable:
            status_updater("Variabel input kosong!", "ERROR")
            return {'output_name': 'Default', 'payload': payload} if use_default else payload

        actual_value = payload.get(input_variable)
        status_updater(f"Mengecek nilai: '{actual_value}'", "INFO")

        for case in cases:
            operator = case.get('operator')
            compare_value = str(case.get('compare_value', ''))

            port_name = compare_value

            condition_met = False
            try:
                num_actual = self._to_number(actual_value)
                num_compare = self._to_number(compare_value)

                if operator == "==": condition_met = str(actual_value).lower() == compare_value.lower()
                elif operator == "!=": condition_met = str(actual_value).lower() != compare_value.lower()
                elif operator == ">": condition_met = (num_actual is not None and num_compare is not None and num_actual > num_compare)
                elif operator == "<": condition_met = (num_actual is not None and num_compare is not None and num_actual < num_compare)
                elif operator == ">=": condition_met = (num_actual is not None and num_compare is not None and num_actual >= num_compare)
                elif operator == "<=": condition_met = (num_actual is not None and num_compare is not None and num_actual <= num_compare)
                elif operator == "contains": condition_met = compare_value.lower() in str(actual_value).lower()
                elif operator == "not contains": condition_met = compare_value.lower() not in str(actual_value).lower()
                elif operator == "starts with": condition_met = str(actual_value).lower().startswith(compare_value.lower())
                elif operator == "ends with": condition_met = str(actual_value).lower().endswith(compare_value.lower())
                elif operator == "is empty": condition_met = not actual_value
                elif operator == "is not empty": condition_met = bool(actual_value)
                elif operator == "is number": condition_met = num_actual is not None
                elif operator == "is not number": condition_met = num_actual is None
            except Exception as e:
                self.logger(f"Error saat membandingkan kasus '{port_name}': {e}", "ERROR")
                condition_met = False

            if condition_met:
                status_updater(f"Cocok: Aturan '{port_name}'", "SUCCESS")
                return {'output_name': port_name, 'payload': payload}

        if use_default:
            status_updater("Tidak ada aturan cocok", "WARN")
            return {'output_name': 'Default', 'payload': payload}

        status_updater("Tidak ada jalur keluar", "ERROR")
        return payload

    def get_dynamic_ports(self, current_config):
        ports = []
        cases = current_config.get('cases', [])
        if isinstance(cases, list):
            for case in cases:
                port_name = case.get('compare_value')
                if port_name:
                    ports.append({"name": port_name, "display_name": port_name})
        if current_config.get('default_output', True):
             ports.append({"name": "Default", "display_name": "Default"})
        return ports

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        self.case_widgets = []
        current_config = get_current_config()
        property_vars = {}

        input_frame = ttk.Frame(parent_frame)
        input_frame.pack(fill='x', padx=5, pady=(10, 5))
        ttk.Label(input_frame, text=self.loc.get('prop_switch_variable_label')).pack(anchor='w')
        input_var = ttk.StringVar(value=current_config.get('input_variable'))
        property_vars['input_variable'] = input_var
        ttk.Combobox(input_frame, textvariable=input_var, values=list(available_vars.keys()), state="readonly").pack(fill='x')

        cases_lf = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_switch_cases_label'))
        cases_lf.pack(fill="x", expand=True, padx=5, pady=5)

        header_frame = ttk.Frame(cases_lf)
        header_frame.pack(fill='x', padx=5, pady=(5,0))
        ttk.Label(header_frame, text="Operator", width=20).pack(side='left', expand=True, fill='x', padx=5)
        ttk.Label(header_frame, text="Nilai Pembanding (otomatis jadi nama port)").pack(side='left', expand=True, fill='x')

        self.list_items_frame = ttk.Frame(cases_lf)
        self.list_items_frame.pack(fill="x", expand=True, padx=5, pady=5)

        saved_cases = current_config.get('cases', [])
        if saved_cases and isinstance(saved_cases, list):
            for case_data in saved_cases:
                self._add_case_entry(self.list_items_frame, case_data)
        else:
            self._add_case_entry(self.list_items_frame, {})

        ttk.Button(cases_lf, text=self.loc.get('prop_switch_add_case_button'), command=lambda: self._add_case_entry(self.list_items_frame, {}), style="success.TButton").pack(pady=5, anchor='w', padx=5)

        class CaseListVar:
            def __init__(self, widgets_list): self.widgets = widgets_list
            def get(self):
                return [
                    {
                        "operator": item['op_wrapper'].get(),
                        "compare_value": item['val_var'].get()
                    }
                    for item in self.widgets if item['row_frame'].winfo_exists() and item['val_var'].get()
                ]
        property_vars['cases'] = CaseListVar(self.case_widgets)

        default_var = ttk.BooleanVar(value=current_config.get('default_output', True))
        property_vars['default_output'] = default_var
        ttk.Checkbutton(parent_frame, text=self.loc.get('prop_switch_enable_default_label'), variable=default_var).pack(anchor='w', padx=10, pady=5)

        debug_vars = create_debug_and_reliability_ui(parent_frame, current_config, self.loc)
        property_vars.update(debug_vars)
        loop_vars = create_loop_settings_ui(parent_frame, current_config, self.loc, available_vars)
        property_vars.update(loop_vars)

        return property_vars

    def _add_case_entry(self, parent, case_data):
        OPERATOR_MAP = [
            {"label": "Sama Dengan (teks)", "value": "=="}, {"label": "Tidak Sama Dengan (teks)", "value": "!="},
            {"label": "Mengandung Teks", "value": "contains"}, {"label": "Tidak Mengandung Teks", "value": "not contains"},
            {"label": "Dimulai Dengan", "value": "starts with"}, {"label": "Diakhiri Dengan", "value": "ends with"},
            {"label": "Lebih Besar Dari (angka)", "value": ">"}, {"label": "Lebih Kecil Dari (angka)", "value": "<"},
            {"label": "Lebih Besar / Sama (angka)", "value": ">="}, {"label": "Lebih Kecil / Sama (angka)", "value": "<="},
            {"label": "Kosong", "value": "is empty"}, {"label": "Tidak Kosong", "value": "is not empty"},
            {"label": "Angka", "value": "is number"}, {"label": "Bukan Angka", "value": "is not number"}
        ]
        label_to_value = {item['label']: item['value'] for item in OPERATOR_MAP}
        value_to_label = {item['value']: item['label'] for item in OPERATOR_MAP}

        item_row = ttk.Frame(parent)
        item_row.pack(fill='x', pady=2)

        op_string_var = ttk.StringVar()
        op_wrapper = EnumVarWrapper(op_string_var, label_to_value, value_to_label)
        op_wrapper.set(case_data.get('operator', '=='))
        ttk.Combobox(item_row, textvariable=op_string_var, values=list(label_to_value.keys()), state="readonly", width=20).pack(side='left', expand=True, fill='x', padx=5)

        val_var = ttk.StringVar(value=case_data.get('compare_value', ''))
        ttk.Entry(item_row, textvariable=val_var).pack(side='left', expand=True, fill='x')

        delete_button = ttk.Button(item_row, text="X", width=2, style="danger.TButton", command=lambda r=item_row: r.destroy())
        delete_button.pack(side='left', padx=(5,0))

        self.case_widgets.append({
            "row_frame": item_row,
            "op_wrapper": op_wrapper,
            "val_var": val_var
        })
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################