####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
from flowork_kernel.api_contract import BaseModule
from tkinter import messagebox
import ttkbootstrap as ttk
from tkinter import StringVar
from flowork_kernel.ui_shell import shared_properties

class TampilkanVariabelModule(BaseModule):
    """
    Contoh modul premium yang menampilkan nilai dari variabel global/secret.
    """
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)
        self.logger = services.get("logger")
        self.variable_manager = services.get("variable_manager")
        self.logger(f"Plugin Demo '{self.manifest.get('name')}' versi final berhasil diinisialisasi.", "INFO")

    def execute(self, payload: dict, config: dict, status_updater, ui_callback, mode: str = 'EXECUTE'):
        """
        Fungsi eksekusi utama.
        """
        status_updater("Memulai...", "INFO")
        self.logger("Plugin Demo: Memulai eksekusi...", "INFO")
        target_variable = config.get("variabel_target")

        if not target_variable:
            status_updater("Nama variabel target belum diatur!", "ERROR")
            raise ValueError("Konfigurasi 'variabel_target' tidak boleh kosong.")

        if mode == 'SIMULATE':
            status_updater(f"Simulasi: Akan menampilkan var '{target_variable}'", "SUCCESS")
            return payload

        variable_value = self.variable_manager.get_variable(target_variable)
        self.logger(f"--- HASIL DEMO TAMPILKAN VARIABEL ---", "INFO")
        self.logger(f"Nama variabel yang dicari: '{target_variable}'", "INFO")
        self.logger(f"Nilai yang ditemukan: '{variable_value}'", "INFO")
        self.logger(f"Tipe data dari nilai tersebut: {type(variable_value).__name__}", "INFO")

        if variable_value is None:
            message_text = f"Variabel '{target_variable}' tidak ditemukan di Pengaturan."
            status_updater("Variabel tidak ditemukan", "WARN")
        else:
            message_text = f"Nilai dari variabel '{target_variable}' adalah:\n\n{variable_value}"
            status_updater("Variabel ditampilkan", "SUCCESS")

        ui_callback(lambda: messagebox.showinfo("Nilai Variabel", message_text))

        return payload

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        """
        Membuat UI untuk mengatur properti dari modul ini.
        """
        config = get_current_config()
        created_vars = {}

        all_variables = [v['name'] for v in self.variable_manager.get_all_variables_for_ui()]
        main_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('demo_plugin_settings_title'), padding=(10, 5))
        main_frame.pack(fill='x', padx=5, pady=5)
        ttk.Label(main_frame, text=self.loc.get('demo_plugin_variable_label')).pack(anchor='w')
        created_vars['variabel_target'] = ttk.StringVar(value=config.get('variabel_target', ''))
        var_combobox = ttk.Combobox(main_frame, textvariable=created_vars['variabel_target'], values=all_variables)
        var_combobox.pack(fill='x', pady=(2, 10))

        ttk.Separator(parent_frame).pack(fill='x', pady=10)
        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, config, self.loc)
        loop_vars = shared_properties.create_loop_settings_ui(parent_frame, config, self.loc, available_vars)

        created_vars.update(debug_vars)
        created_vars.update(loop_vars)

        return created_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################