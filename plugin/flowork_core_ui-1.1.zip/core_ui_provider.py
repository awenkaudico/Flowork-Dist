####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
from flowork_kernel.api_contract import BaseModule, BaseUIProvider

from .settings_tab import SettingsTab
from .module_manager_page import ModuleManagerPage
from .plugin_manager_page import PluginManagerPage
from .widget_manager_page import WidgetManagerPage
from .template_manager_page import TemplateManagerPage
from .generator_page import GeneratorPage
from .trigger_manager_page import TriggerManagerPage

class CoreUIProvider(BaseModule, BaseUIProvider):
    """
    Plugin ini tidak melakukan apa-apa di workflow, TAPI ia bertugas menyediakan
    semua halaman manajemen inti (Pengaturan, Modul, Plugin, dll.) ke UI utama.
    """
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)
        if hasattr(self, 'logger') and callable(self.logger):
            self.logger("Plugin Penyedia UI Inti (Core UI Provider) berhasil dimuat.", "SUCCESS")

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        """
        Metode ini tidak dipanggil untuk modul tipe SERVICE, tapi harus ada
        untuk memenuhi kontrak BaseModule.
        """
        if hasattr(self, 'logger') and callable(self.logger):
            self.logger("CoreUIProvider's execute method called (should not happen).", "WARN")
        return payload

    def get_ui_tabs(self):
        """
        Mengembalikan daftar semua halaman manajemen inti sebagai Tab.
        """
        if hasattr(self, 'logger') and callable(self.logger):
            self.logger("CoreUIProvider: Kernel meminta daftar halaman yang saya sediakan.", "DEBUG")
        return [
            {
                "key": "settings",
                "title": self.loc.get('settings_tab_title', fallback="Pengaturan"),
                "frame_class": SettingsTab
            },
            {
                "key": "module_manager",
                "title": self.loc.get('module_manager_page_title', fallback="Manajemen Modul"),
                "frame_class": ModuleManagerPage
            },
            {
                "key": "plugin_manager",
                "title": self.loc.get('plugin_manager_page_title', fallback="Manajemen Plugin"),
                "frame_class": PluginManagerPage
            },
            {
                "key": "widget_manager",
                "title": self.loc.get('widget_manager_page_title', fallback="Manajemen Widget"),
                "frame_class": WidgetManagerPage
            },
            {
                "key": "trigger_manager",
                "title": self.loc.get('trigger_manager_page_title', fallback="Manajemen Pemicu"),
                "frame_class": TriggerManagerPage
            },
            {
                "key": "template_manager",
                "title": self.loc.get('template_manager_page_title', fallback="Manajemen Template"),
                "frame_class": TemplateManagerPage
            },
            {
                "key": "generator",
                "title": self.loc.get('generator_page_title', fallback="Alat Generator"),
                "frame_class": GeneratorPage
            }
        ]

    def get_menu_items(self):
        """
        Plugin ini tidak menambahkan item menu, jadi kembalikan list kosong.
        """
        return []
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################