####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import ttk as tk_ttk, messagebox, Text, StringVar, BooleanVar
import os
import json
import re
import uuid
import zipfile
import tempfile
import shutil
from tkinter import filedialog

from flowork_kernel.ui_shell.custom_widgets.tooltip import ToolTip
from ttkbootstrap.scrolled import ScrolledFrame

class GeneratorPage(ttk.Frame):
    """
    Halaman untuk Alat Generator dengan form inline dan panel panduan dinamis.
    """

    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, style='TFrame')
        self.kernel = kernel_instance
        self.loc = self.kernel.loc

        self.item_name_var = StringVar()
        self.item_id_var = StringVar()
        self.item_kind_var = StringVar()
        self.item_type_var = StringVar()
        self.item_desc_text = None
        self.item_tutorial_text = None
        self.item_tier_var = StringVar()
        self.item_author_var = StringVar()
        self.item_requirements_text = None
        self.item_permissions_vars = {}
        self.item_use_state_manager_var = BooleanVar(value=False)
        self.item_use_variable_var = BooleanVar(value=False)

        self.type_combo = None
        self.manual_text = None

        self.create_widgets()

        self.item_name_var.trace_add("write", self._update_id_field)
        self.item_kind_var.trace_add("write", self._update_type_dropdown)
        self.item_type_var.trace_add("write", self._update_manual_book_content)
        for perm_var in self.item_permissions_vars.values():
            perm_var.trace_add('write', self._update_manual_book_content)
        self.item_use_state_manager_var.trace_add('write', self._update_manual_book_content)
        self.item_use_variable_var.trace_add('write', self._update_manual_book_content)

        self.apply_styles(self.kernel.theme_manager.get_colors())
        self.refresh_content()


    def apply_styles(self, colors):
        style = tk_ttk.Style(self)
        style.configure('TFrame', background=colors.get('bg'))
        style.configure('TLabel', background=colors.get('bg'), foreground=colors.get('fg'))
        style.configure('TLabelframe', background=colors.get('bg'), relief="solid", borderwidth=1, bordercolor=colors.get('border'))
        style.configure('TLabelframe.Label', background=colors.get('bg'), foreground=colors.get('fg'), font=('Helvetica', 11, 'bold'))
        style.configure('Header.TLabel', font=('Helvetica', 10, 'bold'), foreground=colors.get('primary'))


    def create_widgets(self):
        main_container_frame = ttk.Frame(self, padding=20, style='TFrame')
        main_container_frame.pack(fill="both", expand=True)
        main_container_frame.columnconfigure(0, weight=1, uniform="group1")
        main_container_frame.columnconfigure(1, weight=1, uniform="group1")
        main_container_frame.rowconfigure(0, weight=1)

        form_column = ttk.LabelFrame(main_container_frame, text="Generator", padding=15, style='TLabelframe')
        form_column.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        ttk.Label(form_column, text="Nama Fitur (cth: 'Kirim Email Notifikasi')").pack(fill='x', anchor='w')
        ttk.Entry(form_column, textvariable=self.item_name_var).pack(fill='x', pady=(0,10))

        ttk.Label(form_column, text="ID Unik (otomatis):").pack(fill='x', anchor='w')
        ttk.Entry(form_column, textvariable=self.item_id_var, state="readonly").pack(fill='x', pady=(0,10))

        ttk.Label(form_column, text="Jenis Fitur:").pack(fill='x', anchor='w')
        kind_combo = ttk.Combobox(form_column, textvariable=self.item_kind_var, values=["Modul", "Plugin", "Widget"], state="readonly")
        kind_combo.pack(fill='x', pady=(0,10))
        kind_combo.set("Modul")
        kind_combo.bind("<<ComboboxSelected>>", self._update_type_dropdown)

        ttk.Label(form_column, text="Tipe Spesifik:").pack(fill='x', anchor='w')
        self.type_combo = ttk.Combobox(form_column, textvariable=self.item_type_var, state="readonly")
        self.type_combo.pack(fill='x', pady=(0,10))

        ttk.Label(form_column, text="Deskripsi:").pack(fill='x', anchor='w')
        self.item_desc_text = Text(form_column, height=5, font=("Helvetica", 9))
        self.item_desc_text.pack(fill='x', pady=(0,10))

        ttk.Label(form_column, text="Tutorial (Jelaskan cara penggunaan di sini):").pack(fill='x', anchor='w')
        self.item_tutorial_text = Text(form_column, height=6, font=("Helvetica", 9))
        self.item_tutorial_text.pack(fill='x', pady=(0,10))

        ttk.Label(form_column, text="Author:").pack(fill='x', anchor='w')
        self.item_author_var.set("Flowork Contributor")
        ttk.Entry(form_column, textvariable=self.item_author_var).pack(fill='x', pady=(0,10))

        ttk.Label(form_column, text="Tingkatan Fitur (Tier):").pack(fill='x', anchor='w')
        tier_combo = ttk.Combobox(form_column, textvariable=self.item_tier_var, values=["FREE", "PREMIUM"], state="readonly")
        tier_combo.pack(fill='x', pady=(0,10))
        tier_combo.set("FREE")

        ttk.Label(form_column, text="Dependensi Eksternal (satu per baris, cth: 'requests==2.31.0'):").pack(fill='x', anchor='w', pady=(10,0))
        self.item_requirements_text = Text(form_column, height=4, font=("Consolas", 9))
        self.item_requirements_text.pack(fill='x', pady=(0,10), expand=True)

        manual_column = ttk.Frame(main_container_frame, style='TFrame')
        manual_column.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        manual_column.rowconfigure(1, weight=1) # Baris untuk panduan dibuat fleksibel
        manual_column.columnconfigure(0, weight=1)

        optional_features_frame = ttk.LabelFrame(manual_column, text=self.loc.get('generator_optional_features_title', fallback="Fitur Tambahan"), padding=10)
        optional_features_frame.grid(row=0, column=0, sticky="ew")

        permissions_frame = ttk.LabelFrame(optional_features_frame, text="Izin yang Dibutuhkan", padding=10)
        permissions_frame.pack(fill='x', pady=(0,5))
        self.item_permissions_vars['ui_provider'] = BooleanVar()
        ttk.Checkbutton(permissions_frame, text="ui_provider (bisa membuat tab/menu baru)", variable=self.item_permissions_vars['ui_provider']).pack(anchor='w')
        self.item_permissions_vars['ui_interaction'] = BooleanVar()
        ttk.Checkbutton(permissions_frame, text="ui_interaction (bisa menampilkan popup)", variable=self.item_permissions_vars['ui_interaction']).pack(anchor='w')

        state_frame = ttk.LabelFrame(optional_features_frame, text="Integrasi Data", padding=10)
        state_frame.pack(fill='x', pady=(5,0))
        ttk.Checkbutton(state_frame, text=self.loc.get('generator_option_use_state_manager', fallback="Gunakan State Manager"), variable=self.item_use_state_manager_var).pack(anchor='w')
        ttk.Checkbutton(state_frame, text=self.loc.get('generator_option_use_variable', fallback="Gunakan Variabel Global"), variable=self.item_use_variable_var).pack(anchor='w')

        guide_frame = ttk.LabelFrame(manual_column, text=self.loc.get('generator_guide_title', fallback="Panduan"), padding=15, style='TLabelframe')
        guide_frame.grid(row=1, column=0, sticky="nsew", pady=(10,0))
        guide_frame.rowconfigure(0, weight=1)
        guide_frame.columnconfigure(0, weight=1)

        self.manual_text = Text(guide_frame, wrap='word', state='disabled', font=("Helvetica", 9), relief='flat', background=self.kernel.theme_manager.get_colors().get('bg'), foreground=self.kernel.theme_manager.get_colors().get('fg'))
        self.manual_text.pack(fill='both', expand=True)

        ttk.Button(manual_column, text="Buat File ZIP Kerangka", command=self._start_generation_process, style="success.TButton").grid(row=2, column=0, sticky="ew", pady=(15,0))

    def refresh_content(self):
        self._update_type_dropdown()
        self.kernel.write_to_log(self.loc.get('log_generator_page_refreshed', fallback="Halaman Generator dimuat ulang."), "DEBUG")

    def _update_id_field(self, *args):
        name_text = self.item_name_var.get().lower()
        sanitized_name = re.sub(r'[^a-z0-9_]', '', name_text.replace(' ', '_'))
        if sanitized_name:
            if not hasattr(self, '_current_random_suffix'):
                self._current_random_suffix = str(uuid.uuid4())[:4]
            id_text = f"{sanitized_name}_{self._current_random_suffix}"
            self.item_id_var.set(id_text)
        else:
            self.item_id_var.set("")
            if hasattr(self, '_current_random_suffix'):
                del self._current_random_suffix

    def _update_type_dropdown(self, *args):
        kind = self.item_kind_var.get()
        if self.type_combo:
            if kind == "Modul":
                self.type_combo['values'] = ["LOGIC", "CONTROL_FLOW"]
                self.type_combo.set("LOGIC")
            elif kind == "Plugin":
                self.type_combo['values'] = ["ACTION", "TRIGGER"]
                self.type_combo.set("ACTION")
            elif kind == "Widget":
                self.type_combo['values'] = ["DASHBOARD_WIDGET"]
                self.type_combo.set("DASHBOARD_WIDGET")
        self._update_manual_book_content()

    def _update_manual_book_content(self, *args):
        kind = self.item_kind_var.get()
        item_type = self.item_type_var.get()
        content = self.loc.get('generator_guide_intro', fallback="Panduan Generator\n-----------------\n")
        content += self.loc.get('generator_guide_kind_title', fallback="\nJenis Fitur:\n")
        content += self.loc.get(f'generator_guide_kind_{kind}', fallback=f"Deskripsi untuk jenis '{kind}' tidak tersedia.") + "\n"
        if item_type:
            content += self.loc.get('generator_guide_type_title', fallback="\nTipe Spesifik:\n")
            content += self.loc.get(f'generator_guide_type_{item_type}', fallback=f"Deskripsi untuk tipe '{item_type}' tidak tersedia.") + "\n"
        selected_permissions = [key for key, var in self.item_permissions_vars.items() if var.get()]
        use_state_manager = self.item_use_state_manager_var.get()
        use_variable = self.item_use_variable_var.get()
        if selected_permissions or use_state_manager or use_variable:
            content += self.loc.get('generator_guide_options_title', fallback="\n--- Fitur Tambahan ---\n")
        if selected_permissions:
            for perm in selected_permissions:
                content += "• " + self.loc.get(f'generator_guide_permissions_{perm}', fallback=f"Izin {perm}.") + "\n"
        if use_state_manager:
            content += "• " + self.loc.get('generator_guide_option_state_manager', fallback="Gunakan State Manager.") + "\n"
        if use_variable:
            content += "• " + self.loc.get('generator_guide_option_variable', fallback="Gunakan Variabel Global.") + "\n"
        if self.manual_text:
            self.manual_text.config(state='normal')
            self.manual_text.delete('1.0', 'end')
            self.manual_text.insert('1.0', content)
            self.manual_text.config(state='disabled')

    def _start_generation_process(self):
        config = {
            'id': self.item_id_var.get(),
            'name': self.item_name_var.get(),
            'kind': self.item_kind_var.get(),
            'type': self.item_type_var.get(),
            'description': self.item_desc_text.get("1.0", "end-1c").strip(),
            'tutorial': self.item_tutorial_text.get("1.0", "end-1c").strip(),
            'author': self.item_author_var.get(),
            'tier': self.item_tier_var.get(),
            'permissions': [key for key, var in self.item_permissions_vars.items() if var.get()],
            'use_state_manager': self.item_use_state_manager_var.get(),
            'use_variable': self.item_use_variable_var.get(),
            'requirements': self.item_requirements_text.get("1.0", "end-1c").strip()
        }
        if not all([config['id'], config['name'], config['type']]):
            messagebox.showerror("Data Tidak Lengkap", "Harap isi field Nama, Jenis, dan Tipe.")
            return
        try:
            self._generate_zip(config)
        except Exception as e:
            messagebox.showerror("Error Generator", f"Gagal membuat file ZIP: {e}\n\n{traceback.format_exc()}")

    def _generate_zip(self, config):
        temp_dir = tempfile.mkdtemp()
        try:
            module_root_path = os.path.join(temp_dir, config['id'])
            locales_path = os.path.join(module_root_path, 'locales')
            os.makedirs(locales_path)

            entry_point_file = "processor" if config['kind'] != 'Widget' else f"{config['id']}_widget"
            class_name = "".join(word.capitalize() for word in config['id'].split('_'))
            if config['kind'] == 'Widget':
                class_name += "Widget"
            elif config['kind'] == "Modul" or config['kind'] == "Plugin":
                class_name += "Module"

            required_services = ["logger", "loc"]
            if config.get('use_state_manager'): required_services.append("state_manager")
            if config.get('use_variable'):
                if 'kernel' not in required_services: required_services.append("kernel")

            manifest_content = {
                "id": config['id'], "name": f"loc.{config['id']}_name", "version": "1.0",
                "author": config['author'], "description": f"loc.{config['id']}_description",
                "tutorial": f"loc.{config['id']}_tutorial",
                "type": config['type'], "entry_point": f"{entry_point_file}.{class_name}",
                "requires_services": sorted(list(set(required_services))),
                "permissions": config['permissions'],
            }
            if config['type'] in ['CONTROL_FLOW', 'ACTION']:
                manifest_content["output_ports"] = [{"name": "output", "display_name": "Selesai"}]
            with open(os.path.join(module_root_path, 'manifest.json'), 'w', encoding='utf-8') as f:
                json.dump(manifest_content, f, indent=4, ensure_ascii=False)

            base_class = "BaseDashboardWidget" if config['kind'] == 'Widget' else "BaseModule"
            init_params = "(self, parent, coordinator_tab, kernel, widget_id: str, **kwargs)" if config['kind'] == 'Widget' else "(self, module_id, services)"
            super_init = "super().__init__(parent, coordinator_tab, kernel, widget_id, **kwargs)" if config['kind'] == 'Widget' else "super().__init__(module_id, services)"

            execute_logic = ""
            if config.get('use_state_manager'):
                execute_logic = f"""
        counter_key = f"exec_count_{{self.module_id}}"
        current_count = self.state_manager.get(counter_key, 0)
        new_count = current_count + 1
        self.state_manager.set(counter_key, new_count)
        self.logger(f"Modul ini telah dieksekusi sebanyak {{new_count}} kali.", "SUCCESS")
        status_updater(f"Eksekusi ke-{{new_count}}", "SUCCESS")
"""
            elif config.get('use_variable'):
                execute_logic = f"""
        nilai_dari_variabel = config.get('target_variable')
        self.logger(f"Nilai yang diterima dari variabel adalah: '{{str(nilai_dari_variabel)}}'", "SUCCESS")
        status_updater("Variabel Diterima", "SUCCESS")
"""
            else:
                execute_logic = f"""
        self.logger("Logika eksekusi dimulai.", "INFO")
        status_updater("Selesai", "SUCCESS")
"""
            processor_content = f"from flowork_kernel.api_contract import {base_class}\n"
            if config.get('use_variable'):
                 processor_content += "from tkinter import StringVar\nimport ttkbootstrap as ttk\n"

            processor_content += f"\nclass {class_name}({base_class}):\n"
            processor_content += f"    def __init__{init_params}:\n"
            processor_content += f"        {super_init}\n"
            processor_content += f"        self.tier = \"{config['tier'].upper()}\"\n"
            processor_content += f"        self.logger(self.loc.get('{config['id']}_name'), 'INFO')\n"

            if config['kind'] != 'Widget':
                processor_content += f"\n    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):\n{execute_logic}\n        return payload\n"

            if config['kind'] == 'Modul' and config.get('use_variable'):
                processor_content += """
    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        config = get_current_config()
        settings_frame = ttk.LabelFrame(parent_frame, text="Pengaturan Variabel")
        settings_frame.pack(fill="x", padx=5, pady=10)
        ttk.Label(settings_frame, text="Masukkan Placeholder Variabel:").pack(fill='x', padx=10)
        target_var = StringVar(value=config.get('target_variable', ''))
        entry = ttk.Entry(settings_frame, textvariable=target_var)
        entry.pack(fill='x', padx=10, pady=10)
        ttk.Label(settings_frame, text="Contoh: {{vars.NAMA_ANDA}}", font=("Helvetica", 8, "italic")).pack(fill='x', padx=10)
        return {'target_variable': target_var}
"""
            elif config['kind'] == 'Modul':
                processor_content += """
    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        pass
"""
            with open(os.path.join(module_root_path, f'{entry_point_file}.py'), 'w', encoding='utf-8') as f:
                f.write(processor_content)

            locale_content = {
                f"{config['id']}_name": config['name'],
                f"{config['id']}_description": config['description'],
                f"{config['id']}_tutorial": config['tutorial']
            }
            with open(os.path.join(locales_path, 'id.json'), 'w', encoding='utf-8') as f:
                json.dump(locale_content, f, indent=4, ensure_ascii=False)
            with open(os.path.join(locales_path, 'en.json'), 'w', encoding='utf-8') as f:
                json.dump(locale_content, f, indent=4, ensure_ascii=False)

            with open(os.path.join(module_root_path, 'requirements.txt'), 'w', encoding='utf-8') as f:
                f.write(config['requirements'])

            save_path = filedialog.asksaveasfilename(
                title="Simpan File ZIP Kerangka", initialfile=f"{config['id']}.zip",
                defaultextension=".zip", filetypes=[("ZIP files", "*.zip")]
            )
            if not save_path: return

            shutil.make_archive(os.path.splitext(save_path)[0], 'zip', temp_dir)
            messagebox.showinfo("Sukses", f"File '{os.path.basename(save_path)}' berhasil dibuat!")
        finally:
            shutil.rmtree(temp_dir)
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################