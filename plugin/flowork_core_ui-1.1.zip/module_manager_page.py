####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import ttk as tk_ttk, messagebox, filedialog, StringVar
import os
import shutil
import platform
import subprocess
import requests # NEW: Untuk mengunduh modul dari GitHub
import zipfile # NEW: Untuk mengekstrak file ZIP
import io # NEW: Untuk membaca data biner
import threading # NEW: Untuk operasi yang tidak memblokir UI
import uuid # NEW: Untuk nama file temporer unik
import traceback # NEW: Untuk mendapatkan traceback lengkap dari error

from flowork_kernel.ui_shell.custom_widgets.tooltip import ToolTip
from ttkbootstrap.scrolled import ScrolledFrame

class InstalledModulesTab(ttk.Frame):
    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, style='TFrame')
        self.kernel = kernel_instance
        self.loc = self.kernel.loc
        self.search_var = StringVar()
        self.search_var.trace_add("write", self._on_search)
        self.create_widgets()
        self.apply_styles(self.kernel.theme_manager.get_colors())
        self.populate_module_list()

    def apply_styles(self, colors):
        style = tk_ttk.Style(self)
        style.configure('TFrame', background=colors.get('bg'))
        style.configure('TLabel', background=colors.get('bg'), foreground=colors.get('fg'))
        style.configure('TLabelframe', background=colors.get('bg'), borderwidth=1, relief='solid', bordercolor=colors.get('border'))
        style.configure('TLabelframe.Label', background=colors.get('bg'), foreground=colors.get('fg'), font=('Helvetica', 10, 'bold'))
        style.configure('Paused.TLabel', background=colors.get('bg'), foreground=colors.get('secondary'))
        style.configure('Permissions.TLabel', background=colors.get('bg'), foreground=colors.get('warning'), font=('Helvetica', 7, 'italic'))

    def create_widgets(self):
        main_container_frame = ttk.Frame(self, padding=20, style='TFrame')
        main_container_frame.pack(fill="both", expand=True)

        module_frame = ttk.LabelFrame(main_container_frame, text=self.loc.get('module_management_title', fallback="Manajemen Modul"), padding=15, style='TLabelframe')
        module_frame.pack(fill="both", expand=True, pady=(0, 20))

        top_bar_frame = ttk.Frame(module_frame, style='TFrame')
        top_bar_frame.pack(fill='x', pady=5)

        upload_module_button = ttk.Button(top_bar_frame, text=self.loc.get('upload_module_button', fallback="Unggah Modul"), command=self.upload_module, style="primary.TButton")
        upload_module_button.pack(side="left")

        search_frame = ttk.Frame(top_bar_frame, style='TFrame')
        search_frame.pack(side="right", fill='x', expand=True, padx=(10, 0))
        search_frame.columnconfigure(1, weight=1)

        search_icon_label = ttk.Label(search_frame, text="", font=("Font Awesome 6 Free Solid", 9), style='TLabel')
        search_icon_label.grid(row=0, column=0, padx=(0, 5))

        search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        search_entry.grid(row=0, column=1, sticky="ew")
        ToolTip(search_entry).update_text(self.loc.get('tooltip_search_installed_modules', fallback="Ketik untuk mencari modul terinstal...")) # Adjusted tooltip

        scrolled_frame_container = ttk.Frame(module_frame, style='TFrame')
        scrolled_frame_container.pack(fill='both', expand=True, pady=(10,0))
        self.module_list_frame = ScrolledFrame(scrolled_frame_container, autohide=True)
        self.module_list_frame.pack(fill='both', expand=True)

    def _on_search(self, *args):
        self.populate_module_list()

    def refresh_content(self):
        self.populate_module_list()

    def populate_module_list(self):
        for widget in self.module_list_frame.winfo_children():
            widget.destroy()

        filter_text = self.search_var.get().lower()
        modules = self.kernel.module_manager.loaded_modules
        sorted_modules = sorted(modules.items(), key=lambda item: item[1].get('manifest', {}).get('name', item[0]).lower())

        module_found = False
        for module_id, module_data in sorted_modules:
            if module_data.get('installed_as') != 'module':
                continue

            manifest = module_data.get('manifest', {})

            raw_name = manifest.get('name', module_id)
            raw_description = manifest.get('description', '')
            display_name = self.loc.get(raw_name[4:], fallback=raw_name) if raw_name.startswith('loc.') else raw_name
            display_description = self.loc.get(raw_description[4:], fallback=raw_description) if raw_description.startswith('loc.') else raw_description

            if filter_text and not (filter_text in display_name.lower() or
                                    filter_text in display_description.lower() or
                                    filter_text in module_id.lower()):
                continue

            module_found = True
            module_type = manifest.get('type', 'ACTION').upper()
            item_container = ttk.Frame(self.module_list_frame, style='TFrame')
            item_container.pack(fill='x', pady=2)
            item_frame = ttk.Frame(item_container, style='TFrame')
            item_frame.pack(fill='x')

            is_paused = self.kernel.module_manager.is_module_paused(module_id)
            label_style = 'Paused.TLabel' if is_paused else 'TLabel'
            paused_prefix = self.loc.get('paused_prefix', fallback="[DIJEDA] ") if is_paused else ""
            display_type = self.loc.get(f'module_type_{module_type.lower()}', fallback=module_type)

            label_text = self.loc.get('module_list_item_format', fallback='• {name} ({id}) [Tipe: {type}]', name=display_name, id=module_id, type=display_type)
            ttk.Label(item_frame, text=f"{paused_prefix}{label_text}", style=label_style).pack(side='left', anchor='w', fill='x', expand=True)

            if display_description:
                ttk.Label(item_container, text=display_description, style='TLabel', wraplength=400, justify='left').pack(anchor='w', padx=15, pady=(0,5))

            buttons_frame = ttk.Frame(item_frame, style='TFrame')
            buttons_frame.pack(side='right')

            if is_paused:
                toggle_pause_button = ttk.Button(buttons_frame, text=self.loc.get('resume_button', fallback="Lanjutkan"), style="success-link", width=2, command=lambda mid=module_id: self.toggle_module_pause(mid, False))
                ToolTip(toggle_pause_button).update_text(self.loc.get('tooltip_resume_module', fallback="Lanjutkan modul ini."))
            else:
                toggle_pause_button = ttk.Button(buttons_frame, text=self.loc.get('pause_button', fallback="Jeda"), style="warning-link", width=2, command=lambda mid=module_id: self.toggle_module_pause(mid, True))
                ToolTip(toggle_pause_button).update_text(self.loc.get('tooltip_pause_module', fallback="Jeda modul ini agar tidak dimuat saat aplikasi dimulai."))
            toggle_pause_button.pack(side='right', padx=(5,0))

            edit_button = ttk.Button(buttons_frame, text=self.loc.get('edit_button', fallback="Edit"), style="info-link", width=2, command=lambda mid=module_id: self.edit_module(mid))
            ToolTip(edit_button).update_text(self.loc.get('tooltip_edit_module', fallback="Buka folder modul di file explorer."))
            edit_button.pack(side='right', padx=(5,0))

            is_system_module = manifest.get("is_system", False)
            if not is_system_module:
                uninstall_button = ttk.Button(buttons_frame, text=self.loc.get('uninstall_button', fallback="Hapus"), style="link", width=2, command=lambda mid=module_id, mname=display_name: self.uninstall_module(mid, mname))
                ToolTip(uninstall_button).update_text(self.loc.get('tooltip_delete_module', fallback="Hapus modul ini dari sistem."))
                uninstall_button.pack(side='right', padx=(5,0))

            permissions = self.kernel.module_manager.get_module_permissions(module_id)
            if permissions:
                permission_frame = ttk.Frame(item_container, style='TFrame')
                permission_frame.pack(fill='x', padx=(15, 0), pady=(0, 5))
                perm_string = ", ".join(permissions)
                perm_label = ttk.Label(permission_frame, text=self.loc.get('permissions_label', perm_string=perm_string, fallback=f"Izin: {perm_string}"), style='Permissions.TLabel')
                perm_label.pack(anchor='w')

        if not module_found:
            ttk.Label(self.module_list_frame, text=self.loc.get('no_modules_installed_message', fallback="Tidak ada modul terinstal."), style='TLabel').pack(pady=20)

    def _open_path_in_explorer(self, path):
        try:
            if platform.system() == "Windows": os.startfile(path)
            elif platform.system() == "Darwin": subprocess.Popen(["open", path])
            else: subprocess.Popen(["xdg-open", path])
        except Exception as e:
            error_msg = self.loc.get('log_failed_to_open_folder', path=path, error=str(e), fallback=f"Gagal membuka folder '{path}': {e}")
            messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg)

    def edit_module(self, module_id):
        module_data = self.kernel.module_manager.loaded_modules.get(module_id)
        if not module_data:
            messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('plugin_not_found_error', name=module_id, fallback=f"Modul '{module_id}' tidak ditemukan."))
            return
        self._open_path_in_explorer(module_data['path'])

    def toggle_module_pause(self, module_id, should_pause):
        raw_name = self.kernel.module_manager.get_manifest(module_id).get('name', module_id)
        display_name = self.loc.get(raw_name[4:], fallback=raw_name) if raw_name.startswith('loc.') else raw_name
        if self.kernel.module_manager.set_module_paused(module_id, should_pause):
            if should_pause:
                self.kernel.write_to_log(self.loc.get('module_paused_message', name=display_name, fallback=f"Modul '{display_name}' dijeda."), "WARN")
            else:
                self.kernel.write_to_log(self.loc.get('module_resumed_message', name=display_name, fallback=f"Modul '{display_name}' dilanjutkan."), "SUCCESS")
        self.populate_module_list()

    def uninstall_module(self, module_id, module_name):
        module_data = self.kernel.module_manager.loaded_modules.get(module_id)
        if not module_data:
            messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('plugin_not_found_error', name=module_name, fallback=f"Modul '{module_name}' tidak ditemukan."))
            return
        module_path_to_delete = module_data['path']
        if messagebox.askyesno(self.loc.get('confirm_delete_title', fallback="Konfirmasi Hapus"), self.loc.get('confirm_delete_module_message', name=module_name, fallback=f"Apakah Anda yakin ingin menghapus modul '{module_name}'?")):
            try:
                shutil.rmtree(module_path_to_delete)
                messagebox.showinfo(self.loc.get('success_title', fallback="Berhasil"), self.loc.get('module_deleted_success_message', name=module_name, fallback=f"Modul '{module_name}' telah dihapus."))
                self.kernel.reload_modules()
            except Exception as e:
                error_msg = self.loc.get('module_delete_failed_error', name=module_name, error=e, fallback=f"Gagal menghapus modul '{module_name}': {e}")
                messagebox.showerror(self.loc.get('failed_title', fallback="Gagal"), error_msg)
            finally:
                self.populate_module_list()

    def upload_module(self):
        filepath = filedialog.askopenfilename(title=self.loc.get('select_module_file_title', fallback="Pilih File Modul (.zip)"), filetypes=[(self.loc.get('zip_files_label', fallback="File ZIP"), "*.zip")])
        if not filepath: return
        zip_filename = os.path.basename(filepath)
        module_name = os.path.splitext(zip_filename)[0]
        if not messagebox.askyesno(self.loc.get('confirm_upload_title', fallback="Konfirmasi Unggah"), self.loc.get('confirm_upload_module_message', name=module_name, fallback=f"Apakah Anda yakin ingin mengunggah dan menginstal modul '{module_name}'?")):
            return
        def _upload_and_install():
            module_target_dir = None
            temp_extract_dir = None
            try:
                self.kernel.write_to_log(self.loc.get('log_uploading_module', name=module_name, fallback=f"Mengunggah dan menginstal modul '{module_name}'..."), "INFO")
                temp_extract_dir = os.path.join(self.kernel.data_path, f"temp_upload_extract_{uuid.uuid4()}")
                os.makedirs(temp_extract_dir, exist_ok=True)
                with zipfile.ZipFile(filepath, 'r') as zip_ref:
                    zip_ref.extractall(temp_extract_dir)
                extracted_contents = os.listdir(temp_extract_dir)
                source_module_folder_path = temp_extract_dir
                if len(extracted_contents) == 1 and os.path.isdir(os.path.join(temp_extract_dir, extracted_contents[0])):
                    source_module_folder_path = os.path.join(temp_extract_dir, extracted_contents[0])
                    if os.path.basename(source_module_folder_path) != module_name:
                        self.kernel.write_to_log(self.loc.get('zip_folder_name_mismatch', name_in_zip=os.path.basename(source_module_folder_path), expected_name=module_name, fallback=f"WARN: Nama folder dalam ZIP '{os.path.basename(source_module_folder_path)}' tidak cocok dengan ID modul yang diharapkan '{module_name}'. Lanjutkan..."), "WARN")
                module_target_dir = os.path.join(self.kernel.modules_path, module_name)
                if os.path.exists(module_target_dir):
                    self.kernel.write_to_log(self.loc.get('module_folder_exists_warning', name=module_name, fallback=f"Folder modul '{module_name}' sudah ada. Menimpa..."), "WARN")
                    shutil.rmtree(module_target_dir)
                shutil.move(source_module_folder_path, module_target_dir)
                if not os.path.exists(os.path.join(module_target_dir, 'manifest.json')):
                    raise Exception(self.loc.get('manifest_not_found_after_extract', name=module_name, fallback=f"File manifest.json tidak ditemukan setelah ekstraksi modul '{module_name}'. Instalasi gagal."))
                self.kernel.write_to_log(self.loc.get('log_module_uploaded_success', name=module_name, fallback=f"Modul '{module_name}' berhasil diunggah dan diinstal!"), "SUCCESS")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showinfo(self.loc.get('success_title', fallback="Berhasil"), self.loc.get('module_uploaded_success_popup', name=module_name, fallback=f"Modul '{module_name}' berhasil diunggah dan diinstal!\nAplikasi akan memuat ulang modul.")))
                self.kernel.reload_modules()
            except zipfile.BadZipFile:
                error_msg = self.loc.get('module_zip_corrupt_upload', name=module_name, fallback=f"File '{filepath}' bukan file ZIP yang valid atau rusak.")
                self.kernel.write_to_log(error_msg, "ERROR")
                self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg))
            except Exception as e:
                full_traceback = traceback.format_exc()
                error_msg_detail = str(e)
                error_msg = self.loc.get('module_upload_failed', name=module_name, error=error_msg_detail, fallback=f"Gagal mengunggah atau menginstal '{module_name}': {error_msg_detail}")
                self.kernel.write_to_log(f"ERROR: {error_msg}\nTraceback:\n{full_traceback}", "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg))
            finally:
                if temp_extract_dir and os.path.exists(temp_extract_dir):
                    try:
                        shutil.rmtree(temp_extract_dir)
                        self.kernel.write_to_log(f"Membersihkan folder ekstraksi temporer: {temp_extract_dir}", "DEBUG")
                    except Exception as clean_e:
                        self.kernel.write_to_log(f"Gagal membersihkan folder temporer: {temp_extract_dir} - {clean_e}", "WARN")
        threading.Thread(target=_upload_and_install, daemon=True).start()

class DiscoverModulesTab(ttk.Frame):
    GITHUB_MODULES_URL = "https://raw.githubusercontent.com/flowork-dev/modul/refs/heads/main/top_modul.json"
    def __init__(self, parent_notebook, kernel_instance, installed_modules_tab_instance):
        super().__init__(parent_notebook, style='TFrame')
        self.kernel = kernel_instance
        self.loc = self.kernel.loc
        self.installed_modules_tab = installed_modules_tab_instance
        self.search_var = StringVar()
        self.search_var.trace_add("write", self._on_search)
        self.online_modules_data = []
        self.create_widgets()
        self.apply_styles(self.kernel.theme_manager.get_colors())
        self.fetch_and_populate_modules()

    def apply_styles(self, colors):
        style = tk_ttk.Style(self)
        style.configure('TFrame', background=colors.get('bg'))
        style.configure('TLabel', background=colors.get('bg'), foreground=colors.get('fg'))
        style.configure('Installable.TLabel', background=colors.get('bg'), foreground=colors.get('info'))
        style.configure('Permissions.TLabel', background=colors.get('bg'), foreground=colors.get('warning'), font=('Helvetica', 7, 'italic'))

    def create_widgets(self):
        main_frame = ttk.Frame(self, padding=15, style='TFrame')
        main_frame.pack(fill="both", expand=True)
        search_frame = ttk.Frame(main_frame, style='TFrame')
        search_frame.pack(fill='x', pady=5)
        search_frame.columnconfigure(1, weight=1)
        search_icon_label = ttk.Label(search_frame, text="", font=("Font Awesome 6 Free Solid", 9), style='TLabel')
        search_icon_label.grid(row=0, column=0, padx=(0, 5))
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        search_entry.grid(row=0, column=1, sticky="ew")
        ToolTip(search_entry).update_text(self.loc.get('tooltip_search_online_modules', fallback="Ketik untuk mencari modul online..."))
        self.module_list_frame = ScrolledFrame(main_frame, autohide=True)
        self.module_list_frame.pack(fill='both', expand=True, pady=(10,0))

    def _on_search(self, *args):
        self.populate_online_module_list()

    def refresh_content(self):
        self.fetch_and_populate_modules()

    def fetch_and_populate_modules(self):
        def _fetch():
            self.online_modules_data = self.fetch_online_modules_data()
            if self.kernel.root and hasattr(self.kernel.root, 'after'):
                self.kernel.root.after(0, self.populate_online_module_list)
        threading.Thread(target=_fetch, daemon=True).start()

    def fetch_online_modules_data(self):
        try:
            self.kernel.write_to_log(self.loc.get('log_fetching_online_modules', fallback="Mengambil daftar modul dari GitHub..."), "INFO")
            response = requests.get(self.GITHUB_MODULES_URL, timeout=10)
            response.raise_for_status()
            data = response.json()
            installed_ids = {mod_id for mod_id, _ in self.kernel.module_manager.loaded_modules.items()}
            filtered_data = [
                module for module in data if module.get('name') not in installed_ids and
                os.path.splitext(os.path.basename(module.get('download_url', '')).replace(".zip", ""))[0] not in installed_ids
            ]
            self.kernel.write_to_log(self.loc.get('log_fetched_online_modules', count=len(filtered_data), fallback=f"Berhasil mengambil {len(filtered_data)} modul dari GitHub."), "SUCCESS")
            return filtered_data
        except requests.exceptions.RequestException as e:
            self.kernel.write_to_log(self.loc.get('log_fetch_online_modules_error', error=str(e), fallback=f"Gagal mengambil daftar modul dari GitHub: {e}"), "ERROR")
            if self.kernel.root and hasattr(self.kernel.root, 'after'):
                self.kernel.root.after(0, lambda err=e: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('fetch_modules_error_popup', error=str(err), fallback=f"Gagal mengambil daftar modul dari GitHub: {err}\nPastikan koneksi internet Anda berfungsi.")))
            return []
        except ValueError as e:
            self.kernel.write_to_log(self.loc.get('log_parse_online_modules_error', error=str(e), fallback=f"Gagal mengurai data modul dari GitHub: {e}"), "ERROR")
            if self.kernel.root and hasattr(self.kernel.root, 'after'):
                self.kernel.root.after(0, lambda err=e: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('parse_modules_error_popup', error=str(err), fallback=f"Gagal mengurai data modul dari GitHub: {err}\nFormat JSON mungkin tidak valid.")))
            return []

    def populate_online_module_list(self):
        for widget in self.module_list_frame.winfo_children():
            widget.destroy()
        filter_text = self.search_var.get().lower()
        modules_to_display = sorted(
            [m for m in self.online_modules_data if filter_text in m.get('name', '').lower() or filter_text in m.get('description', '').lower()],
            key=lambda x: x.get('name', '').lower()
        )
        if not modules_to_display:
            ttk.Label(self.module_list_frame, text=self.loc.get('no_online_modules_found_message', fallback="Tidak ada modul online yang ditemukan atau modul sudah terinstal."), style='TLabel').pack(pady=20)
            return
        for module_info in modules_to_display:
            module_name = module_info.get('name', 'Unknown Module')
            description = module_info.get('description', 'No description available.')
            author = module_info.get('author', 'Unknown Author')
            version = module_info.get('version', 'N/A')
            download_url = module_info.get('download_url')
            item_container = ttk.Frame(self.module_list_frame, style='TFrame', borderwidth=1, relief="solid", padding=5)
            item_container.pack(fill='x', pady=5, padx=5)
            name_label = ttk.Label(item_container, text=f"{module_name} (v{version})", style='Installable.TLabel', font=('Helvetica', 10, 'bold'))
            name_label.pack(anchor='w')
            ttk.Label(item_container, text=self.loc.get('module_author_label', author=author, fallback=f"Oleh: {author}"), style='TLabel', font=('Helvetica', 8, 'italic')).pack(anchor='w', padx=5)
            ttk.Label(item_container, text=description, style='TLabel', wraplength=400, justify='left').pack(anchor='w', pady=(5, 5))
            if download_url:
                install_button = ttk.Button(item_container, text=self.loc.get('install_button', fallback="Instal"), style="success.TButton", command=lambda name=module_name, url=download_url: self.install_online_module(name, url))
                install_button.pack(side='right', pady=5, padx=5)
            else:
                ttk.Label(item_container, text=self.loc.get('download_link_missing', fallback="Link download tidak tersedia."), style='Permissions.TLabel').pack(side='right', pady=5, padx=5)

    def install_online_module(self, module_name, download_url):
        print(f"[DEBUG - UI Thread] Memulai install_online_module untuk '{module_name}'.")
        self.kernel.write_to_log(f"DEBUG: Proses instalasi modul '{module_name}' dimulai.", "DEBUG")
        try:
            actual_module_folder_name = os.path.splitext(os.path.basename(download_url).replace(".zip", ""))[0]
            if not actual_module_folder_name:
                self.kernel.write_to_log(self.loc.get('module_invalid_download_url', name=module_name, url=download_url, fallback=f"URL unduh modul '{module_name}' tidak valid: {download_url}"), "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('module_install_failed_invalid_url', name=module_name, fallback=f"Gagal menginstal modul '{module_name}': URL unduh tidak valid.")))
                return
            if not messagebox.askyesno(self.loc.get('confirm_install_title', fallback="Konfirmasi Instalasi"), self.loc.get('confirm_install_module_message', name=module_name, fallback=f"Apakah Anda yakin ingin menginstal modul '{module_name}'?")):
                print(f"[DEBUG - UI Thread] Instalasi '{module_name}' dibatalkan oleh pengguna.")
                self.kernel.write_to_log(f"DEBUG: Instalasi modul '{module_name}' dibatalkan.", "DEBUG")
                return
            def _install():
                print(f"[DEBUG - Install Thread] Thread instalasi dimulai untuk '{module_name}'.")
                self.kernel.write_to_log(f"DEBUG: Thread instalasi untuk '{module_name}' dimulai.", "DEBUG")
                temp_zip_file = None
                temp_extract_dir = None
                module_target_dir = None
                try:
                    self.kernel.write_to_log(self.loc.get('log_downloading_module', name=module_name, url=download_url, fallback=f"Mengunduh modul '{module_name}' dari {download_url}..."), "INFO")
                    response = requests.get(download_url, stream=True, timeout=30)
                    response.raise_for_status()
                    temp_zip_file = os.path.join(self.kernel.data_path, f"temp_module_{uuid.uuid4()}.zip")
                    with open(temp_zip_file, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=8192): f.write(chunk)
                    temp_extract_dir = os.path.join(self.kernel.data_path, f"temp_extract_{uuid.uuid4()}")
                    os.makedirs(temp_extract_dir, exist_ok=True)
                    with zipfile.ZipFile(temp_zip_file, 'r') as zip_ref:
                        zip_ref.extractall(temp_extract_dir)
                    extracted_contents = os.listdir(temp_extract_dir)
                    source_module_folder_path = temp_extract_dir
                    if len(extracted_contents) == 1 and os.path.isdir(os.path.join(temp_extract_dir, extracted_contents[0])):
                        source_module_folder_path = os.path.join(temp_extract_dir, extracted_contents[0])
                        if os.path.basename(source_module_folder_path) != actual_module_folder_name:
                            self.kernel.write_to_log(self.loc.get('zip_folder_name_mismatch', name_in_zip=os.path.basename(source_module_folder_path), expected_name=actual_module_folder_name, fallback=f"WARN: Nama folder dalam ZIP '{os.path.basename(source_module_folder_path)}' tidak cocok dengan ID modul yang diharapkan '{actual_module_folder_name}'. Lanjutkan..."), "WARN")
                    module_target_dir = os.path.join(self.kernel.modules_path, actual_module_folder_name)
                    if os.path.exists(module_target_dir):
                        self.kernel.write_to_log(self.loc.get('module_folder_exists_warning', name=actual_module_folder_name, fallback=f"Folder modul '{actual_module_folder_name}' sudah ada. Menimpa..."), "WARN")
                        shutil.rmtree(module_target_dir)
                    shutil.move(source_module_folder_path, module_target_dir)
                    if not os.path.exists(os.path.join(module_target_dir, 'manifest.json')):
                        raise Exception(self.loc.get('manifest_not_found_after_extract', name=module_name, fallback=f"File manifest.json tidak ditemukan setelah ekstraksi modul '{module_name}'. Instalasi gagal."))
                    self.kernel.write_to_log(self.loc.get('log_module_installed_success', name=module_name, fallback=f"Modul '{module_name}' berhasil diinstal!"), "SUCCESS")
                    if self.kernel.root and hasattr(self.kernel.root, 'after'):
                        self.kernel.root.after(0, lambda: messagebox.showinfo(self.loc.get('success_title', fallback="Berhasil"), self.loc.get('module_installed_success_popup', name=module_name, fallback=f"Modul '{module_name}' berhasil diinstal!\nAplikasi akan memuat ulang modul.")))
                    self.kernel.reload_modules()
                    if self.kernel.root and hasattr(self.kernel.root, 'after'):
                        self.kernel.root.after(0, self.installed_modules_tab.refresh_content)
                        self.kernel.root.after(0, self.fetch_and_populate_modules)
                except requests.exceptions.RequestException as e:
                    full_traceback = traceback.format_exc()
                    error_msg_detail = str(e)
                    print(f"[ERROR - Install Thread] Gagal mengunduh '{module_name}': {error_msg_detail}\n{full_traceback}")
                    self.kernel.write_to_log(f"ERROR: Gagal mengunduh '{module_name}': {error_msg_detail}\nTraceback:\n{full_traceback}", "ERROR")
                    error_msg_for_user = self.loc.get('module_download_failed', name=module_name, error=error_msg_detail, fallback=f"Gagal mengunduh '{module_name}': {error_msg_detail}\nPeriksa koneksi internet.")
                    if self.kernel.root and hasattr(self.kernel.root, 'after'):
                        self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg_for_user))
                except zipfile.BadZipFile:
                    error_msg = self.loc.get('module_zip_corrupt', name=module_name, fallback=f"File '{module_name}' yang diunduh rusak atau bukan file ZIP yang valid.")
                    self.kernel.write_to_log(error_msg, "ERROR")
                    if self.kernel.root and hasattr(self.kernel.root, 'after'):
                        self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg))
                except Exception as e:
                    full_traceback = traceback.format_exc()
                    error_msg_detail = str(e)
                    print(f"[ERROR - Install Thread] Gagal menginstal '{module_name}' (umum): {error_msg_detail}\n{full_traceback}")
                    self.kernel.write_to_log(f"ERROR: Gagal menginstal '{module_name}' (umum): {error_msg_detail}\nTraceback:\n{full_traceback}", "ERROR")
                    error_msg = self.loc.get('module_install_failed', name=module_name, error=error_msg_detail, fallback=f"Gagal menginstal '{module_name}': {error_msg_detail}")
                    if self.kernel.root and hasattr(self.kernel.root, 'after'):
                        self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg))
                finally:
                    if temp_zip_file and os.path.exists(temp_zip_file):
                        try:
                            os.remove(temp_zip_file)
                            self.kernel.write_to_log(f"Membersihkan file ZIP temporer: {temp_zip_file}", "DEBUG")
                        except Exception as clean_e:
                            self.kernel.write_to_log(f"Gagal membersihkan file temporer: {temp_zip_file} - {clean_e}", "WARN")
                    if temp_extract_dir and os.path.exists(temp_extract_dir):
                        try:
                            shutil.rmtree(temp_extract_dir)
                            self.kernel.write_to_log(f"Membersihkan folder ekstraksi temporer: {temp_extract_dir}", "DEBUG")
                        except Exception as clean_e:
                            self.kernel.write_to_log(f"Gagal membersihkan folder temporer: {temp_extract_dir} - {clean_e}", "WARN")
            try:
                threading.Thread(target=_install, daemon=True).start()
                self.kernel.write_to_log(f"DEBUG: Installer untuk modul '{module_name}' berhasil dijadwalkan.", "DEBUG")
            except Exception as e:
                full_traceback = traceback.format_exc()
                error_msg_detail = str(e)
                print(f"CRITICAL ERROR: Gagal memulai proses instalasi modul '{module_name}': {error_msg_detail}\n{full_traceback}")
                self.kernel.write_to_log(f"CRITICAL ERROR: Gagal memulai instalasi modul '{module_name}': {error_msg_detail}\nTraceback:\n{full_traceback}", "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('module_install_failed_generic', name=module_name, error=error_msg_detail, fallback=f"Terjadi kesalahan saat memulai instalasi modul '{module_name}': {error_msg_detail}")))
        except Exception as e:
            full_traceback = traceback.format_exc()
            error_msg_detail = str(e)
            print(f"CRITICAL ERROR: Error tak terduga di install_online_module (Main UI Thread) untuk '{module_name}': {error_msg_detail}\n{full_traceback}")
            self.kernel.write_to_log(f"CRITICAL ERROR: Error di UI Thread saat instalasi '{module_name}': {error_msg_detail}\nTraceback:\n{full_traceback}", "ERROR")
            if self.kernel.root and hasattr(self.kernel.root, 'after'):
                self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('module_install_failed_generic', name=module_name, error=error_msg_detail, fallback=f"Terjadi kesalahan saat menginstal modul '{module_name}': {error_msg_detail}")))

class ModuleManagerPage(ttk.Frame):
    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, style='TFrame')
        self.kernel = kernel_instance
        self.loc = self.kernel.loc
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(expand=True, fill="both", padx=10, pady=10)
        self.installed_modules_tab = InstalledModulesTab(self.notebook, self.kernel)
        self.discover_modules_tab = DiscoverModulesTab(self.notebook, self.kernel, self.installed_modules_tab)
        self.notebook.add(self.installed_modules_tab, text=self.loc.get('installed_modules_tab_title', fallback="Modul Terinstal"))
        self.notebook.add(self.discover_modules_tab, text=self.loc.get('discover_modules_tab_title', fallback="Temukan Modul"))
        self.notebook.bind("<<NotebookTabChanged>>", self._on_tab_change)
        self.apply_styles(self.kernel.theme_manager.get_colors())

    def _on_tab_change(self, event):
        selected_tab_id = self.notebook.select()
        selected_tab = self.notebook.nametowidget(selected_tab_id)
        if hasattr(selected_tab, 'refresh_content'):
            selected_tab.refresh_content()

    def apply_styles(self, colors):
        style = tk_ttk.Style(self)
        style.configure('TFrame', background=colors.get('bg'))
        style.configure('TNotebook', background=colors.get('bg'), borderwidth=0)
        style.configure('TNotebook.Tab', background=colors.get('dark'), foreground=colors.get('fg'), padding=[10, 5], font=('Helvetica', 10, 'bold'))
        style.map('TNotebook.Tab', background=[('selected', colors.get('primary'))], foreground=[('selected', colors.get('success'))])
        self.installed_modules_tab.apply_styles(colors)
        self.discover_modules_tab.apply_styles(colors)

    def refresh_content(self):
        selected_tab_id = self.notebook.select()
        selected_tab = self.notebook.nametowidget(selected_tab_id)
        if hasattr(selected_tab, 'refresh_content'):
            selected_tab.refresh_content()
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################