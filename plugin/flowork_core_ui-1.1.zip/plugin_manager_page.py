####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import ttk as tk_ttk, messagebox, filedialog, StringVar
import os
import shutil
import platform
import subprocess
import requests
import zipfile
import io
import threading
import uuid
import traceback
from flowork_kernel.ui_shell.custom_widgets.tooltip import ToolTip
from ttkbootstrap.scrolled import ScrolledFrame


class InstalledPluginsTab(ttk.Frame):
    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, style='TFrame')
        self.kernel = kernel_instance
        self.loc = self.kernel.loc
        self.search_var = StringVar()
        self.search_var.trace_add("write", self._on_search)
        self.create_widgets()
        self.apply_styles(self.kernel.theme_manager.get_colors())
        self.refresh_content()

    def apply_styles(self, colors):
        style = tk_ttk.Style(self)
        style.configure('TFrame', background=colors.get('bg'))
        style.configure('TLabel', background=colors.get('bg'), foreground=colors.get('fg'))
        style.configure('TLabelframe', background=colors.get('bg'), borderwidth=1, relief='solid', bordercolor=colors.get('border'))
        style.configure('TLabelframe.Label', background=colors.get('bg'), foreground=colors.get('fg'), font=('Helvetica', 11, 'bold'))
        style.configure('Paused.TLabel', background=colors.get('bg'), foreground=colors.get('secondary'))
        style.configure('Permissions.TLabel', background=colors.get('bg'), foreground=colors.get('warning'), font=('Helvetica', 7, 'italic'))

    def create_widgets(self):
        main_container_frame = ttk.Frame(self, padding=20, style='TFrame')
        main_container_frame.pack(fill="both", expand=True)
        plugin_frame = ttk.LabelFrame(main_container_frame, text=self.loc.get('plugin_management_title', fallback="Manajemen Plugin"), padding=15, style='TLabelframe')
        plugin_frame.pack(fill="both", expand=True, pady=(0, 20))
        top_bar_frame = ttk.Frame(plugin_frame, style='TFrame')
        top_bar_frame.pack(fill='x', pady=5)

        upload_button = ttk.Button(top_bar_frame, text=self.loc.get('upload_plugin_button', fallback="Unggah Plugin"), command=self._upload_and_install_feature, style="success.TButton")
        upload_button.pack(side="left")

        search_frame = ttk.Frame(top_bar_frame, style='TFrame')
        search_frame.pack(side="right", fill='x', expand=True, padx=(10, 0))
        search_frame.columnconfigure(1, weight=1)
        search_icon_label = ttk.Label(search_frame, text="", font=("Font Awesome 6 Free Solid", 9), style='TLabel')
        search_icon_label.grid(row=0, column=0, padx=(0, 5))
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        search_entry.grid(row=0, column=1, sticky="ew")
        ToolTip(search_entry).update_text(self.loc.get('tooltip_search_installed_plugins', fallback="Ketik untuk mencari plugin terinstal...")) # Update tooltip

        scrolled_frame_container = ttk.Frame(plugin_frame, style='TFrame')
        scrolled_frame_container.pack(fill='both', expand=True, pady=(10,0))
        self.plugin_list_frame = ScrolledFrame(scrolled_frame_container, autohide=True)
        self.plugin_list_frame.pack(fill='both', expand=True)

    def refresh_content(self):
        self.populate_plugin_list()

    def _on_search(self, *args):
        self.populate_plugin_list()

    def populate_plugin_list(self):
        for widget in self.plugin_list_frame.winfo_children():
            widget.destroy()
        filter_text = self.search_var.get().lower()
        all_items = self.kernel.module_manager.loaded_modules
        sorted_items = sorted(all_items.items(), key=lambda item: item[1]['manifest'].get('name', item[0]).lower())
        plugin_found = False
        for item_id, item_data in sorted_items:
            if item_data.get('installed_as') != 'plugin':
                continue

            manifest = item_data.get('manifest', {})

            raw_name = manifest.get('name', item_id)
            raw_description = manifest.get('description', '')

            display_name = self.loc.get(raw_name[4:], fallback=raw_name) if raw_name.startswith('loc.') else raw_name
            display_description = self.loc.get(raw_description[4:], fallback=raw_description) if raw_description.startswith('loc.') else raw_description

            if filter_text and not (filter_text in display_name.lower() or
                                    filter_text in display_description.lower() or
                                    filter_text in item_id.lower()):
                continue

            plugin_found = True
            item_container = ttk.Frame(self.plugin_list_frame, style='TFrame')
            item_container.pack(fill='x', pady=2)
            item_frame = ttk.Frame(item_container, style='TFrame')
            item_frame.pack(fill='x')
            is_paused = self.kernel.module_manager.is_module_paused(item_id)
            label_style = "Paused.TLabel" if is_paused else "TLabel"
            paused_prefix = self.loc.get('paused_prefix', fallback="[DIJEDA] ") if is_paused else ""

            label = ttk.Label(item_frame, text=f"{paused_prefix}{display_name} ({item_id})", style=label_style)
            label.pack(side='left', padx=5)

            if display_description:
                ttk.Label(item_container, text=display_description, style='TLabel', wraplength=400, justify='left').pack(anchor='w', padx=15, pady=(0,5))

            buttons_frame = ttk.Frame(item_frame, style='TFrame')
            buttons_frame.pack(side='right', padx=5)
            if is_paused:
                toggle_button = ttk.Button(buttons_frame, text=self.loc.get('resume_button', fallback="Lanjutkan"), style="success-link", width=2, command=lambda mid=item_id: self.toggle_plugin_pause(mid, False))
                ToolTip(toggle_button).update_text(self.loc.get('tooltip_resume_plugin', fallback="Lanjutkan plugin ini."))
            else:
                toggle_button = ttk.Button(buttons_frame, text=self.loc.get('pause_button', fallback="Jeda"), style="warning-link", width=2, command=lambda mid=item_id: self.toggle_plugin_pause(mid, True))
                ToolTip(toggle_button).update_text(self.loc.get('tooltip_pause_plugin', fallback="Jeda plugin ini agar tidak dimuat saat aplikasi dimulai."))
            toggle_button.pack(side='right', padx=2)
            edit_button = ttk.Button(buttons_frame, text=self.loc.get('edit_button', fallback="Edit"), style="info-link", width=2, command=lambda path=item_data.get('path'): self._open_path_in_explorer(path))
            ToolTip(edit_button).update_text(self.loc.get('tooltip_edit_plugin', fallback="Buka folder plugin."))
            edit_button.pack(side='right', padx=2)
            delete_button = ttk.Button(buttons_frame, text=self.loc.get('uninstall_button', fallback="Hapus"), style="danger-link", width=2, command=lambda mid=item_id, mname=display_name: self.uninstall_plugin(mid, mname))
            ToolTip(delete_button).update_text(self.loc.get('tooltip_delete_plugin', fallback="Hapus plugin ini."))
            delete_button.pack(side='right', padx=2)
            permissions = self.kernel.module_manager.get_module_permissions(item_id)
            if permissions:
                permission_frame = ttk.Frame(item_container, style='TFrame')
                permission_frame.pack(fill='x', padx=(15, 0), pady=(0, 5))
                perm_string = ", ".join(permissions)
                perm_label = ttk.Label(permission_frame, text=self.loc.get('permissions_label', perm_string=perm_string, fallback=f"Izin: {perm_string}"), style='Permissions.TLabel')
                perm_label.pack(anchor='w')
        if not plugin_found:
            ttk.Label(self.plugin_list_frame, text=self.loc.get('no_plugins_installed_message', fallback="Tidak ada plugin yang terinstal.")).pack(pady=20)

    def _open_path_in_explorer(self, path):
        if not path: return
        try:
            if platform.system() == "Windows": os.startfile(path)
            elif platform.system() == "Darwin": subprocess.Popen(["open", path])
            else: subprocess.Popen(["xdg-open", path])
        except Exception as e:
            messagebox.showerror(self.loc.get('error_title', fallback="Error"), self.loc.get('log_failed_to_open_folder', path=path, error=str(e), fallback=f"Tidak dapat membuka folder: {path}\n{e}"))

    def toggle_plugin_pause(self, plugin_id, should_pause):
        raw_name = self.kernel.module_manager.get_manifest(plugin_id).get('name', plugin_id)
        display_name = self.loc.get(raw_name[4:], fallback=raw_name) if raw_name.startswith('loc.') else raw_name
        if self.kernel.module_manager.set_module_paused(plugin_id, should_pause):
            if should_pause:
                self.kernel.write_to_log(self.loc.get('plugin_paused_message', name=display_name, fallback=f"Plugin '{display_name}' dijeda."), "WARN")
            else:
                self.kernel.write_to_log(self.loc.get('plugin_resumed_message', name=display_name, fallback=f"Plugin '{display_name}' dilanjutkan."), "SUCCESS")
        self.populate_plugin_list()

    def uninstall_plugin(self, plugin_id, plugin_name):
        if messagebox.askyesno(self.loc.get('confirm_delete_title', fallback="Konfirmasi Hapus"), self.loc.get('confirm_delete_plugin_message', name=plugin_name, fallback=f"Apakah Anda yakin ingin menghapus '{plugin_name}' secara permanen?")):
            try:
                item_data = self.kernel.module_manager.loaded_modules.get(plugin_id)
                if item_data and 'path' in item_data:
                    shutil.rmtree(item_data['path'])
                    messagebox.showinfo(self.loc.get('success_title', fallback="Sukses"), self.loc.get('plugin_deleted_success_message', name=plugin_name, fallback=f"'{plugin_name}' berhasil dihapus."))
                    self.kernel.reload_modules()
                else:
                    raise FileNotFoundError(self.loc.get('plugin_path_not_found', fallback="Path plugin tidak ditemukan."))
            except Exception as e:
                messagebox.showerror(self.loc.get('error_title', fallback="Error"), self.loc.get('plugin_delete_failed_error', name=plugin_name, error=str(e), fallback=f"Gagal menghapus '{plugin_name}':\n{e}"))

    def _upload_and_install_feature(self):
        filepath = filedialog.askopenfilename(title=self.loc.get('select_plugin_file_title', fallback="Pilih File Plugin (.zip)"), filetypes=[(self.loc.get('zip_files_label', fallback="File ZIP"), "*.zip")])
        if not filepath: return
        plugin_name = os.path.splitext(os.path.basename(filepath))[0]
        if not messagebox.askyesno(self.loc.get('confirm_upload_title', fallback="Konfirmasi Unggah"), self.loc.get('confirm_upload_plugin_message', name=plugin_name, fallback=f"Apakah Anda yakin ingin mengunggah dan menginstal plugin '{plugin_name}'?")):
            return
        def _upload_and_install():
            plugin_target_dir = None
            temp_extract_dir = None
            try:
                self.kernel.write_to_log(self.loc.get('log_uploading_plugin', name=plugin_name, fallback=f"Mengunggah dan menginstal plugin '{plugin_name}'..."), "INFO")
                temp_extract_dir = os.path.join(self.kernel.data_path, f"temp_plugin_upload_extract_{uuid.uuid4()}")
                os.makedirs(temp_extract_dir, exist_ok=True)
                with zipfile.ZipFile(filepath, 'r') as zip_ref:
                    zip_ref.extractall(temp_extract_dir)
                extracted_contents = os.listdir(temp_extract_dir)
                source_plugin_folder_path = temp_extract_dir
                if len(extracted_contents) == 1 and os.path.isdir(os.path.join(temp_extract_dir, extracted_contents[0])):
                    source_plugin_folder_path = os.path.join(temp_extract_dir, extracted_contents[0])
                    if os.path.basename(source_plugin_folder_path) != plugin_name:
                        self.kernel.write_to_log(self.loc.get('zip_folder_name_mismatch', name_in_zip=os.path.basename(source_plugin_folder_path), expected_name=plugin_name, fallback=f"WARN: Nama folder dalam ZIP '{os.path.basename(source_plugin_folder_path)}' tidak cocok dengan ID plugin yang diharapkan '{plugin_name}'. Lanjutkan..."), "WARN")
                plugin_target_dir = os.path.join(self.kernel.plugins_path, plugin_name)
                if os.path.exists(plugin_target_dir):
                    self.kernel.write_to_log(self.loc.get('plugin_folder_exists_warning', name=plugin_name, fallback=f"Folder plugin '{plugin_name}' sudah ada. Menimpa..."), "WARN")
                    shutil.rmtree(plugin_target_dir)
                shutil.move(source_plugin_folder_path, plugin_target_dir)
                if not os.path.exists(os.path.join(plugin_target_dir, 'manifest.json')):
                    raise Exception(self.loc.get('manifest_not_found_after_extract_plugin', name=plugin_name, fallback=f"File manifest.json tidak ditemukan setelah ekstraksi plugin '{plugin_name}'. Instalasi gagal."))
                self.kernel.write_to_log(self.loc.get('log_plugin_uploaded_success', name=plugin_name, fallback=f"Plugin '{plugin_name}' berhasil diunggah dan diinstal!"), "SUCCESS")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showinfo(self.loc.get('success_title', fallback="Berhasil"), self.loc.get('plugin_uploaded_success_popup', name=plugin_name, fallback=f"Plugin '{plugin_name}' berhasil diunggah dan diinstal!\nAplikasi akan memuat ulang plugin.")))
                self.kernel.reload_modules()
            except zipfile.BadZipFile:
                error_msg = self.loc.get('plugin_zip_corrupt_upload', name=plugin_name, fallback=f"File '{filepath}' bukan file ZIP yang valid atau rusak.")
                self.kernel.write_to_log(error_msg, "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg))
            except Exception as e:
                full_traceback = traceback.format_exc()
                error_msg_detail = str(e)
                error_msg = self.loc.get('plugin_upload_failed', name=plugin_name, error=error_msg_detail, fallback=f"Gagal mengunggah atau menginstal '{plugin_name}': {error_msg_detail}")
                self.kernel.write_to_log(f"ERROR: {error_msg}\nTraceback:\n{full_traceback}", "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg))
            finally:
                if temp_extract_dir and os.path.exists(temp_extract_dir):
                    try:
                        shutil.rmtree(temp_extract_dir)
                        self.kernel.write_to_log(f"Membersihkan folder ekstraksi temporer: {temp_extract_dir}", "DEBUG")
                    except Exception as clean_e:
                        self.kernel.write_to_log(f"Gagal membersihkan folder temporer: {temp_extract_dir} - {clean_e}", "WARN")
        threading.Thread(target=_upload_and_install, daemon=True).start()

class DiscoverPluginsTab(ttk.Frame):
    GITHUB_PLUGINS_URL = "https://raw.githubusercontent.com/flowork-dev/plugin/refs/heads/main/top_plugin.json"
    def __init__(self, parent_notebook, kernel_instance, installed_plugins_tab_instance):
        super().__init__(parent_notebook, style='TFrame')
        self.kernel = kernel_instance
        self.loc = self.kernel.loc
        self.installed_plugins_tab = installed_plugins_tab_instance
        self.search_var = StringVar()
        self.search_var.trace_add("write", self._on_search)
        self.online_plugins_data = []
        self.create_widgets()
        self.apply_styles(self.kernel.theme_manager.get_colors())
        self.fetch_and_populate_plugins()

    def apply_styles(self, colors):
        style = tk_ttk.Style(self)
        style.configure('TFrame', background=colors.get('bg'))
        style.configure('TLabel', background=colors.get('bg'), foreground=colors.get('fg'))
        style.configure('Installable.TLabel', background=colors.get('bg'), foreground=colors.get('info'))
        style.configure('Permissions.TLabel', background=colors.get('bg'), foreground=colors.get('warning'), font=('Helvetica', 7, 'italic'))

    def create_widgets(self):
        main_frame = ttk.Frame(self, padding=15, style='TFrame')
        main_frame.pack(fill="both", expand=True)
        search_frame = ttk.Frame(main_frame, style='TFrame')
        search_frame.pack(fill='x', pady=5)
        search_frame.columnconfigure(1, weight=1)
        search_icon_label = ttk.Label(search_frame, text="", font=("Font Awesome 6 Free Solid", 9), style='TLabel')
        search_icon_label.grid(row=0, column=0, padx=(0, 5))
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        search_entry.grid(row=0, column=1, sticky="ew")
        ToolTip(search_entry).update_text(self.loc.get('tooltip_search_online_plugins', fallback="Ketik untuk mencari plugin online..."))
        self.plugin_list_frame = ScrolledFrame(main_frame, autohide=True)
        self.plugin_list_frame.pack(fill='both', expand=True, pady=(10,0))

    def _on_search(self, *args):
        self.populate_online_plugin_list()

    def refresh_content(self):
        self.fetch_and_populate_plugins()

    def fetch_and_populate_plugins(self):
        def _fetch():
            self.online_plugins_data = self.fetch_online_plugins_data()
            if self.kernel.root and hasattr(self.kernel.root, 'after'):
                self.kernel.root.after(0, self.populate_online_plugin_list)
        threading.Thread(target=_fetch, daemon=True).start()

    def fetch_online_plugins_data(self):
        try:
            self.kernel.write_to_log(self.loc.get('log_fetching_online_plugins', fallback="Mengambil daftar plugin dari GitHub..."), "INFO")
            response = requests.get(self.GITHUB_PLUGINS_URL, timeout=10)
            response.raise_for_status()
            data = response.json()
            installed_ids = {pid for pid, pdata in self.kernel.module_manager.loaded_modules.items() if pdata.get('installed_as') == 'plugin'}
            filtered_data = [
                plugin for plugin in data if plugin.get('name') not in installed_ids and
                os.path.splitext(os.path.basename(plugin.get('download_url', '')).replace(".zip", ""))[0] not in installed_ids
            ]
            self.kernel.write_to_log(self.loc.get('log_fetched_online_plugins', count=len(filtered_data), fallback=f"Berhasil mengambil {len(filtered_data)} plugin dari GitHub."), "SUCCESS")
            return filtered_data
        except requests.exceptions.RequestException as e:
            self.kernel.write_to_log(self.loc.get('log_fetch_online_plugins_error', error=str(e), fallback=f"Gagal mengambil daftar plugin dari GitHub: {e}"), "ERROR")
            if self.kernel.root and hasattr(self.kernel.root, 'after'):
                self.kernel.root.after(0, lambda err=e: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('fetch_plugins_error_popup', error=str(err), fallback=f"Gagal mengambil daftar plugin dari GitHub: {err}\nPastikan koneksi internet Anda berfungsi.")))
            return []
        except ValueError as e:
            self.kernel.write_to_log(self.loc.get('log_parse_online_plugins_error', error=str(e), fallback=f"Gagal mengurai data plugin dari GitHub: {e}"), "ERROR")
            if self.kernel.root and hasattr(self.kernel.root, 'after'):
                self.kernel.root.after(0, lambda err=e: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('parse_plugins_error_popup', error=str(err), fallback=f"Gagal mengurai data plugin dari GitHub: {err}\nFormat JSON mungkin tidak valid.")))
            return []

    def populate_online_plugin_list(self):
        for widget in self.plugin_list_frame.winfo_children():
            widget.destroy()
        filter_text = self.search_var.get().lower()
        plugins_to_display = sorted(
            [p for p in self.online_plugins_data if filter_text in p.get('name', '').lower() or filter_text in p.get('description', '').lower()],
            key=lambda x: x.get('name', '').lower()
        )
        if not plugins_to_display:
            ttk.Label(self.plugin_list_frame, text=self.loc.get('no_online_plugins_found_message', fallback="Tidak ada plugin online yang ditemukan atau semua sudah terinstal."), style='TLabel').pack(pady=20)
            return
        for plugin_info in plugins_to_display:
            plugin_name = plugin_info.get('name', 'Unknown Plugin')
            description = plugin_info.get('description', 'No description available.')
            author = plugin_info.get('author', 'Unknown Author')
            version = plugin_info.get('version', 'N/A')
            download_url = plugin_info.get('download_url')
            item_container = ttk.Frame(self.plugin_list_frame, style='TFrame', borderwidth=1, relief="solid", padding=5)
            item_container.pack(fill='x', pady=5, padx=5)
            name_label = ttk.Label(item_container, text=f"{plugin_name} (v{version})", style='Installable.TLabel', font=('Helvetica', 10, 'bold'))
            name_label.pack(anchor='w')
            ttk.Label(item_container, text=self.loc.get('plugin_author_label', author=author, fallback=f"Oleh: {author}"), style='TLabel', font=('Helvetica', 8, 'italic')).pack(anchor='w', padx=5)
            ttk.Label(item_container, text=description, style='TLabel', wraplength=400, justify='left').pack(anchor='w', pady=(5, 5))
            if download_url:
                install_button = ttk.Button(item_container, text=self.loc.get('install_button', fallback="Instal"), style="success.TButton", command=lambda name=plugin_name, url=download_url: self.install_online_plugin(name, url))
                install_button.pack(side='right', pady=5, padx=5)
            else:
                ttk.Label(item_container, text=self.loc.get('download_link_missing', fallback="Link download tidak tersedia."), style='Permissions.TLabel').pack(side='right', pady=5, padx=5)

    def install_online_plugin(self, plugin_name, download_url):
        actual_plugin_folder_name = os.path.splitext(os.path.basename(download_url).replace(".zip", ""))[0]
        if not actual_plugin_folder_name:
            self.kernel.write_to_log(self.loc.get('plugin_invalid_download_url', name=plugin_name, url=download_url, fallback=f"URL unduh plugin '{plugin_name}' tidak valid: {download_url}"), "ERROR")
            if self.kernel.root and hasattr(self.kernel.root, 'after'):
                self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('plugin_install_failed_invalid_url', name=plugin_name, fallback=f"Gagal menginstal plugin '{plugin_name}': URL unduh tidak valid.")))
            return
        if not messagebox.askyesno(self.loc.get('confirm_install_title', fallback="Konfirmasi Instalasi"), self.loc.get('confirm_install_plugin_message', name=plugin_name, fallback=f"Apakah Anda yakin ingin menginstal plugin '{plugin_name}'?")):
            return
        def _install():
            temp_zip_file = None
            temp_extract_dir = None
            plugin_target_dir = None
            try:
                self.kernel.write_to_log(self.loc.get('log_downloading_plugin', name=plugin_name, url=download_url, fallback=f"Mengunduh plugin '{plugin_name}' dari {download_url}..."), "INFO")
                response = requests.get(download_url, stream=True, timeout=30)
                response.raise_for_status()
                temp_zip_file = os.path.join(self.kernel.data_path, f"temp_plugin_{uuid.uuid4()}.zip")
                with open(temp_zip_file, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                temp_extract_dir = os.path.join(self.kernel.data_path, f"temp_plugin_extract_{uuid.uuid4()}")
                os.makedirs(temp_extract_dir, exist_ok=True)
                with zipfile.ZipFile(temp_zip_file, 'r') as zip_ref:
                    zip_ref.extractall(temp_extract_dir)
                extracted_contents = os.listdir(temp_extract_dir)
                source_plugin_folder_path = temp_extract_dir
                if len(extracted_contents) == 1 and os.path.isdir(os.path.join(temp_extract_dir, extracted_contents[0])):
                    source_plugin_folder_path = os.path.join(temp_extract_dir, extracted_contents[0])
                    if os.path.basename(source_plugin_folder_path) != actual_plugin_folder_name:
                        self.kernel.write_to_log(self.loc.get('zip_folder_name_mismatch_plugin', name_in_zip=os.path.basename(source_plugin_folder_path), expected_name=actual_plugin_folder_name, fallback=f"WARN: Nama folder dalam ZIP '{os.path.basename(source_plugin_folder_path)}' tidak cocok dengan ID plugin yang diharapkan '{actual_plugin_folder_name}'. Lanjutkan..."), "WARN")
                plugin_target_dir = os.path.join(self.kernel.plugins_path, actual_plugin_folder_name)
                if os.path.exists(plugin_target_dir):
                    self.kernel.write_to_log(self.loc.get('plugin_folder_exists_warning', name=actual_plugin_folder_name, fallback=f"Folder plugin '{actual_plugin_folder_name}' sudah ada. Menimpa..."), "WARN")
                    shutil.rmtree(plugin_target_dir)
                shutil.move(source_plugin_folder_path, plugin_target_dir)
                if not os.path.exists(os.path.join(plugin_target_dir, 'manifest.json')):
                    raise Exception(self.loc.get('manifest_not_found_after_extract_plugin', name=plugin_name, fallback=f"File manifest.json tidak ditemukan setelah ekstraksi plugin '{plugin_name}'. Instalasi gagal."))
                self.kernel.write_to_log(self.loc.get('log_plugin_installed_success', name=plugin_name, fallback=f"Plugin '{plugin_name}' berhasil diinstal!"), "SUCCESS")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showinfo(self.loc.get('success_title', fallback="Berhasil"), self.loc.get('plugin_installed_success_popup', name=plugin_name, fallback=f"Plugin '{plugin_name}' berhasil diinstal!\nAplikasi akan memuat ulang plugin.")))
                self.kernel.reload_modules()
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, self.installed_plugins_tab.refresh_content)
                    self.kernel.root.after(0, self.fetch_and_populate_plugins)
            except requests.exceptions.RequestException as e:
                full_traceback = traceback.format_exc()
                error_msg_detail = str(e)
                error_msg_for_user = self.loc.get('plugin_download_failed', name=plugin_name, error=error_msg_detail, fallback=f"Gagal mengunduh '{plugin_name}': {error_msg_detail}\nPeriksa koneksi internet.")
                self.kernel.write_to_log(f"ERROR: {error_msg_for_user}\nTraceback:\n{full_traceback}", "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg_for_user))
            except zipfile.BadZipFile:
                error_msg = self.loc.get('plugin_zip_corrupt', name=plugin_name, fallback=f"File '{plugin_name}' yang diunduh rusak atau bukan file ZIP yang valid.")
                self.kernel.write_to_log(error_msg, "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg))
            except Exception as e:
                full_traceback = traceback.format_exc()
                error_msg_detail = str(e)
                error_msg = self.loc.get('plugin_install_failed', name=plugin_name, error=error_msg_detail, fallback=f"Gagal menginstal '{plugin_name}': {error_msg_detail}")
                self.kernel.write_to_log(f"ERROR: {error_msg}\nTraceback:\n{full_traceback}", "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg))
            finally:
                if temp_zip_file and os.path.exists(temp_zip_file):
                    try:
                        os.remove(temp_zip_file)
                        self.kernel.write_to_log(f"Membersihkan file ZIP temporer: {temp_zip_file}", "DEBUG")
                    except Exception as clean_e:
                        self.kernel.write_to_log(f"Gagal membersihkan file temporer: {temp_zip_file} - {clean_e}", "WARN")
                if temp_extract_dir and os.path.exists(temp_extract_dir):
                    try:
                        shutil.rmtree(temp_extract_dir)
                        self.kernel.write_to_log(f"Membersihkan folder ekstraksi temporer: {temp_extract_dir}", "DEBUG")
                    except Exception as clean_e:
                        self.kernel.write_to_log(f"Gagal membersihkan folder temporer: {temp_extract_dir} - {clean_e}", "WARN")
        threading.Thread(target=_install, daemon=True).start()

class PluginManagerPage(ttk.Frame):
    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, style='TFrame')
        self.kernel = kernel_instance
        self.loc = self.kernel.loc
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(expand=True, fill="both", padx=10, pady=10)
        self.installed_plugins_tab = InstalledPluginsTab(self.notebook, self.kernel)
        self.discover_plugins_tab = DiscoverPluginsTab(self.notebook, self.kernel, self.installed_plugins_tab)
        self.notebook.add(self.installed_plugins_tab, text=self.loc.get('installed_plugins_tab_title', fallback="Plugin Terinstal"))
        self.notebook.add(self.discover_plugins_tab, text=self.loc.get('discover_plugins_tab_title', fallback="Temukan Plugin"))
        self.notebook.bind("<<NotebookTabChanged>>", self._on_tab_change)
        self.apply_styles(self.kernel.theme_manager.get_colors())

    def _on_tab_change(self, event):
        selected_tab_id = self.notebook.select()
        selected_tab = self.notebook.nametowidget(selected_tab_id)
        if hasattr(selected_tab, 'refresh_content'):
            selected_tab.refresh_content()

    def apply_styles(self, colors):
        style = tk_ttk.Style(self)
        style.configure('TFrame', background=colors.get('bg'))
        style.configure('TNotebook', background=colors.get('bg'), borderwidth=0)
        style.configure('TNotebook.Tab', background=colors.get('dark'), foreground=colors.get('fg'), padding=[10, 5], font=('Helvetica', 10, 'bold'))
        style.map('TNotebook.Tab', background=[('selected', colors.get('primary'))], foreground=[('selected', colors.get('success'))])
        self.installed_plugins_tab.apply_styles(colors)
        self.discover_plugins_tab.apply_styles(colors)

    def refresh_content(self):
        selected_tab_id = self.notebook.select()
        selected_tab = self.notebook.nametowidget(selected_tab_id)
        if hasattr(selected_tab, 'refresh_content'):
            selected_tab.refresh_content()
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################