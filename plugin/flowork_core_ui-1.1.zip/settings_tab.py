####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import messagebox, StringVar, BooleanVar, IntVar, filedialog
import os
import json

class SettingsTab(ttk.Frame):
    """
    Kelas yang membangun UI untuk tab Pengaturan utama.
    """
    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, padding=15)
        self.kernel = kernel_instance
        self.loc = self.kernel.loc
        self.variables_data_cache = []

        self._init_variables()
        self._build_ui()
        self._load_settings_to_ui()
        self._load_variables_to_ui()

    def _init_variables(self):
        """Inisialisasi semua variabel Tkinter."""
        self.lang_var = StringVar()
        self.theme_var = StringVar()
        self.webhook_enabled_var = BooleanVar()
        self.webhook_port_var = StringVar()
        self.error_handler_enabled_var = BooleanVar()
        self.error_handler_preset_var = StringVar()
        self.notifications_enabled_var = BooleanVar()
        self.notifications_duration_var = StringVar()
        self.notifications_position_var = StringVar()
        self.git_remote_url_var = StringVar()

    def _build_ui(self):
        """Membangun semua frame dan widget di dalam tab."""
        paned_window = ttk.PanedWindow(self, orient='horizontal')
        paned_window.pack(fill='both', expand=True)

        left_frame = ttk.Frame(paned_window, padding=5)
        paned_window.add(left_frame, weight=1)

        right_frame = ttk.Frame(paned_window, padding=5)
        paned_window.add(right_frame, weight=1)

        self._build_left_panel(left_frame)
        self._build_right_panel(right_frame)

    def _build_left_panel(self, parent_frame):
        """Membangun panel kiri yang berisi semua pengaturan."""
        general_frame = ttk.LabelFrame(parent_frame, text=self.loc.get("settings_general_title", fallback="Pengaturan Umum"), padding=15)
        general_frame.pack(fill="x", pady=5, padx=5)
        self._build_general_settings_ui(general_frame)

        webhook_frame = ttk.LabelFrame(parent_frame, text=self.loc.get("settings_webhook_title", fallback="Pengaturan Webhook"), padding=15)
        webhook_frame.pack(fill="x", pady=5, padx=5)
        self._build_webhook_settings_ui(webhook_frame)

        notification_frame = ttk.LabelFrame(parent_frame, text=self.loc.get("settings_notifications_title", fallback="Pengaturan Notifikasi Popup"), padding=15)
        notification_frame.pack(fill="x", pady=5, padx=5)
        self._build_notification_settings_ui(notification_frame)

        license_frame = ttk.LabelFrame(parent_frame, text=self.loc.get("settings_license_title", fallback="Manajemen Lisensi"), padding=15)
        license_frame.pack(fill="x", pady=5, padx=5)
        self._build_license_management_ui(license_frame)

        git_settings_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('settings_git_title', fallback="Pengaturan Git untuk Preset"), padding=15)
        git_settings_frame.pack(fill='x', expand=False, pady=(5, 0), padx=5)
        self._build_git_settings_ui(git_settings_frame)

        error_handler_frame = ttk.LabelFrame(parent_frame, text=self.loc.get("settings_error_handler_title", fallback="Pengaturan Error Handler Global"), padding=15)
        error_handler_frame.pack(fill="x", pady=5, padx=5, expand=False, anchor="n")
        self._build_error_handler_ui(error_handler_frame)

        save_button = ttk.Button(parent_frame, text=self.loc.get("settings_save_button", fallback="Simpan Semua Pengaturan"), command=self._save_all_settings, bootstyle="success")
        save_button.pack(pady=20, padx=5, side="bottom", anchor="e")

    def _build_right_panel(self, parent_frame):
        """Membangun panel kanan untuk manajemen variabel."""
        variables_frame = ttk.LabelFrame(parent_frame, text=self.loc.get("settings_variables_title", fallback="Manajemen Variabel & Secret"), padding=15)
        variables_frame.pack(fill="both", expand=True, pady=5, padx=5)
        self._build_variables_ui(variables_frame)

    def _build_general_settings_ui(self, parent_frame):
        lang_label = ttk.Label(parent_frame, text=self.loc.get("settings_language_label", fallback="Bahasa Antarmuka:"))
        lang_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        lang_combo = ttk.Combobox(parent_frame, textvariable=self.lang_var, values=self.loc.get_available_languages_display(), state="readonly")
        lang_combo.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        theme_label = ttk.Label(parent_frame, text=self.loc.get("settings_theme_label", fallback="Tema Aplikasi:"))
        theme_label.grid(row=1, column=0, padx=5, pady=5, sticky="w")
        theme_combo = ttk.Combobox(parent_frame, textvariable=self.theme_var, values=[d['name'] for d in self.kernel.theme_manager.loaded_themes.values()], state="readonly")
        theme_combo.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        parent_frame.columnconfigure(1, weight=1)

    def _build_webhook_settings_ui(self, parent_frame):
        webhook_check = ttk.Checkbutton(parent_frame, text=self.loc.get("settings_webhook_enable_label", fallback="Aktifkan Server Webhook/API"), variable=self.webhook_enabled_var)
        webhook_check.grid(row=0, column=0, columnspan=2, padx=5, pady=5, sticky="w")

        port_label = ttk.Label(parent_frame, text=self.loc.get("settings_webhook_port_label", fallback="Port Server:"))
        port_label.grid(row=1, column=0, padx=5, pady=5, sticky="w")
        port_entry = ttk.Entry(parent_frame, textvariable=self.webhook_port_var, width=10)
        port_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")

    def _build_error_handler_ui(self, parent_frame):
        enabled_check = ttk.Checkbutton(parent_frame, text=self.loc.get("settings_error_handler_enable_label", fallback="Aktifkan Penangan Error Global"), variable=self.error_handler_enabled_var)
        enabled_check.grid(row=0, column=0, columnspan=2, padx=5, pady=5, sticky="w")

        preset_label = ttk.Label(parent_frame, text=self.loc.get("settings_error_handler_preset_label", fallback="Pilih Preset Penangan Error:"))
        preset_label.grid(row=1, column=0, padx=5, pady=5, sticky="w")

        preset_list = [""] + self.kernel.preset_manager.get_preset_list()
        preset_combo = ttk.Combobox(parent_frame, textvariable=self.error_handler_preset_var, values=preset_list, state="readonly")
        preset_combo.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        parent_frame.columnconfigure(1, weight=1)

    def _build_notification_settings_ui(self, parent_frame):
        """Membangun UI untuk pengaturan Notifikasi Popup."""
        enabled_check = ttk.Checkbutton(parent_frame, text=self.loc.get("settings_notifications_enable_label", fallback="Aktifkan Notifikasi Popup"), variable=self.notifications_enabled_var)
        enabled_check.grid(row=0, column=0, columnspan=2, padx=5, pady=5, sticky="w")

        duration_label = ttk.Label(parent_frame, text=self.loc.get("settings_notifications_duration_label", fallback="Durasi Tampil (detik):"))
        duration_label.grid(row=1, column=0, padx=5, pady=5, sticky="w")
        duration_entry = ttk.Entry(parent_frame, textvariable=self.notifications_duration_var, width=10)
        duration_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")

        position_label = ttk.Label(parent_frame, text=self.loc.get("settings_notifications_position_label", fallback="Posisi Popup:"))
        position_label.grid(row=2, column=0, padx=5, pady=5, sticky="w")
        position_combo = ttk.Combobox(parent_frame, textvariable=self.notifications_position_var, values=["bottom_right", "top_right", "bottom_left", "top_left"], state="readonly")
        position_combo.grid(row=2, column=1, padx=5, pady=5, sticky="w")

    def _build_license_management_ui(self, parent_frame):
        """Membangun UI untuk Manajemen Lisensi."""
        self.deactivate_button = ttk.Button(parent_frame, text=self.loc.get("settings_license_deactivate_button", fallback="Nonaktifkan Lisensi di Komputer Ini"), command=self._deactivate_license, bootstyle="danger-outline")
        self.deactivate_button.pack(pady=5, padx=5, fill='x')
        self._update_license_ui_state()

    def _build_git_settings_ui(self, parent_frame):
        """Membangun UI untuk konfigurasi Git."""
        remote_url_frame = ttk.Frame(parent_frame)
        remote_url_frame.pack(fill='x', expand=True, pady=(0, 5))

        ttk.Label(remote_url_frame, text=self.loc.get('settings_git_url_label', fallback="URL Remote 'origin':")).pack(side='left', padx=(0, 10))

        ttk.Entry(remote_url_frame, textvariable=self.git_remote_url_var).pack(side='left', fill='x', expand=True)

        git_buttons_frame = ttk.Frame(parent_frame)
        git_buttons_frame.pack(fill='x', expand=True, pady=(5,0))

        init_button = ttk.Button(git_buttons_frame, text=self.loc.get('settings_git_init_button', fallback="Inisialisasi Repo"), command=self._initialize_git_repo, style="info.TButton")
        init_button.pack(side='right')

        save_url_button = ttk.Button(git_buttons_frame, text=self.loc.get('settings_git_save_button', fallback="Simpan URL"), command=self._save_remote_url, style="success.TButton")
        save_url_button.pack(side='right', padx=(0, 5))

    def _build_variables_ui(self, parent_frame):
        parent_frame.columnconfigure(0, weight=1)
        parent_frame.rowconfigure(0, weight=1)

        tree_frame = ttk.Frame(parent_frame)
        tree_frame.grid(row=0, column=0, sticky="nsew", columnspan=3)
        tree_frame.columnconfigure(0, weight=1)
        tree_frame.rowconfigure(0, weight=1)

        columns = ("name", "value")
        self.var_tree = ttk.Treeview(tree_frame, columns=columns, show="headings", height=10)
        self.var_tree.heading("name", text=self.loc.get("settings_variables_col_name", fallback="Nama Variabel"))
        self.var_tree.heading("value", text=self.loc.get("settings_variables_col_value", fallback="Nilai"))
        self.var_tree.column("name", width=150, anchor="w")
        self.var_tree.column("value", width=300, anchor="w")

        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.var_tree.yview)
        hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.var_tree.xview)
        self.var_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.var_tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        button_frame = ttk.Frame(parent_frame)
        button_frame.grid(row=1, column=0, columnspan=3, sticky="ew", pady=(10,0))

        add_button = ttk.Button(button_frame, text=self.loc.get("settings_variables_btn_add", fallback="Tambah"), command=self._add_variable)
        add_button.pack(side="left", padx=2)

        edit_button = ttk.Button(button_frame, text=self.loc.get("settings_variables_btn_edit", fallback="Edit"), command=self._edit_variable, bootstyle="info")
        edit_button.pack(side="left", padx=2)

        delete_button = ttk.Button(button_frame, text=self.loc.get("settings_variables_btn_delete", fallback="Hapus"), command=self._delete_variable, bootstyle="danger")
        delete_button.pack(side="left", padx=2)

        copy_button = ttk.Button(button_frame, text=self.loc.get("settings_variables_action_copy", fallback="[ Salin ]"), command=self._copy_variable_placeholder, bootstyle="secondary-outline")
        copy_button.pack(side="right", padx=2)

    def _load_settings_to_ui(self):
        self.lang_var.set(self.loc.language_map.get(self.loc.get_current_language_code(), "English"))
        self.theme_var.set(self.kernel.theme_manager.loaded_themes.get(self.kernel.theme_manager.active_theme_id, {}).get('name', ''))
        self.webhook_enabled_var.set(self.loc.get_setting("webhook_enabled", False))
        self.webhook_port_var.set(str(self.loc.get_setting("webhook_port", 8989)))
        self.error_handler_enabled_var.set(self.loc.get_setting("global_error_handler_enabled", False))
        self.error_handler_preset_var.set(self.loc.get_setting("global_error_workflow_preset", ""))
        self.notifications_enabled_var.set(self.loc.get_setting("notifications_enabled", True))
        self.notifications_duration_var.set(str(self.loc.get_setting("notifications_duration_seconds", 5)))
        self.notifications_position_var.set(self.loc.get_setting("notifications_position", "bottom_right"))
        self.git_remote_url_var.set(self.kernel.loc.get_setting('git_remote_url', ''))
        self._update_license_ui_state()

    def _load_variables_to_ui(self):
        for item in self.var_tree.get_children():
            self.var_tree.delete(item)
        self.variables_data_cache = self.kernel.variable_manager.get_all_variables_for_ui()
        for var_data in self.variables_data_cache:
            self.var_tree.insert("", "end", values=(var_data["name"], var_data["value"]), tags=('secret' if var_data.get('is_secret') else 'normal',))
        self.var_tree.tag_configure('secret', foreground='orange')

    def _save_all_settings(self):
        try:
            selected_lang_display = self.lang_var.get()
            lang_code_to_save = next((code for code, display in self.loc.language_map.items() if display == selected_lang_display), "id")
            self.loc.set_language(lang_code_to_save)

            selected_theme_name = self.theme_var.get()
            theme_id_to_save = next((tid for tid, data in self.kernel.theme_manager.loaded_themes.items() if data['name'] == selected_theme_name), "flowork_default")
            self.kernel.apply_theme(theme_id_to_save)

            self.loc.save_setting("webhook_enabled", self.webhook_enabled_var.get())
            self.loc.save_setting("webhook_port", int(self.webhook_port_var.get()))

            self.loc.save_setting("global_error_handler_enabled", self.error_handler_enabled_var.get())
            self.loc.save_setting("global_error_workflow_preset", self.error_handler_preset_var.get())

            self.loc.save_setting("notifications_enabled", self.notifications_enabled_var.get())
            self.loc.save_setting("notifications_duration_seconds", int(self.notifications_duration_var.get()))
            self.loc.save_setting("notifications_position", self.notifications_position_var.get())

            self.kernel.loc.save_setting('git_remote_url', self.git_remote_url_var.get())

            messagebox.showinfo(self.loc.get("messagebox_success_title", fallback="Sukses"), self.loc.get("settings_save_success_msg", fallback="Pengaturan berhasil disimpan."))
            self.kernel.root.refresh_ui_components()

        except ValueError:
            messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Kesalahan"), "Port dan Durasi harus berupa angka.")
        except Exception as e:
            messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Kesalahan"), f"{self.loc.get('settings_save_error_msg', fallback='Gagal menyimpan pengaturan')}: {e}")

    def _update_license_ui_state(self):
        """Mengaktifkan atau menonaktifkan tombol deaktivasi berdasarkan status lisensi."""
        if hasattr(self, 'deactivate_button') and self.deactivate_button.winfo_exists():
            if self.kernel.is_premium_user():
                self.deactivate_button.config(state="normal")
            else:
                self.deactivate_button.config(state="disabled")

    def _deactivate_license(self):
        """Meminta konfirmasi dan menjalankan proses deaktivasi lisensi."""
        if messagebox.askyesno(
            self.loc.get("settings_license_deactivate_confirm_title", fallback="Konfirmasi Deaktivasi"),
            self.loc.get("settings_license_deactivate_confirm_message"),
            parent=self
        ):
            success, message = self.kernel.deactivate_license_online()
            if success:
                messagebox.showinfo(self.loc.get("messagebox_success_title", fallback="Sukses"), message, parent=self)
                self._update_license_ui_state()
            else:
                messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Gagal"), message, parent=self)

    def _add_variable(self):
        dialog = VariableDialog(self, title=self.loc.get("settings_variables_dialog_add_title", fallback="Tambah Variabel Baru"), kernel=self.kernel)
        if dialog.result:
            name, value, is_secret = dialog.result
            try:
                self.kernel.variable_manager.set_variable(name, value, is_secret)
                self._load_variables_to_ui()
            except ValueError as e:
                messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Kesalahan"), str(e), parent=self)

    def _edit_variable(self):
        selected_item = self.var_tree.focus()
        if not selected_item:
            messagebox.showwarning(self.loc.get("messagebox_warning_title", fallback="Peringatan"), self.loc.get("settings_variables_warn_select_to_edit", fallback="Pilih variabel yang ingin diedit."), parent=self)
            return

        item_data = self.var_tree.item(selected_item)
        var_name = item_data['values'][0]

        is_secret = False
        for var_cache in self.variables_data_cache:
            if var_cache['name'] == var_name:
                is_secret = var_cache.get('is_secret', False)
                break

        dialog = VariableDialog(self, title=self.loc.get("settings_variables_dialog_edit_title", fallback="Edit Variabel"), kernel=self.kernel, existing_name=var_name, is_editing_secret=is_secret)
        if dialog.result:
            _name, value, _is_secret = dialog.result
            try:
                self.kernel.variable_manager.set_variable(var_name, value, is_secret)
                self._load_variables_to_ui()
            except ValueError as e:
                messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Kesalahan"), str(e), parent=self)

    def _delete_variable(self):
        selected_item = self.var_tree.focus()
        if not selected_item:
            messagebox.showwarning(self.loc.get("messagebox_warning_title", fallback="Peringatan"), self.loc.get("settings_variables_warn_select_to_delete", fallback="Pilih variabel yang ingin dihapus."), parent=self)
            return

        item_data = self.var_tree.item(selected_item)
        var_name = item_data['values'][0]

        confirm_message = self.loc.get("settings_variables_confirm_delete", var_name=var_name)
        if messagebox.askyesno(self.loc.get("messagebox_confirm_title", fallback="Konfirmasi"), confirm_message, parent=self):
            if self.kernel.variable_manager.delete_variable(var_name):
                self._load_variables_to_ui()


    def _copy_variable_placeholder(self):
        selected_item = self.var_tree.focus()
        if not selected_item:
            messagebox.showwarning(self.loc.get("messagebox_warning_title", fallback="Peringatan"), self.loc.get("settings_variables_warn_select_to_copy", fallback="Pilih variabel untuk disalin."), parent=self)
            return

        item_data = self.var_tree.item(selected_item)
        var_name = item_data['values'][0]
        placeholder = f"{{{{vars.{var_name}}}}}"

        self.clipboard_clear()
        self.clipboard_append(placeholder)
        self.kernel.write_to_log(self.loc.get("settings_variables_copy_success", fallback=f"Placeholder '{placeholder}' disalin ke clipboard."), "SUCCESS")

    def _initialize_git_repo(self):
        """Membungkus fungsi inisialisasi dari PresetManager."""
        if messagebox.askyesno("Konfirmasi", "Anda yakin ingin membuat folder preset menjadi repositori Git? Aksi ini tidak bisa dibatalkan."):
            success, message = self.kernel.preset_manager.initialize_git_repo()
            if success:
                messagebox.showinfo("Sukses", message)
            else:
                messagebox.showerror("Error", message)

            if self.kernel.root:
                self.kernel.root.refresh_ui_components()

    def _save_remote_url(self):
        """Menyimpan URL remote ke PresetManager dan settings.json."""
        url = self.git_remote_url_var.get()
        if not url:
            messagebox.showwarning("Peringatan", "URL remote tidak boleh kosong.")
            return

        success, message = self.kernel.preset_manager.set_remote_url(url)
        if success:
            self.kernel.loc.save_setting('git_remote_url', url)
            messagebox.showinfo("Sukses", message)
        else:
            messagebox.showerror("Error", message)


class VariableDialog(ttk.Toplevel):
    def __init__(self, parent, title, kernel, existing_name=None, is_editing_secret=False):
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.grab_set()

        self.loc = kernel.loc
        self.result = None

        self.name_var = StringVar(value=existing_name or "")
        self.value_var = StringVar()
        self.is_secret_var = BooleanVar(value=is_editing_secret)

        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill="both", expand=True)

        name_label = ttk.Label(main_frame, text=self.loc.get("settings_variables_dialog_name", fallback="Nama:"))
        name_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.name_entry = ttk.Entry(main_frame, textvariable=self.name_var, width=40)
        self.name_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        if existing_name:
            self.name_entry.config(state="readonly")

        value_label = ttk.Label(main_frame, text=self.loc.get("settings_variables_dialog_value", fallback="Nilai:"))
        value_label.grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.value_entry = ttk.Entry(main_frame, textvariable=self.value_var, width=40)
        self.value_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        if is_editing_secret:
            self.value_entry.config(show="*")
            self.value_entry.insert(0, self.loc.get("settings_variables_dialog_secret_placeholder", fallback="(Biarkan kosong jika tidak ingin mengubah)"))

        secret_check = ttk.Checkbutton(main_frame, text=self.loc.get("settings_variables_dialog_secret_check", fallback="Rahasiakan nilai ini (secret)"), variable=self.is_secret_var, command=self._toggle_secret)
        secret_check.grid(row=2, column=1, padx=5, pady=10, sticky="w")
        if existing_name:
            secret_check.config(state="disabled")

        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=(10,0))

        ok_button = ttk.Button(button_frame, text=self.loc.get("button_save", fallback="Simpan"), command=self._on_ok, bootstyle="success")
        ok_button.pack(side="right", padx=5)

        cancel_button = ttk.Button(button_frame, text=self.loc.get("button_cancel", fallback="Batal"), command=self.destroy, bootstyle="secondary")
        cancel_button.pack(side="right")

        self.wait_window(self)

    def _toggle_secret(self):
        if self.is_secret_var.get():
            self.value_entry.config(show="*")
        else:
            self.value_entry.config(show="")

    def _on_ok(self):
        name = self.name_var.get().strip().upper()
        value = self.value_var.get()
        is_secret = self.is_secret_var.get()

        if not name:
            messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Kesalahan"), self.loc.get("settings_variables_warn_name_empty", fallback="Nama tidak boleh kosong."), parent=self)
            return

        if not name.replace('_', '').isalnum():
            messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Kesalahan"), self.loc.get("settings_variables_warn_name_format"), parent=self)
            return

        if value == "" or (self.name_entry.cget('state') == 'readonly' and value == self.loc.get("settings_variables_dialog_secret_placeholder", fallback="(Biarkan kosong jika tidak ingin mengubah)")):
            messagebox.showerror(self.loc.get("messagebox_error_title", fallback="Kesalahan"), self.loc.get("settings_variables_warn_value_empty", fallback="Nilai tidak boleh kosong."), parent=self)
            return

        self.result = (name, value, is_secret)
        self.destroy()
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################