####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import messagebox, Toplevel, simpledialog
import uuid
from datetime import datetime, timezone

class TriggerManagerPage(ttk.Frame):
    def __init__(self, parent, kernel):
        super().__init__(parent)
        self.kernel = kernel
        self.loc = kernel.loc
        self.rules = self.kernel.state.get("trigger_rules", {})

        self.countdown_updater_id = None
        self.countdown_jobs = {}

        self._create_widgets()
        self.populate_rules_list()

        self._start_countdown_updater()

    def _create_widgets(self):
        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill="both", expand=True)

        columns = ("name", "trigger_type", "preset", "status", "next_run")
        self.rules_tree = ttk.Treeview(main_frame, columns=columns, show="headings", style="Custom.Treeview")

        self.rules_tree.heading("name", text=self.loc.get('trigger_col_name', fallback="Nama Aturan"))
        self.rules_tree.heading("trigger_type", text=self.loc.get('trigger_col_type', fallback="Jenis Pemicu"))
        self.rules_tree.heading("preset", text=self.loc.get('trigger_col_preset', fallback="Preset Dijalankan"))
        self.rules_tree.heading("status", text=self.loc.get('trigger_col_status', fallback="Status"))
        self.rules_tree.heading("next_run", text=self.loc.get('trigger_col_next_run', fallback="Jadwal Berikutnya"))

        self.rules_tree.column("name", width=250)
        self.rules_tree.column("trigger_type", width=150)
        self.rules_tree.column("preset", width=200)
        self.rules_tree.column("status", width=80, anchor='center')
        self.rules_tree.column("next_run", width=150, anchor='center')

        self.rules_tree.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=self.rules_tree.yview)
        self.rules_tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")

        button_frame = ttk.Frame(self, padding=(20, 10, 20, 20))
        button_frame.pack(fill="x")
        ttk.Button(button_frame, text=self.loc.get('trigger_btn_new', fallback="Aturan Baru..."), command=self._open_rule_editor, style="success.TButton").pack(side="left")
        ttk.Button(button_frame, text=self.loc.get('trigger_btn_edit', fallback="Edit..."), command=self._edit_selected_rule).pack(side="left", padx=10)
        ttk.Button(button_frame, text=self.loc.get('trigger_btn_delete', fallback="Hapus"), command=self._delete_selected_rule, style="danger.TButton").pack(side="left")

    def populate_rules_list(self):
        for item in self.rules_tree.get_children():
            self.rules_tree.delete(item)

        self.countdown_jobs.clear()

        for rule_id, rule_data in sorted(self.rules.items(), key=lambda item: item[1]['name']):
            trigger_id = rule_data.get("trigger_id", "N/A")
            trigger_manifest = self.kernel.trigger_manager.loaded_triggers.get(trigger_id, {}).get("manifest", {})
            trigger_name = trigger_manifest.get("name", trigger_id)
            status = self.loc.get('status_enabled', fallback="Aktif") if rule_data.get("is_enabled") else self.loc.get('status_disabled', fallback="Nonaktif")

            next_run_text = "-"
            if rule_data.get("is_enabled") and trigger_id == 'cron_trigger':
                next_run_time = self.kernel.scheduler_manager.get_next_run_time(rule_id)
                if next_run_time:
                    next_run_text = self.loc.get('status_calculating', fallback="Menghitung...")
                else:
                    next_run_text = self.loc.get('status_not_scheduled', fallback="Tidak Terjadwal")

            values = (
                rule_data.get("name", "Tanpa Nama"),
                trigger_name,
                rule_data.get("preset_to_run", "-"),
                status,
                next_run_text
            )
            item_id = self.rules_tree.insert("", "end", values=values, iid=rule_id)

            if rule_data.get("is_enabled") and trigger_id == 'cron_trigger':
                self.countdown_jobs[item_id] = rule_id

    def _start_countdown_updater(self):
        if self.countdown_updater_id is None:
            self._update_countdowns()

    def _update_countdowns(self):
        if not self.winfo_exists():
            return

        for item_id, rule_id in self.countdown_jobs.items():
            if not self.rules_tree.exists(item_id):
                continue

            next_run_time = self.kernel.scheduler_manager.get_next_run_time(rule_id)
            if next_run_time:
                now_utc = datetime.now(timezone.utc)
                if next_run_time.tzinfo is None:
                    next_run_time = next_run_time.astimezone()

                delta = next_run_time - now_utc

                if delta.total_seconds() > 0:
                    hours, remainder = divmod(int(delta.total_seconds()), 3600)
                    minutes, seconds = divmod(remainder, 60)
                    countdown_str = f"{hours:02}:{minutes:02}:{seconds:02}"
                    self.rules_tree.set(item_id, "next_run", countdown_str)
                else:
                    self.rules_tree.set(item_id, "next_run", self.loc.get('status_waiting_schedule', fallback="Menunggu..."))
            else:
                 self.rules_tree.set(item_id, "next_run", self.loc.get('status_not_scheduled', fallback="Tidak Terjadwal"))

        self.countdown_updater_id = self.after(1000, self._update_countdowns)

    def destroy(self):
        if self.countdown_updater_id:
            self.after_cancel(self.countdown_updater_id)
            self.countdown_updater_id = None
        super().destroy()

    def _edit_selected_rule(self):
        selected_items = self.rules_tree.selection()
        if not selected_items:
            messagebox.showwarning(self.loc.get('warning_title'), self.loc.get('trigger_warn_select_to_edit'))
            return
        self._open_rule_editor(rule_id=selected_items[0])

    def _delete_selected_rule(self):
        selected_items = self.rules_tree.selection()
        if not selected_items:
            messagebox.showwarning(self.loc.get('warning_title'), self.loc.get('trigger_warn_select_to_delete'))
            return

        rule_id = selected_items[0]
        rule_name = self.rules[rule_id].get("name")
        if messagebox.askyesno(self.loc.get('confirm_delete_title'), self.loc.get('trigger_confirm_delete', name=rule_name)):
            del self.rules[rule_id]
            self._save_and_reload()

    def _save_and_reload(self):
        self.kernel.state.set("trigger_rules", self.rules)
        self.populate_rules_list()
        self.kernel.trigger_manager.start_all_listeners()

    def _open_rule_editor(self, rule_id=None):
        editor_window = Toplevel(self)
        editor_window.transient(self)
        editor_window.grab_set()

        rule_data = self.rules.get(rule_id, {}) if rule_id else {}
        editor_window.title(self.loc.get('trigger_editor_title_edit' if rule_id else 'trigger_editor_title_new'))

        form_vars = {
            'name': ttk.StringVar(value=rule_data.get('name', '')),
            'trigger_id': ttk.StringVar(value=rule_data.get('trigger_id', '')),
            'preset_to_run': ttk.StringVar(value=rule_data.get('preset_to_run', '')),
            'is_enabled': ttk.BooleanVar(value=rule_data.get('is_enabled', True)),
        }

        main_frame = ttk.Frame(editor_window, padding=20)
        main_frame.pack(fill="both", expand=True)


        ttk.Label(main_frame, text=self.loc.get('trigger_form_name')).pack(anchor='w', pady=(0,2))
        ttk.Entry(main_frame, textvariable=form_vars['name']).pack(fill='x', pady=(0, 10))

        ttk.Label(main_frame, text=self.loc.get('trigger_form_type')).pack(anchor='w', pady=(0,2))
        trigger_display_names = {tdata['manifest'].get('name', tid): tid for tid, tdata in self.kernel.trigger_manager.loaded_triggers.items()}
        trigger_combobox = ttk.Combobox(main_frame, state="readonly",
                                        values=list(sorted(trigger_display_names.keys())))
        if form_vars['trigger_id'].get():
            for name, tid in trigger_display_names.items():
                if tid == form_vars['trigger_id'].get():
                    trigger_combobox.set(name)
                    break
        trigger_combobox.pack(fill='x', pady=(0, 10))

        ttk.Label(main_frame, text=self.loc.get('trigger_form_preset')).pack(anchor='w', pady=(0,2))
        preset_list = self.kernel.preset_manager.get_preset_list()
        ttk.Combobox(main_frame, textvariable=form_vars['preset_to_run'], values=preset_list, state="readonly").pack(fill='x', pady=(0, 10))

        config_frame_container = ttk.Frame(main_frame)
        config_frame_container.pack(fill="both", expand=True, pady=5, before=trigger_combobox) # Posisikan

        def on_trigger_selected(event=None):
            for widget in config_frame_container.winfo_children():
                widget.destroy()

            selected_display_name = trigger_combobox.get()
            selected_trigger_id = trigger_display_names.get(selected_display_name)

            if not selected_trigger_id: return
            form_vars['trigger_id'].set(selected_trigger_id)

            ConfigUIClass = self.kernel.trigger_manager.get_config_ui_class(selected_trigger_id)

            if ConfigUIClass:
                config_frame_container.configure(padding=(0, 10))
                config_ui_instance = ConfigUIClass(config_frame_container, self.loc, rule_data.get('config', {}))
                config_ui_instance.pack(fill='both', expand=True)
                form_vars['config_ui'] = config_ui_instance
            else:
                config_frame_container.configure(padding=(0, 0))

        trigger_combobox.bind("<<ComboboxSelected>>", on_trigger_selected)
        if form_vars['trigger_id'].get():
            on_trigger_selected(None)

        bottom_frame = ttk.Frame(main_frame)
        bottom_frame.pack(side='bottom', fill='x', pady=(10,0))

        ttk.Checkbutton(bottom_frame, text=self.loc.get('trigger_form_enable'), variable=form_vars['is_enabled']).pack(side='left')

        button_container = ttk.Frame(bottom_frame)
        button_container.pack(side='right')

        def _save_rule():
            if not form_vars['trigger_id'].get():
                messagebox.showerror(self.loc.get('error_title'), self.loc.get('trigger_err_no_type_selected'))
                return

            new_rule_id = rule_id or str(uuid.uuid4())

            config_data = {}
            if 'config_ui' in form_vars and hasattr(form_vars['config_ui'], 'get_config'):
                config_data = form_vars['config_ui'].get_config()

            self.rules[new_rule_id] = {
                "name": form_vars['name'].get(),
                "trigger_id": form_vars['trigger_id'].get(),
                "preset_to_run": form_vars['preset_to_run'].get(),
                "is_enabled": form_vars['is_enabled'].get(),
                "config": config_data
            }
            self._save_and_reload()
            editor_window.destroy()

        ttk.Button(button_container, text=self.loc.get('button_save'), command=_save_rule, style="success.TButton").pack(side="right")
        ttk.Button(button_container, text=self.loc.get('button_cancel'), command=editor_window.destroy, style="secondary.TButton").pack(side="right", padx=10)
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################