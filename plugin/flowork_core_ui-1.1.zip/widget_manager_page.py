####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import ttk as tk_ttk, messagebox, filedialog, StringVar
import os
import shutil
import platform
import subprocess
import requests
import zipfile
import io
import threading
import uuid
import traceback
import sys # PENAMBAHAN KODE: Impor sys yang hilang
from flowork_kernel.ui_shell.custom_widgets.tooltip import ToolTip
from ttkbootstrap.scrolled import ScrolledFrame


class InstalledWidgetsTab(ttk.Frame):
    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, style='TFrame')
        self.kernel = kernel_instance
        self.loc = self.kernel.loc
        self.search_var = StringVar()
        self.search_var.trace_add("write", self._on_search)
        self.create_widgets()
        self.apply_styles(self.kernel.theme_manager.get_colors())
        self.populate_widget_list()

    def apply_styles(self, colors):
        style = tk_ttk.Style(self)
        style.configure('TFrame', background=colors.get('bg'))
        style.configure('TLabel', background=colors.get('bg'), foreground=colors.get('fg'))
        style.configure('TLabelframe', background=colors.get('bg'), borderwidth=1, relief='solid', bordercolor=colors.get('border'))
        style.configure('TLabelframe.Label', background=colors.get('bg'), foreground=colors.get('fg'), font=('Helvetica', 10, 'bold'))
        style.configure('Paused.TLabel', background=colors.get('bg'), foreground=colors.get('secondary'))

    def create_widgets(self):
        main_container_frame = ttk.Frame(self, padding=20, style='TFrame')
        main_container_frame.pack(fill="both", expand=True)
        widget_frame = ttk.LabelFrame(main_container_frame, text=self.loc.get('widget_management_title', fallback="Manajemen Widget"), padding=15, style='TLabelframe')
        widget_frame.pack(fill="both", expand=True, pady=(0, 20))
        top_bar_frame = ttk.Frame(widget_frame, style='TFrame')
        top_bar_frame.pack(fill='x', pady=5)

        upload_button = ttk.Button(top_bar_frame, text=self.loc.get('upload_widget_button', fallback="Unggah Widget"), command=self.upload_widget, style="success.TButton")
        upload_button.pack(side="left")

        search_frame = ttk.Frame(top_bar_frame, style='TFrame')
        search_frame.pack(side="right", fill='x', expand=True, padx=(10, 0))
        search_frame.columnconfigure(1, weight=1)
        search_icon_label = ttk.Label(search_frame, text="", font=("Font Awesome 6 Free Solid", 9), style='TLabel')
        search_icon_label.grid(row=0, column=0, padx=(0, 5))
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        search_entry.grid(row=0, column=1, sticky="ew")
        ToolTip(search_entry).update_text(self.loc.get('tooltip_search_installed_widgets', fallback="Ketik untuk mencari widget terinstal...")) # Update tooltip

        scrolled_frame_container = ttk.Frame(widget_frame, style='TFrame')
        scrolled_frame_container.pack(fill='both', expand=True, pady=(10,0))
        self.widget_list_frame = ScrolledFrame(scrolled_frame_container, autohide=True)
        self.widget_list_frame.pack(fill='both', expand=True)

    def refresh_content(self):
        self.populate_widget_list()

    def _on_search(self, *args):
        self.populate_widget_list()

    def populate_widget_list(self):
        for widget in self.widget_list_frame.winfo_children():
            widget.destroy()
        filter_text = self.search_var.get().lower()
        all_widgets = self.kernel.widget_manager.loaded_widgets
        sorted_widgets = sorted(all_widgets.items(), key=lambda item: item[1].get('name', item[0]).lower())
        widget_found = False
        for widget_id, widget_data in sorted_widgets:
            widget_name = widget_data.get('name', widget_id)
            widget_description = widget_data.get('manifest', {}).get('description', '') # Ambil deskripsi

            if filter_text not in widget_name.lower() and \
               filter_text not in widget_description.lower() and \
               filter_text not in widget_id.lower():
                continue

            widget_found = True
            item_container = ttk.Frame(self.widget_list_frame, style='TFrame')
            item_container.pack(fill='x', pady=2)
            item_frame = ttk.Frame(item_container, style='TFrame')
            item_frame.pack(fill='x')
            is_paused = widget_data.get('is_paused', False)
            label_style = "Paused.TLabel" if is_paused else "TLabel"
            paused_prefix = self.loc.get('paused_prefix', fallback="[DIJEDA] ") if is_paused else "" # Gunakan lokalisasi
            label = ttk.Label(item_frame, text=f"{paused_prefix}{widget_name} ({widget_id})", style=label_style) # Tambahkan ID
            label.pack(side='left', padx=5)

            if widget_description:
                ttk.Label(item_container, text=widget_description, style='TLabel', wraplength=400, justify='left').pack(anchor='w', padx=15, pady=(0,5))


            buttons_frame = ttk.Frame(item_frame, style='TFrame')
            buttons_frame.pack(side='right', padx=5)
            if is_paused:
                toggle_button = ttk.Button(buttons_frame, text=self.loc.get('resume_button', fallback="Lanjutkan"), style="success-link", command=lambda wid=widget_id: self.toggle_widget_pause(wid, False))
                ToolTip(toggle_button).update_text(self.loc.get('tooltip_resume_widget', fallback="Lanjutkan widget ini.")) # Update tooltip
            else:
                toggle_button = ttk.Button(buttons_frame, text=self.loc.get('pause_button', fallback="Jeda"), style="warning-link", command=lambda wid=widget_id: self.toggle_widget_pause(wid, True))
                ToolTip(toggle_button).update_text(self.loc.get('tooltip_pause_widget', fallback="Jeda widget ini agar tidak dimuat saat aplikasi dimulai.")) # Update tooltip
            toggle_button.pack(side='right', padx=2)
            edit_button = ttk.Button(buttons_frame, text=self.loc.get('edit_button', fallback="Edit"), style="info-link", command=lambda path=widget_data.get('path'): self._open_path_in_explorer(path))
            ToolTip(edit_button).update_text(self.loc.get('tooltip_edit_widget', fallback="Buka folder widget.")) # Update tooltip
            edit_button.pack(side='right', padx=2)
            delete_button = ttk.Button(buttons_frame, text=self.loc.get('uninstall_button', fallback="Hapus"), style="danger-link", command=lambda wid=widget_id, wname=widget_name: self.uninstall_widget(wid, wname))
            ToolTip(delete_button).update_text(self.loc.get('tooltip_delete_widget', fallback="Hapus widget ini.")) # Update tooltip
            delete_button.pack(side='right', padx=2)
        if not widget_found:
            ttk.Label(self.widget_list_frame, text=self.loc.get('no_widgets_installed_message', fallback="Tidak ada widget yang terinstal.")).pack(pady=20) # Gunakan lokalisasi

    def toggle_widget_pause(self, widget_id, should_pause):
        widget_name = self.kernel.widget_manager.loaded_widgets.get(widget_id, {}).get('name', widget_id)
        if self.kernel.widget_manager.set_widget_paused(widget_id, should_pause):
            self.populate_widget_list()

    def uninstall_widget(self, widget_id, widget_name):
        if messagebox.askyesno(self.loc.get('confirm_delete_title', fallback="Konfirmasi Hapus"), self.loc.get('confirm_delete_widget_message', name=widget_name, fallback=f"Apakah Anda yakin ingin menghapus widget '{widget_name}' secara permanen?")): # Gunakan lokalisasi
            try:
                widget_data = self.kernel.widget_manager.loaded_widgets.get(widget_id)
                if widget_data and 'path' in widget_data:
                    shutil.rmtree(widget_data['path'])
                    messagebox.showinfo(self.loc.get('success_title', fallback="Sukses"), self.loc.get('widget_deleted_success_message', name=widget_name, fallback=f"Widget '{widget_name}' berhasil dihapus.")) # Gunakan lokalisasi
                    self.kernel.reload_widgets()
                else:
                    raise FileNotFoundError(self.loc.get('widget_path_not_found', fallback="Path widget tidak ditemukan.")) # Gunakan lokalisasi
            except Exception as e:
                messagebox.showerror(self.loc.get('error_title', fallback="Error"), self.loc.get('widget_delete_failed_error', name=widget_name, error=str(e), fallback=f"Gagal menghapus widget '{widget_name}':\n{e}")) # Gunakan lokalisasi

    def _open_path_in_explorer(self, path):
        if not path: return
        try:
            if os.name == 'nt': os.startfile(path)
            elif sys.platform == 'darwin': subprocess.call(('open', path))
            else: subprocess.call(('xdg-open', path))
        except Exception as e:
            messagebox.showerror(self.loc.get('error_title', fallback="Error"), self.loc.get('log_failed_to_open_folder', path=path, error=str(e), fallback=f"Tidak dapat membuka folder: {path}\n{e}")) # Gunakan lokalisasi

    def upload_widget(self):
        zip_path = filedialog.askopenfilename(title=self.loc.get('select_widget_file_title', fallback="Pilih File Widget (.zip)"), filetypes=[(self.loc.get('zip_files_label', fallback="File ZIP"), "*.zip")]) # Gunakan lokalisasi
        if not zip_path:
            self.kernel.write_to_log(self.loc.get('widget_installation_cancelled', fallback="Instalasi widget dibatalkan."), "WARN") # Gunakan lokalisasi
            return

        widget_name = os.path.splitext(os.path.basename(zip_path))[0] # Ambil nama widget dari nama file

        if not messagebox.askyesno(self.loc.get('confirm_upload_title', fallback="Konfirmasi Unggah"), self.loc.get('confirm_upload_widget_message', name=widget_name, fallback=f"Apakah Anda yakin ingin mengunggah dan menginstal widget '{widget_name}'?")): # Gunakan lokalisasi
            return

        def _upload_and_install():
            widget_target_dir = None
            temp_extract_dir = None
            try:
                self.kernel.write_to_log(self.loc.get('log_uploading_widget', name=widget_name, fallback=f"Mengunggah dan menginstal widget '{widget_name}'..."), "INFO") # Gunakan lokalisasi

                temp_extract_dir = os.path.join(self.kernel.data_path, f"temp_widget_upload_extract_{uuid.uuid4()}")
                os.makedirs(temp_extract_dir, exist_ok=True)

                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(temp_extract_dir) # Ekstrak semua ke direktori sementara

                extracted_contents = os.listdir(temp_extract_dir)
                source_widget_folder_path = temp_extract_dir # Default: asumsikan file langsung di root ZIP

                if len(extracted_contents) == 1 and os.path.isdir(os.path.join(temp_extract_dir, extracted_contents[0])):
                    source_widget_folder_path = os.path.join(temp_extract_dir, extracted_contents[0])
                    if os.path.basename(source_widget_folder_path) != widget_name:
                        self.kernel.write_to_log(self.loc.get('zip_folder_name_mismatch',
                            name_in_zip=os.path.basename(source_widget_folder_path),
                            expected_name=widget_name,
                            fallback=f"WARN: Nama folder dalam ZIP '{os.path.basename(source_widget_folder_path)}' tidak cocok dengan ID widget yang diharapkan '{widget_name}'. Lanjutkan..."), "WARN") # Gunakan lokalisasi

                widget_target_dir = os.path.join(self.kernel.widgets_path, widget_name) # Folder tujuan untuk widget

                if os.path.exists(widget_target_dir):
                    self.kernel.write_to_log(self.loc.get('widget_folder_exists_warning', name=widget_name, fallback=f"Folder widget '{widget_name}' sudah ada. Menimpa..."), "WARN") # Gunakan lokalisasi
                    shutil.rmtree(widget_target_dir)

                shutil.move(source_widget_folder_path, widget_target_dir)

                if not os.path.exists(os.path.join(widget_target_dir, 'manifest.json')):
                    raise Exception(self.loc.get('manifest_not_found_after_extract_widget', name=widget_name, fallback=f"File manifest.json tidak ditemukan setelah ekstraksi widget '{widget_name}'. Instalasi gagal.")) # Gunakan lokalisasi


                self.kernel.write_to_log(self.loc.get('log_widget_uploaded_success', name=widget_name, fallback=f"Widget '{widget_name}' berhasil diunggah dan diinstal!"), "SUCCESS") # Lokalisasi
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showinfo(self.loc.get('success_title', fallback="Berhasil"), self.loc.get('widget_uploaded_success_popup', name=widget_name, fallback=f"Widget '{widget_name}' berhasil diunggah dan diinstal!\nAplikasi akan memuat ulang widget."))) # Lokalisasi

                self.kernel.reload_widgets() # Reload widgets
            except zipfile.BadZipFile:
                error_msg = self.loc.get('widget_zip_corrupt_upload', name=widget_name, fallback=f"File '{zip_path}' bukan file ZIP yang valid atau rusak.") # Lokalisasi
                self.kernel.write_to_log(error_msg, "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg))
            except Exception as e:
                full_traceback = traceback.format_exc()
                error_msg_detail = str(e)
                error_msg = self.loc.get('widget_upload_failed', name=widget_name, error=error_msg_detail, fallback=f"Gagal mengunggah atau menginstal '{widget_name}': {error_msg_detail}") # Lokalisasi
                self.kernel.write_to_log(f"ERROR: {error_msg}\nTraceback:\n{full_traceback}", "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg))
            finally:
                if temp_extract_dir and os.path.exists(temp_extract_dir):
                    try:
                        shutil.rmtree(temp_extract_dir)
                        self.kernel.write_to_log(f"Membersihkan folder ekstraksi temporer: {temp_extract_dir}", "DEBUG")
                    except Exception as clean_e:
                        self.kernel.write_to_log(f"Gagal membersihkan folder temporer: {temp_extract_dir} - {clean_e}", "WARN")

        threading.Thread(target=_upload_and_install, daemon=True).start()


class DiscoverWidgetsTab(ttk.Frame):
    GITHUB_WIDGETS_URL = "https://raw.githubusercontent.com/flowork-dev/modul/refs/heads/main/top_widget.json" # Asumsi URL ini ada dan berisi data widget

    def __init__(self, parent_notebook, kernel_instance, installed_widgets_tab_instance): # Perbaikan: nama parameter widget
        super().__init__(parent_notebook, style='TFrame')
        self.kernel = kernel_instance
        self.loc = self.kernel.loc
        self.installed_widgets_tab = installed_widgets_tab_instance # Referensi ke tab widget terinstal untuk refresh
        self.search_var = StringVar()
        self.search_var.trace_add("write", self._on_search)
        self.online_widgets_data = [] # Untuk menyimpan data widget yang diambil dari GitHub

        self.create_widgets()
        self.apply_styles(self.kernel.theme_manager.get_colors())
        self.fetch_and_populate_widgets() # Panggil saat inisialisasi

    def apply_styles(self, colors):
        style = tk_ttk.Style(self)
        style.configure('TFrame', background=colors.get('bg'))
        style.configure('TLabel', background=colors.get('bg'), foreground=colors.get('fg'))
        style.configure('Installable.TLabel', background=colors.get('bg'), foreground=colors.get('info')) # Gaya baru untuk item installable
        style.configure('Permissions.TLabel', background=colors.get('bg'), foreground=colors.get('warning'), font=('Helvetica', 7, 'italic'))

    def create_widgets(self):
        main_frame = ttk.Frame(self, padding=15, style='TFrame')
        main_frame.pack(fill="both", expand=True)

        search_frame = ttk.Frame(main_frame, style='TFrame')
        search_frame.pack(fill='x', pady=5)
        search_frame.columnconfigure(1, weight=1)

        search_icon_label = ttk.Label(search_frame, text="", font=("Font Awesome 6 Free Solid", 9), style='TLabel')
        search_icon_label.grid(row=0, column=0, padx=(0, 5))

        search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        search_entry.grid(row=0, column=1, sticky="ew")
        ToolTip(search_entry).update_text(self.loc.get('tooltip_search_online_widgets', fallback="Ketik untuk mencari widget online...")) # Lokalisasi

        self.widget_list_frame = ScrolledFrame(main_frame, autohide=True)
        self.widget_list_frame.pack(fill='both', expand=True, pady=(10,0))

    def _on_search(self, *args):
        self.populate_online_widget_list()

    def refresh_content(self):
        self.fetch_and_populate_widgets()

    def fetch_and_populate_widgets(self):
        def _fetch():
            self.online_widgets_data = self.fetch_online_widgets_data()
            if self.kernel.root and hasattr(self.kernel.root, 'after'):
                self.kernel.root.after(0, self.populate_online_widget_list)

        threading.Thread(target=_fetch, daemon=True).start()

    def fetch_online_widgets_data(self):
        try:
            self.kernel.write_to_log(self.loc.get('log_fetching_online_widgets', fallback="Mengambil daftar widget dari GitHub..."), "INFO") # Lokalisasi
            response = requests.get(self.GITHUB_WIDGETS_URL, timeout=10)
            response.raise_for_status()
            data = response.json()

            installed_ids = {wid for wid, _ in self.kernel.widget_manager.loaded_widgets.items()}
            filtered_data = [
                widget for widget in data if widget.get('name') not in installed_ids and
                                             os.path.splitext(os.path.basename(widget.get('download_url', '')).replace(".zip", ""))[0] not in installed_ids # Perbaikan: Gunakan 'download_url'
            ]

            self.kernel.write_to_log(self.loc.get('log_fetched_online_widgets', count=len(filtered_data), fallback=f"Berhasil mengambil {len(filtered_data)} widget dari GitHub."), "SUCCESS") # Lokalisasi
            return filtered_data
        except requests.exceptions.RequestException as e:
            self.kernel.write_to_log(self.loc.get('log_fetch_online_widgets_error', error=str(e), fallback=f"Gagal mengambil daftar widget dari GitHub: {e}"), "ERROR") # Lokalisasi
            if self.kernel.root and hasattr(self.kernel.root, 'after'):
                self.kernel.root.after(0, lambda err=e: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('fetch_widgets_error_popup', error=str(err), fallback=f"Gagal mengambil daftar widget dari GitHub: {err}\nPastikan koneksi internet Anda berfungsi."))) # Lokalisasi
            return []
        except ValueError as e:
            self.kernel.write_to_log(self.loc.get('log_parse_online_widgets_error', error=str(e), fallback=f"Gagal mengurai data widget dari GitHub: {e}"), "ERROR") # Lokalisasi
            if self.kernel.root and hasattr(self.kernel.root, 'after'):
                self.kernel.root.after(0, lambda err=e: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('parse_widgets_error_popup', error=str(err), fallback=f"Gagal mengurai data widget dari GitHub: {err}\nFormat JSON mungkin tidak valid."))) # Lokalisasi
            return []

    def populate_online_widget_list(self):
        for widget in self.widget_list_frame.winfo_children():
            widget.destroy()

        filter_text = self.search_var.get().lower()
        widgets_to_display = sorted(
            [w for w in self.online_widgets_data if filter_text in w.get('name', '').lower() or filter_text in w.get('description', '').lower()], # Perbaikan: Gunakan 'description'
            key=lambda x: x.get('name', '').lower()
        )

        if not widgets_to_display:
            ttk.Label(self.widget_list_frame, text=self.loc.get('no_online_widgets_found_message', fallback="Tidak ada widget online yang ditemukan atau semua sudah terinstal."), style='TLabel').pack(pady=20) # Lokalisasi
            return

        for widget_info in widgets_to_display:
            widget_name = widget_info.get('name', 'Unknown Widget')
            description = widget_info.get('description', 'No description available.') # Perbaikan: Gunakan 'description'
            author = widget_info.get('author', 'Unknown Author') # Asumsi ada field author
            version = widget_info.get('version', 'N/A') # Asumsi ada field version
            download_url = widget_info.get('download_url') # Perbaikan: Gunakan 'download_url'

            item_container = ttk.Frame(self.widget_list_frame, style='TFrame', borderwidth=1, relief="solid", padding=5)
            item_container.pack(fill='x', pady=5, padx=5)

            name_label = ttk.Label(item_container, text=f"{widget_name} (v{version})", style='Installable.TLabel', font=('Helvetica', 10, 'bold'))
            name_label.pack(anchor='w')
            ttk.Label(item_container, text=self.loc.get('widget_author_label', author=author, fallback=f"Oleh: {author}"), style='TLabel', font=('Helvetica', 8, 'italic')).pack(anchor='w', padx=5) # Lokalisasi
            ttk.Label(item_container, text=description, style='TLabel', wraplength=400, justify='left').pack(anchor='w', pady=(5, 5))

            if download_url:
                install_button = ttk.Button(item_container, text=self.loc.get('install_button', fallback="Instal"), style="success.TButton", command=lambda name=widget_name, url=download_url: self.install_online_widget(name, url)) # Lokalisasi
                install_button.pack(side='right', pady=5, padx=5)
            else:
                ttk.Label(item_container, text=self.loc.get('download_link_missing', fallback="Link download tidak tersedia."), style='Permissions.TLabel').pack(side='right', pady=5, padx=5) # Lokalisasi

    def install_online_widget(self, widget_name, download_url):
        actual_widget_folder_name = os.path.splitext(os.path.basename(download_url).replace(".zip", ""))[0]
        if not actual_widget_folder_name:
            self.kernel.write_to_log(self.loc.get('widget_invalid_download_url', name=widget_name, url=download_url, fallback=f"URL unduh widget '{widget_name}' tidak valid: {download_url}"), "ERROR") # Lokalisasi
            if self.kernel.root and hasattr(self.kernel.root, 'after'):
                self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), self.loc.get('widget_install_failed_invalid_url', name=widget_name, fallback=f"Gagal menginstal widget '{widget_name}': URL unduh tidak valid."))) # Lokalisasi
            return

        if not messagebox.askyesno(self.loc.get('confirm_install_title', fallback="Konfirmasi Instalasi"), self.loc.get('confirm_install_widget_message', name=widget_name, fallback=f"Apakah Anda yakin ingin menginstal widget '{widget_name}'?")): # Lokalisasi
            return

        def _install():
            temp_zip_file = None
            temp_extract_dir = None
            widget_target_dir = None
            try:
                self.kernel.write_to_log(self.loc.get('log_downloading_widget', name=widget_name, url=download_url, fallback=f"Mengunduh widget '{widget_name}' dari {download_url}..."), "INFO") # Lokalisasi

                response = requests.get(download_url, stream=True, timeout=30)
                response.raise_for_status()

                temp_zip_file = os.path.join(self.kernel.data_path, f"temp_widget_{uuid.uuid4()}.zip")
                with open(temp_zip_file, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)

                temp_extract_dir = os.path.join(self.kernel.data_path, f"temp_widget_extract_{uuid.uuid4()}")
                os.makedirs(temp_extract_dir, exist_ok=True)

                with zipfile.ZipFile(temp_zip_file, 'r') as zip_ref:
                    zip_ref.extractall(temp_extract_dir)

                extracted_contents = os.listdir(temp_extract_dir)
                source_widget_folder_path = temp_extract_dir

                if len(extracted_contents) == 1 and os.path.isdir(os.path.join(temp_extract_dir, extracted_contents[0])):
                    source_widget_folder_path = os.path.join(temp_extract_dir, extracted_contents[0])
                    if os.path.basename(source_widget_folder_path) != actual_widget_folder_name:
                        self.kernel.write_to_log(self.loc.get('zip_folder_name_mismatch_widget',
                            name_in_zip=os.path.basename(source_widget_folder_path),
                            expected_name=actual_widget_folder_name,
                            fallback=f"WARN: Nama folder dalam ZIP '{os.path.basename(source_widget_folder_path)}' tidak cocok dengan ID widget yang diharapkan '{actual_widget_folder_name}'. Lanjutkan..."), "WARN") # Lokalisasi

                widget_target_dir = os.path.join(self.kernel.widgets_path, actual_widget_folder_name)

                if os.path.exists(widget_target_dir):
                    self.kernel.write_to_log(self.loc.get('widget_folder_exists_warning', name=actual_widget_folder_name, fallback=f"Folder widget '{actual_widget_folder_name}' sudah ada. Menimpa..."), "WARN") # Lokalisasi
                    shutil.rmtree(widget_target_dir)

                shutil.move(source_widget_folder_path, widget_target_dir)

                if not os.path.exists(os.path.join(widget_target_dir, 'manifest.json')):
                    raise Exception(self.loc.get('manifest_not_found_after_extract_widget', name=widget_name, fallback=f"File manifest.json tidak ditemukan setelah ekstraksi widget '{widget_name}'. Instalasi gagal.")) # Lokalisasi

                self.kernel.write_to_log(self.loc.get('log_widget_installed_success', name=widget_name, fallback=f"Widget '{widget_name}' berhasil diinstal!"), "SUCCESS") # Lokalisasi
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showinfo(self.loc.get('success_title', fallback="Berhasil"), self.loc.get('widget_installed_success_popup', name=widget_name, fallback=f"Widget '{widget_name}' berhasil diinstal!\nAplikasi akan memuat ulang widget."))) # Lokalisasi

                self.kernel.reload_widgets()
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, self.installed_widgets_tab.refresh_content)
                    self.kernel.root.after(0, self.fetch_and_populate_widgets)

            except requests.exceptions.RequestException as e:
                full_traceback = traceback.format_exc()
                error_msg_detail = str(e)
                error_msg_for_user = self.loc.get('widget_download_failed', name=widget_name, error=error_msg_detail, fallback=f"Gagal mengunduh '{widget_name}': {error_msg_detail}\nPeriksa koneksi internet.") # Lokalisasi
                self.kernel.write_to_log(f"ERROR: {error_msg_for_user}\nTraceback:\n{full_traceback}", "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg_for_user))
            except zipfile.BadZipFile:
                error_msg = self.loc.get('widget_zip_corrupt', name=widget_name, fallback=f"File '{widget_name}' yang diunduh rusak atau bukan file ZIP yang valid.") # Lokalisasi
                self.kernel.write_to_log(error_msg, "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg))
            except Exception as e:
                full_traceback = traceback.format_exc()
                error_msg_detail = str(e)
                error_msg = self.loc.get('widget_install_failed', name=widget_name, error=error_msg_detail, fallback=f"Gagal menginstal '{widget_name}': {error_msg_detail}") # Lokalisasi
                self.kernel.write_to_log(f"ERROR: {error_msg}\nTraceback:\n{full_traceback}", "ERROR")
                if self.kernel.root and hasattr(self.kernel.root, 'after'):
                    self.kernel.root.after(0, lambda: messagebox.showerror(self.loc.get('error_title', fallback="Kesalahan"), error_msg))
            finally:
                if temp_zip_file and os.path.exists(temp_zip_file):
                    try:
                        os.remove(temp_zip_file)
                        self.kernel.write_to_log(f"Membersihkan file ZIP temporer: {temp_zip_file}", "DEBUG")
                    except Exception as clean_e:
                        self.kernel.write_to_log(f"Gagal membersihkan file temporer: {temp_zip_file} - {clean_e}", "WARN")

                if temp_extract_dir and os.path.exists(temp_extract_dir):
                    try:
                        shutil.rmtree(temp_extract_dir)
                        self.kernel.write_to_log(f"Membersihkan folder ekstraksi temporer: {temp_extract_dir}", "DEBUG")
                    except Exception as clean_e:
                        self.kernel.write_to_log(f"Gagal membersihkan folder temporer: {temp_extract_dir} - {clean_e}", "WARN")

        threading.Thread(target=_install, daemon=True).start()


class WidgetManagerPage(ttk.Frame):
    def __init__(self, parent_notebook, kernel_instance):
        super().__init__(parent_notebook, style='TFrame')
        self.kernel = kernel_instance
        self.loc = self.kernel.loc

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(expand=True, fill="both", padx=10, pady=10)

        self.installed_widgets_tab = InstalledWidgetsTab(self.notebook, self.kernel)
        self.discover_widgets_tab = DiscoverWidgetsTab(self.notebook, self.kernel, self.installed_widgets_tab)

        self.notebook.add(self.installed_widgets_tab, text=self.loc.get('installed_widgets_tab_title', fallback="Widget Terinstal")) # Lokalisasi
        self.notebook.add(self.discover_widgets_tab, text=self.loc.get('discover_widgets_tab_title', fallback="Temukan Widget")) # Lokalisasi

        self.notebook.bind("<<NotebookTabChanged>>", self._on_tab_change)

        self.apply_styles(self.kernel.theme_manager.get_colors())

    def _on_tab_change(self, event):
        selected_tab_id = self.notebook.select()
        selected_tab = self.notebook.nametowidget(selected_tab_id)
        if hasattr(selected_tab, 'refresh_content'):
            selected_tab.refresh_content()

    def apply_styles(self, colors):
        style = tk_ttk.Style(self)
        style.configure('TFrame', background=colors.get('bg'))
        style.configure('TNotebook', background=colors.get('bg'), borderwidth=0)
        style.configure('TNotebook.Tab', background=colors.get('dark'), foreground=colors.get('fg'), padding=[10, 5], font=('Helvetica', 10, 'bold'))
        style.map('TNotebook.Tab', background=[('selected', colors.get('primary'))], foreground=[('selected', colors.get('success'))])

        self.installed_widgets_tab.apply_styles(colors)
        self.discover_widgets_tab.apply_styles(colors)

    def refresh_content(self):
        selected_tab_id = self.notebook.select()
        selected_tab = self.notebook.nametowidget(selected_tab_id)
        if hasattr(selected_tab, 'refresh_content'):
            selected_tab.refresh_content()
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################