####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
from flowork_kernel.api_contract import BaseModule
from flowork_kernel.ui_shell.shared_properties import create_debug_and_reliability_ui
import ttkbootstrap as ttk
from tkinter import StringVar, Text
import google.generativeai as genai
from google.api_core import exceptions as google_exceptions

class GeminiArtikelPlugin(BaseModule):
    """
    Plugin untuk menghasilkan artikel menggunakan Google Gemini API
    dengan penanganan error yang lebih baik.
    """
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)
        self.logger(f"Plugin '{self.manifest.get('name')}' berhasil diinisialisasi.", "INFO")

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        prompt = config.get('prompt')
        api_key_var = config.get('api_key_var')
        model_name = config.get('model_name', 'gemini-1.5-flash-latest')

        if not api_key_var:
            raise ValueError("Nama Variabel API Key Gemini belum diatur di properti node.")

        if not prompt:
            raise ValueError("Prompt tidak boleh kosong.")

        status_updater("Mengambil API Key...", "INFO")
        api_key = self.kernel.variable_manager.get_variable(api_key_var)

        if not api_key:
            raise ValueError(f"API Key tidak ditemukan. Pastikan variabel '{api_key_var}' ada dan berisi nilai di Pengaturan -> Manajemen Variabel.")

        if mode == 'SIMULATE':
            status_updater("Simulasi: Menghasilkan artikel", "SUCCESS")
            payload['generated_article'] = "Ini adalah contoh artikel hasil simulasi."
            return payload

        try:
            status_updater("Menghubungi Gemini API...", "INFO")
            genai.configure(api_key=api_key)
            model = genai.GenerativeModel(model_name)

            status_updater("Menghasilkan konten...", "INFO")
            self.logger(f"Mengirim prompt ke Gemini model '{model_name}'...", "DEBUG")
            response = model.generate_content(prompt)

            payload['generated_article'] = response.text
            status_updater("Artikel berhasil dibuat!", "SUCCESS")
            self.logger("Artikel dari Gemini berhasil dibuat.", "SUCCESS")

        except google_exceptions.PermissionDenied as e:
            error_msg = "Akses ditolak oleh Google. Kemungkinan besar API Key tidak valid atau belum diaktifkan untuk Gemini API."
            self.logger(f"{error_msg} Detail: {e}", "ERROR")
            status_updater(error_msg, "ERROR")
            raise ConnectionRefusedError(error_msg) from e

        except google_exceptions.GoogleAPICallError as e:
            error_msg = f"Terjadi error saat memanggil API Google. Cek koneksi atau status layanan Google. Detail: {e}"
            self.logger(error_msg, "ERROR")
            status_updater(f"Error API Call: {e}", "ERROR")
            raise ConnectionError(error_msg) from e

        except Exception as e:
            error_msg = f"Terjadi kesalahan tak terduga: {e}"
            self.logger(f"Error tidak terduga di modul Gemini: {error_msg}", "ERROR")
            status_updater(f"Error: {e}", "ERROR")
            raise e

        return payload

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        config = get_current_config()
        created_vars = {}

        api_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_gemini_api_settings_title', fallback="Pengaturan API Gemini"))
        api_frame.pack(fill='x', padx=5, pady=10)

        ttk.Label(api_frame, text=self.loc.get('prop_api_key_var_label', fallback="Nama Variabel API Key:")).pack(anchor='w', padx=10, pady=(5,0))
        api_key_var_sv = StringVar(value=config.get('api_key_var', 'GEMINI_API_KEY'))
        ttk.Entry(api_frame, textvariable=api_key_var_sv).pack(fill='x', padx=10, pady=(0,5))
        created_vars['api_key_var'] = api_key_var_sv
        ttk.Label(api_frame, text=self.loc.get('prop_api_key_var_help', fallback="Simpan API Key Anda di Pengaturan -> Manajemen Variabel."), font=("Helvetica", 8, "italic")).pack(anchor='w', padx=10, pady=(0,10))

        ttk.Label(api_frame, text=self.loc.get('prop_model_label', fallback="Model Gemini:")).pack(anchor='w', padx=10, pady=(5,0))
        model_name_sv = StringVar(value=config.get('model_name', 'gemini-1.5-flash-latest'))
        ttk.Entry(api_frame, textvariable=model_name_sv).pack(fill='x', padx=10, pady=(0,10))
        created_vars['model_name'] = model_name_sv

        prompt_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_prompt_label', fallback="Prompt Artikel"))
        prompt_frame.pack(fill='both', expand=True, padx=5, pady=5)

        prompt_text = Text(prompt_frame, height=10, font=("Segoe UI", 9))
        prompt_text.pack(fill='both', expand=True, padx=5, pady=5)
        prompt_text.insert('1.0', config.get('prompt', ''))
        created_vars['prompt'] = prompt_text

        debug_vars = create_debug_and_reliability_ui(parent_frame, config, self.loc)
        created_vars.update(debug_vars)

        return created_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################