####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import os
import json
import time
from flowork_kernel.api_contract import BaseModule

class MetricsLogger(BaseModule):
    """
    Service yang berjalan di background, mendengarkan event METRICS_UPDATED
    dan mencatatnya ke sebuah file untuk dianalisa nanti oleh widget lain.
    """
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)
        self.history_file_path = os.path.join(self.kernel.data_path, "metrics_history.jsonl")

    def on_load(self):
        """Saat plugin dimuat, langsung subscribe ke event bus."""
        if hasattr(self, 'logger'):
            self.logger("Metrics Logger: Siap mencatat histori metrik.", "INFO")

        self.event_bus.subscribe(
            event_name="METRICS_UPDATED",
            subscriber_id=self.module_id,
            callback=self.on_metrics_updated
        )

    def on_unload(self):
        """Saat plugin dinonaktifkan, berhenti mendengarkan event."""
        if hasattr(self, 'logger'):
            self.logger("Metrics Logger: Berhenti mencatat histori metrik.", "INFO")


    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        return payload

    def on_metrics_updated(self, metrics_data):
        """
        Callback yang dieksekusi setiap kali ada event METRICS_UPDATED.
        """
        log_entry = {
            "timestamp": time.time(),
            "metrics": metrics_data
        }

        try:
            with open(self.history_file_path, 'a', encoding='utf-8') as f:
                f.write(json.dumps(log_entry) + '\\n')
        except Exception as e:
            if hasattr(self, 'logger'):
                self.logger(f"Metrics Logger: Gagal menulis ke file histori: {e}", "ERROR")
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################