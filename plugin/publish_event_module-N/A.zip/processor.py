####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import json
from flowork_kernel.api_contract import BaseModule
import ttkbootstrap as ttk
from tkinter import StringVar, Text
from flowork_kernel.ui_shell import shared_properties

class PublishEventModule(BaseModule):
    """
    Modul untuk menerbitkan (publish) sebuah event kustom ke Event Bus,
    yang bisa didengarkan oleh modul lain (seperti Receiver).
    """

    TIER = "free"

    def execute(self, payload: dict, config: dict, status_updater, ui_callback, mode: str = 'EXECUTE'):
        event_name = config.get('event_name', '').strip()
        event_data_raw = config.get('event_data', '{}')

        if not event_name:
            self.kernel.stop_workflow_execution()
            raise ValueError("Nama Event tidak boleh kosong.")

        event_data = {}
        try:
            if isinstance(event_data_raw, dict):
                event_data = event_data_raw
            elif isinstance(event_data_raw, str):
                valid_json_string = event_data_raw.replace("'", '"')
                event_data = json.loads(valid_json_string) if valid_json_string.strip() else {}
            else:
                raise TypeError(f"Tipe data untuk Event Data tidak didukung: {type(event_data_raw)}")

        except (json.JSONDecodeError, TypeError) as e:
            self.kernel.stop_workflow_execution()
            raise ValueError(f"Format JSON pada Event Data tidak valid atau tipe data salah: {e}")

        if mode == 'SIMULATE':
            status_updater(f"Simulasi: Event '{event_name}' akan diterbitkan.", "INFO")
            return payload

        self.event_bus.publish(event_name, event_data, self.module_id)
        status_updater(f"Event '{event_name}' diterbitkan.", "SUCCESS")

        return payload

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        config = get_current_config()
        created_vars = {}

        main_frame = ttk.LabelFrame(parent_frame, text=self.loc.get('prop_publish_event_title'))
        main_frame.pack(fill='x', padx=5, pady=10)

        ttk.Label(main_frame, text=self.loc.get('prop_event_name_label')).pack(anchor='w', padx=10, pady=(5,0))
        event_name_var = StringVar(value=config.get('event_name', 'MY_CUSTOM_EVENT'))
        ttk.Entry(main_frame, textvariable=event_name_var).pack(fill='x', padx=10, pady=(0, 10))
        created_vars['event_name'] = event_name_var

        ttk.Label(main_frame, text=self.loc.get('prop_event_data_label')).pack(anchor='w', padx=10, pady=(5,0))
        event_data_text = Text(main_frame, height=6, font=("Consolas", 9))
        event_data_text.pack(fill='x', padx=10, pady=(0, 10))
        event_data_text.insert('1.0', config.get('event_data', '{\n    "info": "data penting"\n}'))
        created_vars['event_data'] = event_data_text

        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, config, self.loc)
        created_vars.update(debug_vars)

        loop_vars = shared_properties.create_loop_settings_ui(parent_frame, config, self.loc, available_vars)
        created_vars.update(loop_vars)

        return created_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################