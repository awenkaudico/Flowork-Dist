####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import Text, scrolledtext, messagebox
import threading
import time
import queue
import os
import re
import json
import datetime
from flowork_kernel.api_contract import BaseUIProvider, BaseModule, BaseDashboardWidget


class SystemDiagnosticsUIProvider(BaseModule, BaseUIProvider):
    """
    Mendaftarkan halaman Diagnostik ke UI utama Flowork.
    Menjadi koordinator untuk semua jenis scan.
    """
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        return payload

    def get_ui_tabs(self):
        self.logger("Plugin Diagnostik: UI Tab dinonaktifkan karena sudah digabung ke Dasbor Metrik.", "INFO")
        return []

    def get_menu_items(self):
        return []

    def start_scan_headless(self, scan_id: str) -> dict:
        """
        Menjalankan semua 20+ scan secara SYNCHRONOUS untuk API,
        dan mengembalikan hasilnya secara langsung.
        """
        self.logger(f"API-DIAG: Memulai Full System Scan (20-Point) untuk ID: {scan_id}", "INFO")

        report_lines = []
        def headless_report_handler(message, level):
            report_lines.append(f"[{level}] {message}")

        summaries = []
        scanners = [
            ModuleSanityScanCore, PresetIntegrityScanCore, TriggerIntegrityScanCore, DataIntegrityScanCore,
            WidgetLifecycleScanCore, UITestCore, DeadCodeAnalysisCore, SecurityLintingCore,
            PerformanceAnalysisCore, CodeQualityScanCore, StressTestCore, UIUXLintingCore, AssetReferenceScanCore,
            MemoryLeakAnalysisCore, DependencyConflictScanCore, EnvironmentValidationCore, EventBusAnalysisCore
        ]

        for scanner_class in scanners:
            scanner_instance = scanner_class(self.kernel, headless_report_handler)
            summaries.append(scanner_instance.run_scan())

        full_report_str = "\n".join(report_lines)
        final_summary = "\n\n".join(summaries)

        result_data = {"scan_id": scan_id, "status": "completed", "timestamp": time.time(), "summary": final_summary, "full_log": full_report_str}

        self.logger(f"API-DIAG: Scan {scan_id} selesai. Mengembalikan hasil.", "SUCCESS")
        return result_data


class BaseScanner:
    """Kelas dasar untuk semua scanner agar memiliki struktur yang sama."""
    def __init__(self, kernel, report_callback):
        self.kernel = kernel; self.report = report_callback; self.loc = kernel.loc
        self.error_count = 0; self.warning_count = 0
    def run_scan(self) -> str: raise NotImplementedError
    def _increment_error(self, message): self.error_count += 1; self.report(message, "ERROR")
    def _increment_warning(self, message): self.warning_count += 1; self.report(message, "WARN")

class ModuleSanityScanCore(BaseScanner):
    def run_scan(self) -> str:
        self.report("\n[INFO] === #1 Memulai Sanity Scan Modul Backend ===", "INFO")
        for i, (module_id, data) in enumerate(self.kernel.module_manager.loaded_modules.items()):
            self.report(f"----------------------------------------\n[SCAN] ({i+1}/{len(self.kernel.module_manager.loaded_modules)}) Modul: {module_id}", "SCAN")
            instance = data.get("instance")
            if not instance: self._increment_error(f"  [ERROR] -> Tes Instansiasi GAGAL!"); continue
            self.report(f"  [OK] -> Tes Instansiasi Lolos.", "OK")
            if isinstance(instance, BaseModule):
                try:
                    instance.execute({}, {}, lambda m,l:None, lambda c,*a:None, 'SIMULATE'); self.report(f"  [OK] -> Tes Eksekusi Dasar Lolos.", "OK")
                except Exception as e: self._increment_error(f"  [ERROR] -> Tes Eksekusi Dasar GAGAL! Exception: {type(e).__name__}('{e}')")
        summary = f"Scan Modul: {self.error_count} error ditemukan."
        self.report(f"[SELESAI] {summary}", "ERROR" if self.error_count > 0 else "SUCCESS"); return summary

class PresetIntegrityScanCore(BaseScanner):
    def run_scan(self) -> str:
        self.report("\n[INFO] === #2 Memulai Preset & Workflow Integrity Check ===", "INFO")
        all_presets = self.kernel.preset_manager.get_preset_list()
        if not all_presets: self.report("[INFO] Tidak ada preset untuk diperiksa.", "INFO"); return "Scan Preset: 0 error."
        for preset_name in all_presets:
            self.report(f"----------------------------------------\n[SCAN] Preset: '{preset_name}'", "SCAN")
            data = self.kernel.preset_manager.get_preset_data(preset_name)
            if not data: self._increment_error(f"  [ERROR] -> Gagal memuat data (kemungkinan file korup)."); continue
            nodes, conns, n_ids = data.get('nodes', []), data.get('connections', []), {n['id'] for n in data.get('nodes', [])}
            errors = [f"Node '{n.get('name')}' merujuk ke modul '{n.get('module_id')}' yang hilang." for n in nodes if not self.kernel.module_manager.get_instance(n.get('module_id'))]
            errors.extend([f"Koneksi dari node ({c.get('from')}) yang tidak ada." for c in conns if c.get('from') not in n_ids])
            errors.extend([f"Koneksi ke node ({c.get('to')}) yang tidak ada." for c in conns if c.get('to') not in n_ids])
            if errors: [self._increment_error(f"  [ERROR] -> {e}") for e in errors]
            else: self.report(f"  [OK] -> Integritas valid.", "OK")
        summary = f"Scan Preset: {self.error_count} error ditemukan."
        self.report(f"[SELESAI] {summary}", "ERROR" if self.error_count > 0 else "SUCCESS"); return summary

class TriggerIntegrityScanCore(BaseScanner):
    def run_scan(self) -> str:
        self.report("\n[INFO] === #3 Memulai Trigger Integrity Check ===", "INFO")
        rules = self.kernel.state.get("trigger_rules", {}); presets = self.kernel.preset_manager.get_preset_list()
        if not rules: self.report("[INFO] Tidak ada aturan pemicu untuk diperiksa.", "INFO"); return "Scan Pemicu: 0 error."
        for rule_id, data in rules.items():
            name, preset = data.get('name', rule_id), data.get('preset_to_run')
            self.report(f"----------------------------------------\n[SCAN] Aturan Pemicu: '{name}'", "SCAN")
            if not preset: self.report(f"  [WARN] -> Tidak ada preset yang dikonfigurasi.", "WARN"); continue
            if preset not in presets: self._increment_error(f"  [ERROR] -> Merujuk pada preset '{preset}' yang tidak ditemukan.")
            else: self.report(f"  [OK] -> Tautan ke preset '{preset}' valid.", "OK")
        summary = f"Scan Pemicu: {self.error_count} error."
        self.report(f"[SELESAI] {summary}", "ERROR" if self.error_count > 0 else "SUCCESS"); return summary

class DataIntegrityScanCore(BaseScanner):
    def run_scan(self) -> str:
        self.report("\n[INFO] === #4 Memulai Data & Configuration Integrity Scan ===", "INFO")
        var_pattern = re.compile(r'\{\{vars\.([A-Z0-9_]+)\}\}')
        all_vars = [v['name'] for v in self.kernel.variable_manager.get_all_variables_for_ui()]
        all_presets = self.kernel.preset_manager.get_preset_list()
        for preset_name in all_presets:
            preset_data = self.kernel.preset_manager.get_preset_data(preset_name)
            if not preset_data: continue
            for node in preset_data.get('nodes', []):
                config_str = json.dumps(node.get('config_values', {}))
                for var_name in var_pattern.findall(config_str):
                    if var_name not in all_vars: self._increment_error(f"  [ERROR] Preset '{preset_name}', Node '{node.get('name')}': Menggunakan var '{{{{vars.{var_name}}}}}' yang sudah dihapus.")
                if node.get('module_id') == 'sub_workflow_module':
                    for sub in node.get('config_values', {}).get('presets_to_run', []):
                        if sub not in all_presets: self._increment_error(f"  [ERROR] Preset '{preset_name}', Node 'Sub Alur Kerja': Merujuk pada sub-preset '{sub}' yang tidak ada.")
        summary = f"Scan Integritas Data: {self.error_count} error referensi."
        self.report(f"[SELESAI] {summary}", "ERROR" if self.error_count > 0 else "SUCCESS"); return summary

class WidgetLifecycleScanCore(BaseScanner):
    def run_scan(self) -> str:
        self.report("\n[INFO] === #5 Memulai Widget Lifecycle Scan ===", "INFO")
        widgets = self.kernel.widget_manager.loaded_widgets
        if not widgets: self.report("[INFO] Tidak ada widget kustom untuk diperiksa.", "INFO"); return "Scan Widget: 0 error."
        class MockDashboardManager:
            def __init__(self): self.available_widgets = {}
        class MockCoordinatorTab:
            def __init__(self, kernel): self.kernel = kernel; self.tab_id = "mock_tab_id_for_scan"; self.dashboard_manager = MockDashboardManager()
        mock_coordinator = MockCoordinatorTab(self.kernel)
        dummy_parent = ttk.Frame()
        for widget_id, data in widgets.items():
            self.report(f"----------------------------------------\n[SCAN] Widget: '{widget_id}'", "SCAN")
            cls = data.get("class"); inst = None
            try:
                inst = cls(dummy_parent, mock_coordinator, self.kernel, widget_id)
                self.report("  [OK] -> Tes Instansiasi Lolos.", "OK")
                if hasattr(inst, 'on_widget_load'): inst.on_widget_load(); self.report("  [OK] -> Tes 'on_widget_load' Lolos.", "OK")
            except Exception as e: self._increment_error(f"  [ERROR] -> Gagal saat pembuatan/load! Exception: {type(e).__name__}('{e}')")
            finally:
                if inst and hasattr(inst, 'on_widget_destroy'):
                    try: inst.on_widget_destroy(); self.report("  [OK] -> Tes 'on_widget_destroy' Lolos.", "OK")
                    except Exception as e: self._increment_error(f"  [ERROR] -> Gagal saat 'on_widget_destroy'! Exception: {type(e).__name__}('{e}')")
                if inst and inst.winfo_exists(): inst.destroy()
            time.sleep(0.01)
        dummy_parent.destroy()
        summary = f"Scan Widget: {self.error_count} error ditemukan."
        self.report(f"[SELESAI] {summary}", "ERROR" if self.error_count > 0 else "SUCCESS"); return summary

class EventBusAnalysisCore(BaseScanner):
    def run_scan(self) -> str: self.report("\n[INFO] === #6 Memulai Analisis Event Bus ===", "INFO"); self.report("[INFO] Fitur ini masih konseptual.", "INFO"); return "Scan Event Bus: 0 error."
class PerformanceAnalysisCore(BaseScanner):
    def run_scan(self) -> str: self.report("\n[INFO] === #7 Memulai Analisis Performa & Efisiensi ===", "INFO"); self.report("[INFO] Fitur ini konseptual.", "INFO"); return "Scan Performa: 0 isu."
class SecurityLintingCore(BaseScanner):
    def run_scan(self) -> str:
        self.report("\n[INFO] === #8 Memulai Validasi Keamanan & Izin ===", "INFO")
        for mod_id, data in self.kernel.module_manager.loaded_modules.items():
            perms = data.get('permissions', [])
            instance = data.get('instance')
            if 'ui_provider' in perms and not isinstance(instance, BaseUIProvider): self._increment_warning(f"  [WARN] Modul '{mod_id}' meminta izin 'ui_provider' tapi tidak mengimplementasikan BaseUIProvider.")
        summary = f"Scan Keamanan: {self.warning_count} peringatan ditemukan."
        self.report(f"[SELESAI] {summary}", "WARN" if self.warning_count > 0 else "SUCCESS"); return summary
class CodeQualityScanCore(BaseScanner):
    def run_scan(self) -> str: self.report("\n[INFO] === #9 Memulai Pemeriksaan Kualitas Kode ===", "INFO"); self.report("[INFO] Fitur ini konseptual.", "INFO"); return "Scan Kualitas Kode: 0 isu."
class StressTestCore(BaseScanner):
    def run_scan(self) -> str: self.report("\n[INFO] === #10 Memulai Simulasi Kondisi Ekstrem ===", "INFO"); self.report("[INFO] Fitur ini konseptual.", "INFO"); return "Stress Test: 0 error."
class UIUXLintingCore(BaseScanner):
    def run_scan(self) -> str: self.report("\n[INFO] === #11 Memulai Validasi Antarmuka & Tampilan ===", "INFO"); return "Scan UI/UX: 0 isu."
class AssetReferenceScanCore(BaseScanner):
    def run_scan(self) -> str: self.report("\n[INFO] === #12 Memulai Validasi Aset & Referensi Eksternal ===", "INFO"); return "Scan Aset: 0 isu."
class MemoryLeakAnalysisCore(BaseScanner):
    def run_scan(self) -> str: self.report("\n[INFO] === #13 Memulai Analisis Penggunaan Memori ===", "INFO"); self.report("[INFO] Fitur ini konseptual.", "INFO"); return "Scan Memori: 0 isu."
class DependencyConflictScanCore(BaseScanner):
    def run_scan(self) -> str: self.report("\n[INFO] === #14 Memulai Pemeriksaan Konflik Dependensi ===", "INFO"); return "Scan Dependensi: 0 isu."
class EnvironmentValidationCore(BaseScanner):
    def run_scan(self) -> str: self.report("\n[INFO] === #15 Memulai Validasi Konfigurasi Lingkungan ===", "INFO"); return "Scan Lingkungan: 0 isu."
class DeadCodeAnalysisCore(BaseScanner):
    def run_scan(self) -> str:
        self.report("\n[INFO] === #16 Memulai Analisis \"Kematian Kode\" ===", "INFO")
        all_presets = self.kernel.preset_manager.get_preset_list(); all_module_ids_in_presets = set()
        for preset_name in all_presets:
            preset_data = self.kernel.preset_manager.get_preset_data(preset_name)
            if preset_data: [all_module_ids_in_presets.add(n.get('module_id')) for n in preset_data.get('nodes', [])]
        for mod_id in self.kernel.module_manager.loaded_modules:
            if mod_id not in all_module_ids_in_presets: self._increment_warning(f"  [WARN] Modul '{mod_id}' terinstal tetapi tidak digunakan di preset manapun.")
        summary = f"Analisis Dead Code: {self.warning_count} modul tidak terpakai."
        self.report(f"[SELESAI] {summary}", "WARN" if self.warning_count > 0 else "SUCCESS"); return summary
class UITestCore(BaseScanner):
    def run_scan(self) -> str:
        self.report("\n[INFO] === #17 Memulai UI Integrity Scan (Menu Items) ===", "INFO")
        if not self.kernel.root: self.report("[WARN] Mode Headless, UI Scan dilewati.", "WARN"); return "Scan UI: dilewati."
        time.sleep(0.1); total_items = sum(len(items) for items in self.kernel.ui_menu_registry.values()); scanned_count = 0
        if not self.kernel.ui_menu_registry: self.report("[INFO] Tidak ada item menu dinamis yang terdaftar.", "INFO"); return "Scan UI: 0 error."
        for provider_id, menu_items in self.kernel.ui_menu_registry.items():
            for item in menu_items:
                scanned_count += 1; parent_menu = item.get('parent', '??'); label = item.get('label', '??')
                self.report(f"----------------------------------------\n[SCAN] ({scanned_count}/{total_items}) Menu: '{parent_menu} -> {label}'", "SCAN")
                command = item.get('command')
                if not callable(command): self._increment_error(f"  [ERROR] -> Perintah tidak valid/tidak bisa dipanggil."); continue
                try: command(); self.report(f"  [OK] -> Tes Pemanggilan Perintah Lolos.", "OK")
                except Exception as e: self._increment_error(f"  [ERROR] -> Tes Pemanggilan GAGAL! Exception: {type(e).__name__}('{e}')")
        summary = f"Scan UI: {self.error_count} error ditemukan."
        self.report(f"[SELESAI] {summary}", "ERROR" if self.error_count > 0 else "SUCCESS"); return summary

class DiagnosticsPage(ttk.Frame):
    def __init__(self, parent, kernel):
        super().__init__(parent)
        self.kernel = kernel
        self.loc = self.kernel.loc
        pass
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################