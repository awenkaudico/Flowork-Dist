####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
from flowork_kernel.api_contract import BaseModule, BaseUIProvider
from tkinter import messagebox
import ttkbootstrap as ttk
from tkinter import StringVar
from flowork_kernel.ui_shell import shared_properties

class TampilkanVariabelModule(BaseModule):
    """
    Contoh modul yang menampilkan nilai dari variabel global/secret.
    """
    TIER = "free"

    def __init__(self, module_id, services):
        super().__init__(module_id, services)
        self.logger(f"Plugin Demo '{self.manifest.get('name')}' versi final berhasil diinisialisasi.", "INFO")

    def execute(self, payload: dict, config: dict, status_updater, ui_callback, mode: str = 'EXECUTE'):
        status_updater("Memulai...", "INFO")
        target_variable = config.get("variabel_target")

        if not target_variable:
            self.kernel.stop_workflow_execution()
            raise ValueError("Konfigurasi 'variabel_target' tidak boleh kosong.")

        if mode == 'SIMULATE':
            status_updater(f"Simulasi: Akan menampilkan var '{target_variable}'", "INFO")
            return payload

        var_value = self.variable_manager.get_variable(target_variable)

        if var_value is not None:
            message_text = f"Nilai dari '{target_variable}' adalah:\n\n{var_value}"
            ui_callback(messagebox.showinfo, "Nilai Variabel", message_text)
            status_updater(self.loc.get('status_showing_variable', var_name=target_variable), "SUCCESS")
        else:
            status_updater(self.loc.get('status_variable_not_found', var_name=target_variable), "ERROR")
            self.kernel.stop_workflow_execution()
            raise ValueError(f"Variabel '{target_variable}' tidak ditemukan di Pengaturan.")

        return payload

    def create_properties_ui(self, parent_frame, get_current_config, available_vars):
        config = get_current_config()
        created_vars = {}

        all_variables = [v['name'] for v in self.variable_manager.get_all_variables_for_ui()]

        main_frame = ttk.LabelFrame(parent_frame, text="Pengaturan Spesifik")
        main_frame.pack(fill='x', padx=5, pady=(10, 5))

        ttk.Label(main_frame, text=self.loc.get('prop_var_to_display_label')).pack(anchor='w', padx=10, pady=(5,0))

        created_vars['variabel_target'] = StringVar(value=config.get('variabel_target', ''))

        var_combobox = ttk.Combobox(
            main_frame,
            textvariable=created_vars['variabel_target'],
            values=all_variables,
            state='readonly'
        )
        var_combobox.pack(fill='x', padx=10, pady=(5, 10))

        debug_vars = shared_properties.create_debug_and_reliability_ui(parent_frame, config, self.loc)
        created_vars.update(debug_vars)

        loop_vars = shared_properties.create_loop_settings_ui(parent_frame, config, self.loc, available_vars)
        created_vars.update(loop_vars)

        return created_vars
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################