####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import StringVar, Frame

class CronConfigUI(ttk.Frame):
    """
    UI Konfigurasi Cronjob yang user-friendly, menerjemahkan input simpel
    menjadi cron string secara otomatis.
    """
    def __init__(self, parent, loc, initial_config):
        super().__init__(parent)
        self.loc = loc

        self.schedule_type_var = StringVar(value='daily') # Default ke harian
        self.vars = {
            'every_x_minutes': StringVar(value='5'),
            'hourly_minute': StringVar(value='0'),
            'daily_hour': StringVar(value='9'),
            'daily_minute': StringVar(value='0'),
            'weekly_days': {i: ttk.BooleanVar(value=False) for i in range(7)}, # 0=Senin, 6=Minggu
            'weekly_hour': StringVar(value='9'),
            'weekly_minute': StringVar(value='0'),
        }

        self._parse_initial_config(initial_config.get('cron_string', '0 9 * * *'))

        self._create_widgets()
        self._on_schedule_type_change()

    def _create_widgets(self):
        """Membuat semua widget UI."""
        type_frame = ttk.LabelFrame(self, text=self.loc.get('cron_ui_schedule_type', fallback="Tipe Jadwal"))
        type_frame.pack(fill='x', expand=True, pady=(0, 10))

        ttk.Radiobutton(type_frame, text=self.loc.get('cron_ui_every_x_minutes', fallback="Setiap X Menit"),
                        variable=self.schedule_type_var, value='minutes', command=self._on_schedule_type_change).pack(anchor='w', padx=5)
        ttk.Radiobutton(type_frame, text=self.loc.get('cron_ui_every_hour', fallback="Setiap Jam"),
                        variable=self.schedule_type_var, value='hourly', command=self._on_schedule_type_change).pack(anchor='w', padx=5)
        ttk.Radiobutton(type_frame, text=self.loc.get('cron_ui_daily', fallback="Setiap Hari"),
                        variable=self.schedule_type_var, value='daily', command=self._on_schedule_type_change).pack(anchor='w', padx=5)
        ttk.Radiobutton(type_frame, text=self.loc.get('cron_ui_weekly', fallback="Setiap Minggu"),
                        variable=self.schedule_type_var, value='weekly', command=self._on_schedule_type_change).pack(anchor='w', padx=5)

        self.details_frame = ttk.Frame(self)
        self.details_frame.pack(fill='x', expand=True, pady=10)

    def _on_schedule_type_change(self):
        """Menampilkan UI yang sesuai dengan tipe jadwal yang dipilih."""
        for widget in self.details_frame.winfo_children():
            widget.destroy()

        schedule_type = self.schedule_type_var.get()

        if schedule_type == 'minutes':
            self._create_minutes_ui()
        elif schedule_type == 'hourly':
            self._create_hourly_ui()
        elif schedule_type == 'daily':
            self._create_daily_ui()
        elif schedule_type == 'weekly':
            self._create_weekly_ui()

    def _create_minutes_ui(self):
        """UI untuk jadwal 'Setiap X Menit'."""
        frame = self.details_frame
        ttk.Label(frame, text=self.loc.get('cron_ui_run_every', fallback="Jalankan setiap")).pack(side='left', padx=(0, 5))
        ttk.Entry(frame, textvariable=self.vars['every_x_minutes'], width=5).pack(side='left')
        ttk.Label(frame, text=self.loc.get('cron_ui_minutes_label', fallback="menit")).pack(side='left', padx=5)

    def _create_hourly_ui(self):
        """UI untuk jadwal 'Setiap Jam'."""
        frame = self.details_frame
        ttk.Label(frame, text=self.loc.get('cron_ui_run_at_minute', fallback="Jalankan pada menit ke-")).pack(side='left', padx=(0, 5))
        ttk.Entry(frame, textvariable=self.vars['hourly_minute'], width=5).pack(side='left')

    def _create_daily_ui(self):
        """UI untuk jadwal 'Setiap Hari'."""
        frame = self.details_frame
        ttk.Label(frame, text=self.loc.get('cron_ui_run_at_time', fallback="Jalankan pada pukul")).pack(side='left', padx=(0, 5))
        ttk.Entry(frame, textvariable=self.vars['daily_hour'], width=5).pack(side='left')
        ttk.Label(frame, text=":").pack(side='left', padx=2)
        ttk.Entry(frame, textvariable=self.vars['daily_minute'], width=5).pack(side='left')

    def _create_weekly_ui(self):
        """UI untuk jadwal 'Setiap Minggu'."""
        frame = self.details_frame
        days_frame = ttk.Frame(frame)
        days_frame.pack(fill='x', pady=(0,10))
        days = [
            self.loc.get('day_mon', fallback="Sen"), self.loc.get('day_tue', fallback="Sel"),
            self.loc.get('day_wed', fallback="Rab"), self.loc.get('day_thu', fallback="Kam"),
            self.loc.get('day_fri', fallback="Jum"), self.loc.get('day_sat', fallback="Sab"),
            self.loc.get('day_sun', fallback="Min")
        ]
        for i, day_text in enumerate(days):
            ttk.Checkbutton(days_frame, text=day_text, variable=self.vars['weekly_days'][i]).pack(side='left', expand=True)

        time_frame = ttk.Frame(frame)
        time_frame.pack(fill='x')
        ttk.Label(time_frame, text=self.loc.get('cron_ui_run_at_time', fallback="Jalankan pada pukul")).pack(side='left', padx=(0, 5))
        ttk.Entry(time_frame, textvariable=self.vars['weekly_hour'], width=5).pack(side='left')
        ttk.Label(time_frame, text=":").pack(side='left', padx=2)
        ttk.Entry(time_frame, textvariable=self.vars['weekly_minute'], width=5).pack(side='left')

    def _parse_initial_config(self, cron_string):
        """Mencoba mem-parsing cron string untuk mengisi UI."""
        parts = cron_string.split()
        if len(parts) != 5: return

        minute, hour, day_month, month, day_week = parts

        if day_week != '*' and day_month == '*' and month == '*':
            self.schedule_type_var.set('weekly')
            self.vars['weekly_hour'].set(hour if hour != '*' else '9')
            self.vars['weekly_minute'].set(minute if minute != '*' else '0')
            selected_days = day_week.split(',')
            for i in range(7):
                if str(i) in selected_days:
                    self.vars['weekly_days'][i].set(True)
        elif minute.startswith('*/'):
            self.schedule_type_var.set('minutes')
            self.vars['every_x_minutes'].set(minute[2:])
        elif hour == '*' and day_month == '*' and month == '*':
            self.schedule_type_var.set('hourly')
            self.vars['hourly_minute'].set(minute)
        else: # Default ke Harian
            self.schedule_type_var.set('daily')
            self.vars['daily_hour'].set(hour if hour != '*' else '9')
            self.vars['daily_minute'].set(minute if minute != '*' else '0')

    def get_config(self):
        """Membangun cron string dari input UI."""
        schedule_type = self.schedule_type_var.get()
        cron_string = "* * * * *" # Default

        if schedule_type == 'minutes':
            minute = self.vars['every_x_minutes'].get()
            cron_string = f"*/{minute} * * * *"
        elif schedule_type == 'hourly':
            minute = self.vars['hourly_minute'].get()
            cron_string = f"{minute} * * * *"
        elif schedule_type == 'daily':
            hour = self.vars['daily_hour'].get()
            minute = self.vars['daily_minute'].get()
            cron_string = f"{minute} {hour} * * *"
        elif schedule_type == 'weekly':
            hour = self.vars['weekly_hour'].get()
            minute = self.vars['weekly_minute'].get()
            days = [str(i) for i, var in self.vars['weekly_days'].items() if var.get()]
            day_string = ",".join(days) if days else '*'
            cron_string = f"{minute} {hour} * * {day_string}"

        return {"cron_string": cron_string}
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################