####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
from flowork_kernel.api_contract import BaseTriggerListener

class EventBusListener(BaseTriggerListener):
    """
    Listener yang mendengarkan event spesifik pada Event Bus internal Flowork.
    """
    def __init__(self, trigger_id: str, config: dict, services: dict, rule_id: str):
        super().__init__(trigger_id, config, services)
        self.rule_id = rule_id

        self.event_name_to_listen = self.config.get("event_name", "")

        self.event_bus = getattr(self, 'event_bus', None)

    def start(self):
        """
        Mulai berlangganan ke event yang ditentukan di Event Bus.
        """
        if not self.event_name_to_listen:
            self.logger(f"Pemicu Event Bus '{self.rule_id}': Nama event tidak dikonfigurasi. Pemicu tidak akan dimulai.", "ERROR")
            return

        if not self.event_bus:
            self.logger(f"Pemicu Event Bus '{self.rule_id}': Layanan Event Bus tidak tersedia. Pemicu gagal.", "ERROR")
            return

        subscriber_id = f"trigger_listener_{self.rule_id}"
        self.event_bus.subscribe(self.event_name_to_listen, subscriber_id, self._handle_internal_event)

        self.is_running = True
        self.logger(f"Pemicu Event Bus '{self.rule_id}': Mulai mendengarkan event '{self.event_name_to_listen}'.", "INFO")

    def stop(self):
        """
        Berhenti berlangganan dari Event Bus.
        (Saat ini, EventBus tidak memiliki metode unsubscribe, jadi kita hanya log saja).
        """
        if self.is_running:
            self.is_running = False
            self.logger(f"Pemicu Event Bus '{self.rule_id}': Langganan ke event '{self.event_name_to_listen}' dihentikan (secara konseptual).", "INFO")

    def _handle_internal_event(self, event_data_from_bus: dict):
        """
        Metode ini akan secara otomatis dipanggil oleh EventBus saat event terjadi.
        """
        if not self.is_running:
            return

        event_data_to_report = {
            "trigger_id": self.trigger_id,
            "rule_id": self.rule_id,
            "event_type": "event_bus_received",
            "source_event_name": self.event_name_to_listen,
            "source_event_data": event_data_from_bus
        }

        self._on_event(event_data_to_report)
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################