####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import time
import os
import threading
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileModifiedEvent, FileCreatedEvent, FileDeletedEvent, FileMovedEvent
from flowork_kernel.api_contract import BaseTriggerListener

class _InternalEventHandler(FileSystemEventHandler):
    """Kelas internal untuk menangani event dari watchdog dan meneruskannya."""
    def __init__(self, listener_instance):
        self.listener = listener_instance

    def on_any_event(self, event):
        if event.is_directory:
            return

        event_type = "unknown"
        if isinstance(event, FileCreatedEvent):
            event_type = "created"
        elif isinstance(event, FileModifiedEvent):
            event_type = "modified"
        elif isinstance(event, FileDeletedEvent):
            event_type = "deleted"
        elif isinstance(event, FileMovedEvent):
            event_type = "moved"

        event_data = {
            "trigger_id": self.listener.trigger_id,
            "rule_id": self.listener.rule_id, # Sertakan ID aturan untuk identifikasi
            "event_type": event_type,
            "src_path": event.src_path
        }

        if isinstance(event, FileMovedEvent):
            event_data["dest_path"] = event.dest_path

        self.listener._on_event(event_data)


class FileSystemListener(BaseTriggerListener):
    """
    Listener yang memantau perubahan pada sistem file (dibuat, diubah, dihapus).
    """
    def __init__(self, trigger_id: str, config: dict, services: dict, rule_id: str):
        super().__init__(trigger_id, config, services)
        self.rule_id = rule_id # ID unik dari aturan yang menggunakan instance ini
        self._observer = None
        self.path_to_watch = self.config.get("path_to_watch")
        self.events_to_watch = self.config.get("events_to_watch", [])

    def start(self):
        """Memulai thread pemantauan sistem file."""
        if not self.path_to_watch or not os.path.isdir(self.path_to_watch):
            self.logger(f"Pemicu File '{self.rule_id}': Path '{self.path_to_watch}' tidak valid atau bukan direktori. Pemicu tidak akan dimulai.", "ERROR")
            return

        self.is_running = True
        event_handler = _InternalEventHandler(self)
        self._observer = Observer()
        self._observer.schedule(event_handler, self.path_to_watch, recursive=True)

        self.thread = threading.Thread(target=self._run_observer, daemon=True)
        self.thread.start()
        self.logger(f"Pemicu File '{self.rule_id}': Mulai memantau folder '{self.path_to_watch}'.", "INFO")

    def _run_observer(self):
        """Metode internal yang dijalankan oleh thread."""
        try:
            self._observer.start()
            while self.is_running:
                time.sleep(1)
        finally:
            if self._observer.is_alive():
                self._observer.stop()
            self._observer.join()

    def stop(self):
        """Menghentikan pemantauan."""
        if self.is_running:
            self.is_running = False
            if self._observer and self._observer.is_alive():
                self._observer.stop()
            self.logger(f"Pemicu File '{self.rule_id}': Pemantauan dihentikan.", "INFO")
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################