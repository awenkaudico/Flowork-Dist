####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import threading
import time
import psutil
from flowork_kernel.api_contract import BaseTriggerListener

class ProcessListener(BaseTriggerListener):
    """
    Listener yang memantau proses aplikasi yang dimulai atau dihentikan.
    """
    def __init__(self, trigger_id: str, config: dict, services: dict, rule_id: str):
        super().__init__(trigger_id, config, services)
        self.rule_id = rule_id

        self.process_name = self.config.get("process_name", "").lower()
        self.event_to_watch = self.config.get("event_to_watch", "started") # 'started' atau 'stopped'
        self.polling_interval = self.config.get("polling_interval", 2) # Detik

        self._thread = None
        self._known_pids = set()

    def start(self):
        """Memulai thread pemantauan proses."""
        if not self.process_name:
            self.logger(f"Pemicu Proses '{self.rule_id}': Nama proses tidak dikonfigurasi. Pemicu tidak akan dimulai.", "ERROR")
            return

        self.is_running = True
        self._known_pids = {p.pid for p in psutil.process_iter(['pid', 'name']) if self.process_name in p.info['name'].lower()}

        self._thread = threading.Thread(target=self._monitor_processes, daemon=True)
        self._thread.start()
        self.logger(f"Pemicu Proses '{self.rule_id}': Mulai memantau proses '{self.process_name}'.", "INFO")

    def stop(self):
        """Menghentikan pemantauan."""
        if self.is_running:
            self.is_running = False
            self.logger(f"Pemicu Proses '{self.rule_id}': Pemantauan dihentikan.", "INFO")

    def _monitor_processes(self):
        """Metode yang berjalan di thread terpisah untuk memantau proses."""
        while self.is_running:
            try:
                current_pids = {p.pid for p in psutil.process_iter(['pid', 'name']) if self.process_name in p.info['name'].lower()}

                if self.event_to_watch == "started":
                    new_pids = current_pids - self._known_pids
                    for pid in new_pids:
                        process = psutil.Process(pid)
                        event_data = {
                            "trigger_id": self.trigger_id,
                            "rule_id": self.rule_id,
                            "event_type": "started",
                            "process_name": process.name(),
                            "pid": pid,
                            "exe_path": process.exe()
                        }
                        self._on_event(event_data)

                elif self.event_to_watch == "stopped":
                    stopped_pids = self._known_pids - current_pids
                    for pid in stopped_pids:
                        event_data = {
                            "trigger_id": self.trigger_id,
                            "rule_id": self.rule_id,
                            "event_type": "stopped",
                            "process_name": self.process_name,
                            "pid": pid
                        }
                        self._on_event(event_data)

                self._known_pids = current_pids

            except (psutil.NoSuchProcess, psutil.AccessDenied):
                self._known_pids = {p.pid for p in psutil.process_iter(['pid'])}
            except Exception as e:
                self.logger(f"Error di dalam loop pemantau proses: {e}", "ERROR")

            time.sleep(self.polling_interval)
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################