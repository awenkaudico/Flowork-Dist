####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import messagebox
from flowork_kernel.ui_shell.custom_widgets.tooltip import ToolTip
from flowork_kernel.api_contract import BaseDashboardWidget
from flowork_kernel.ui_shell.canvas_manager import CanvasManager

class CanvasAreaWidget(BaseDashboardWidget):
    """Widget yang berisi kanvas utama dan tombol-tombol aksinya."""
    def __init__(self, parent, coordinator_tab, kernel, widget_id: str):
        super().__init__(parent, coordinator_tab, kernel, widget_id)
        self.parent_tab = coordinator_tab
        self.canvas_manager = None

        self._create_widgets()

    def _create_widgets(self):
        top_action_frame = ttk.Frame(self)
        top_action_frame.pack(fill='x', pady=(0, 5))

        ttk.Button(top_action_frame, text=self.loc.get('save_workflow_button'), command=self.parent_tab.save_workflow, style='success.TButton').pack(side='left', padx=(0, 5))
        ttk.Button(top_action_frame, text=self.loc.get('load_workflow_button'), command=self.parent_tab.load_workflow, style='info.TButton').pack(side='left', padx=(0, 5))
        ttk.Button(top_action_frame, text=self.loc.get('clear_canvas_button'), command=self.parent_tab.clear_canvas, style='danger.TButton').pack(side='left', padx=5)

        zoom_frame = ttk.Frame(top_action_frame)
        zoom_frame.pack(side='left', padx=15)

        self.zoom_label = ttk.Label(zoom_frame, text="100%", width=5, anchor='center')

        zoom_in_button = ttk.Button(zoom_frame, text="+", width=2, style='secondary.TButton')
        zoom_out_button = ttk.Button(zoom_frame, text="-", width=2, style='secondary.TButton')
        reset_zoom_button = ttk.Button(zoom_frame, text="⟲", width=2, style='secondary.TButton')

        zoom_in_button.pack(side='left')
        self.zoom_label.pack(side='left', padx=5)
        zoom_out_button.pack(side='left')
        reset_zoom_button.pack(side='left', padx=(5,0))

        ToolTip(zoom_in_button).update_text(self.loc.get('tooltip_zoom_in', fallback="Perbesar"))
        ToolTip(zoom_out_button).update_text(self.loc.get('tooltip_zoom_out', fallback="Perkecil"))
        ToolTip(reset_zoom_button).update_text(self.loc.get('tooltip_zoom_reset', fallback="Reset Zoom"))

        execution_frame = ttk.Frame(top_action_frame)
        execution_frame.pack(side='left', padx=20)

        self.simulate_button = ttk.Button(execution_frame, text=self.loc.get('simulate_workflow_button', fallback="Jalankan Simulasi"), command=self.parent_tab.simulate_workflow, style='primary.TButton')
        self.simulate_button.pack(side='left', expand=True, fill='x', padx=(0,5))

        self.run_button = ttk.Button(execution_frame, text=self.loc.get('run_workflow_button'), command=self.parent_tab.run_workflow, style='warning.TButton')
        self.run_button.pack(side='left', expand=True, fill='x', padx=(0,5))

        self.pause_resume_button = ttk.Button(execution_frame, text="Jeda", command=self.parent_tab.pause_workflow, style='info.TButton', state='disabled')
        self.pause_resume_button.pack(side='left', expand=True, fill='x', padx=(0,5))

        ttk.Button(execution_frame, text=self.loc.get('clear_cache_button'), command=self.parent_tab.clear_cache, style='secondary.TButton').pack(side='left', expand=True, fill='x')

        colors = self.kernel.theme_manager.get_colors()
        self.canvas = ttk.Canvas(self, background=colors.get('bg', '#222'))
        self.canvas.pack(expand=True, fill='both')

        self.canvas_manager = CanvasManager(self, self.parent_tab, self.canvas, self.kernel)
        zoom_in_button.config(command=self.canvas_manager.visual_manager.zoom_in)
        zoom_out_button.config(command=self.canvas_manager.visual_manager.zoom_out)
        reset_zoom_button.config(command=self.canvas_manager.visual_manager.reset_zoom)

    def update_zoom_label(self):
        if hasattr(self, 'zoom_label') and self.canvas_manager and self.canvas_manager.visual_manager:
            self.zoom_label.config(text=f"{int(self.canvas_manager.visual_manager.zoom_level * 100)}%")

    def apply_styles(self, colors):
        pass
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################