####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import Text, END
import subprocess
import threading
import os
from flowork_kernel.api_contract import BaseDashboardWidget

class CmdWidget(BaseDashboardWidget):
    """
    Widget yang berfungsi sebagai terminal perintah (CMD/PowerShell) sederhana
    yang terintegrasi di dalam dashboard.
    """
    def __init__(self, parent, coordinator_tab, kernel, widget_id: str, **kwargs):
        super().__init__(parent, coordinator_tab, kernel, widget_id, **kwargs)

        self.working_directory = self.kernel.project_root_path

        self._create_ui()
        self._insert_prompt()

    def _create_ui(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        terminal_frame = ttk.Frame(self, style='TFrame')
        terminal_frame.grid(row=0, column=0, sticky="nsew")
        terminal_frame.columnconfigure(0, weight=1)
        terminal_frame.rowconfigure(0, weight=1)

        colors = self.kernel.theme_manager.get_colors()
        self.output_text = Text(
            terminal_frame,
            wrap='word',
            state='disabled',
            background=colors.get('dark', '#222'),
            foreground=colors.get('light', '#fff'),
            insertbackground=colors.get('light', '#fff'),
            borderwidth=0,
            highlightthickness=0,
            font=("Consolas", 10)
        )
        self.output_text.grid(row=0, column=0, sticky="nsew")

        scrollbar = ttk.Scrollbar(terminal_frame, orient="vertical", command=self.output_text.yview)
        self.output_text.configure(yscrollcommand=scrollbar.set)
        scrollbar.grid(row=0, column=1, sticky="ns")

        input_frame = ttk.Frame(self, style='dark.TFrame')
        input_frame.grid(row=1, column=0, sticky="ew")
        input_frame.columnconfigure(1, weight=1)

        self.prompt_label = ttk.Label(input_frame, text=">", font=("Consolas", 10), style='inverse-dark.TLabel')
        self.prompt_label.grid(row=0, column=0, padx=(5,0))

        self.cmd_entry = ttk.Entry(input_frame, font=("Consolas", 10))
        style = ttk.Style()
        style.configure(
            "custom_cmd.TEntry",
            fieldbackground=colors.get('dark', '#222'),
            foreground=colors.get('light', '#fff'),
            insertcolor=colors.get('light', '#fff'),
            borderwidth=0,
            relief='flat'
        )
        self.cmd_entry.config(style="custom_cmd.TEntry")

        self.cmd_entry.grid(row=0, column=1, sticky="ew")
        self.cmd_entry.bind("<Return>", self._on_enter_pressed)
        self.cmd_entry.focus_set()

    def _append_to_output(self, text):
        self.output_text.config(state='normal')
        self.output_text.insert(END, text)
        self.output_text.see(END)
        self.output_text.config(state='disabled')

    def _on_enter_pressed(self, event=None):
        command = self.cmd_entry.get()
        self.cmd_entry.delete(0, END)

        self._append_to_output(f"{self.prompt_label.cget('text')}{command}\n")

        if command.strip().lower() in ['cls', 'clear']:
            self.output_text.config(state='normal')
            self.output_text.delete('1.0', END)
            self.output_text.config(state='disabled')
            self._insert_prompt()
            return

        if command.strip():
            thread = threading.Thread(target=self._run_command_thread, args=(command,), daemon=True)
            thread.start()

    def _run_command_thread(self, command):
        try:
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                shell=True,
                cwd=self.working_directory,
                text=True,
                encoding='utf-8',
                errors='replace'
            )

            for line in iter(process.stdout.readline, ''):
                if self.winfo_exists():
                    self.after(0, self._append_to_output, line)

            for line in iter(process.stderr.readline, ''):
                if self.winfo_exists():
                    self.after(0, self._append_to_output, line)

            process.stdout.close()
            process.stderr.close()
            process.wait()

        except Exception as e:
            if self.winfo_exists():
                self.after(0, self._append_to_output, f"Error: {str(e)}\n")
        finally:
            if self.winfo_exists():
                self.after(0, self._insert_prompt)

    def _insert_prompt(self):
        prompt_text = f"\n{self.working_directory}>"
        self.prompt_label.config(text=prompt_text)

    def refresh_content(self):
        self.cmd_entry.focus_set()
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################