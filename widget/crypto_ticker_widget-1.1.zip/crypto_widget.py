####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import ttk as tk_ttk
import yfinance as yf
import threading
import math
from flowork_kernel.api_contract import BaseDashboardWidget

class CryptoWidget(BaseDashboardWidget):
    """
    Widget untuk menampilkan daftar harga cryptocurrency dengan pagination.
    """
    def __init__(self, parent, coordinator_tab, kernel, widget_id: str, **kwargs):
        super().__init__(parent, coordinator_tab, kernel, widget_id, **kwargs)

        self.crypto_list = [
            "BTC-USD", "ETH-USD", "BNB-USD", "SOL-USD", "XRP-USD", "DOGE-USD",
            "ADA-USD", "SHIB-USD", "AVAX-USD", "LINK-USD", "DOT-USD", "TRX-USD",
            "MATIC-USD", "LTC-USD", "BCH-USD", "ICP-USD", "NEAR-USD", "UNI-USD",
            "LEO-USD", "XLM-USD", "ATOM-USD", "ETC-USD", "XMR-USD", "FIL-USD"
        ]

        self.current_page = 1
        self.items_per_page = 10
        self.total_pages = math.ceil(len(self.crypto_list) / self.items_per_page)

        self.after_id = None
        self._create_ui()
        self.start_fetching_data()

    def _create_ui(self):
        """Membuat semua elemen antarmuka pengguna untuk widget ini."""
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        tree_frame = ttk.Frame(self)
        tree_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=(10, 5))
        tree_frame.columnconfigure(0, weight=1)
        tree_frame.rowconfigure(0, weight=1)

        columns = ('name', 'price', 'change', 'pct_change')
        self.crypto_tree = tk_ttk.Treeview(tree_frame, columns=columns, show='headings', style="Custom.Treeview")

        self.crypto_tree.heading('name', text='Nama Crypto')
        self.crypto_tree.heading('price', text='Harga (USD)')
        self.crypto_tree.heading('change', text='Perubahan (24j)')
        self.crypto_tree.heading('pct_change', text='% Perubahan (24j)')

        self.crypto_tree.column('name', width=180)
        self.crypto_tree.column('price', width=120, anchor='e')
        self.crypto_tree.column('change', width=120, anchor='e')
        self.crypto_tree.column('pct_change', width=120, anchor='e')

        self.crypto_tree.grid(row=0, column=0, sticky="nsew")

        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.crypto_tree.yview)
        self.crypto_tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.grid(row=0, column=1, sticky="ns")

        self.crypto_tree.tag_configure('gain', foreground='green')
        self.crypto_tree.tag_configure('loss', foreground='red')

        bottom_frame = ttk.Frame(self, style='TFrame')
        bottom_frame.grid(row=1, column=0, sticky="ew", padx=10, pady=(5, 10))
        bottom_frame.columnconfigure(1, weight=1)

        self.prev_button = ttk.Button(bottom_frame, text="<< Prev", command=self.prev_page, style="secondary.TButton")
        self.prev_button.grid(row=0, column=0)

        self.page_label = ttk.Label(bottom_frame, text=f"Halaman {self.current_page}/{self.total_pages}", style='TLabel')
        self.page_label.grid(row=0, column=1)

        self.next_button = ttk.Button(bottom_frame, text="Next >>", command=self.next_page, style="secondary.TButton")
        self.next_button.grid(row=0, column=2)

        self.status_label = ttk.Label(bottom_frame, text="Memuat...", style='secondary.TLabel', font=("Helvetica", 8))
        self.status_label.grid(row=0, column=3, sticky='e', padx=(10,0))
        bottom_frame.columnconfigure(3, weight=1)

    def start_fetching_data(self):
        """Memulai proses pengambilan data untuk halaman saat ini."""
        if not self.winfo_exists():
            return
        self.status_label.config(text="Memuat...")
        thread = threading.Thread(target=self._fetch_data_thread, daemon=True)
        thread.start()

    def _fetch_data_thread(self):
        """Thread untuk mengambil data beberapa crypto sekaligus."""
        start_index = (self.current_page - 1) * self.items_per_page
        end_index = start_index + self.items_per_page
        tickers_to_fetch = self.crypto_list[start_index:end_index]

        try:
            if not tickers_to_fetch:
                if self.winfo_exists():
                    self.after(0, self._update_ui_with_data, [])
                return

            self.kernel.write_to_log(f"CryptoWidget: Mengambil data untuk: {', '.join(tickers_to_fetch)}", "INFO")
            tickers = yf.Tickers(' '.join(tickers_to_fetch))

            all_info = []
            for ticker_symbol in tickers_to_fetch:
                info = tickers.tickers[ticker_symbol].info
                if info.get('regularMarketPrice') is not None or info.get('bid') is not None:
                     all_info.append(info)
                else:
                    self.kernel.write_to_log(f"CryptoWidget: Tidak ada data untuk {ticker_symbol}", "WARN")

            if self.winfo_exists():
                self.after(0, self._update_ui_with_data, all_info)

        except Exception as e:
            error_message = f"Gagal mengambil data: {e}"
            self.kernel.write_to_log(f"CryptoWidget: {error_message}", "ERROR")
            if self.winfo_exists():
                self.after(0, self._show_error, error_message)
        finally:
            if self.winfo_exists():
                self.after_id = self.after(300000, self.start_fetching_data)

    def _update_ui_with_data(self, data_list):
        """Memperbarui Treeview dengan data yang baru."""
        if not self.winfo_exists():
            return

        for item in self.crypto_tree.get_children():
            self.crypto_tree.delete(item)

        for data in data_list:
            crypto_name = data.get('longName', data.get('shortName', data.get('symbol', 'N/A')))
            current_price = data.get('regularMarketPrice', data.get('bid', 0))
            previous_close = data.get('previousClose', data.get('open', current_price))

            change = current_price - previous_close
            percent_change = (change / previous_close) * 100 if previous_close else 0

            tag = 'gain' if change >= 0 else 'loss'

            values = (
                crypto_name,
                f"{current_price:,.4f}", # Tampilkan lebih banyak desimal untuk crypto
                f"{change:,.4f}",
                f"{percent_change:,.2f}%"
            )
            self.crypto_tree.insert('', 'end', values=values, tags=(tag,))

        from datetime import datetime
        self.status_label.config(text=f"Update terakhir: {datetime.now().strftime('%H:%M:%S')}")
        self.update_pagination_controls()

    def _show_error(self, message):
        """Menampilkan pesan error."""
        if not self.winfo_exists():
            return
        self.status_label.config(text=message[:50] + "...")

    def update_pagination_controls(self):
        """Memperbarui label halaman dan status tombol next/prev."""
        self.page_label.config(text=f"Halaman {self.current_page}/{self.total_pages}")
        self.prev_button.config(state="normal" if self.current_page > 1 else "disabled")
        self.next_button.config(state="normal" if self.current_page < self.total_pages else "disabled")

    def change_page(self):
        """Menghentikan refresh lama dan memulai yang baru untuk halaman baru."""
        if self.after_id:
            self.after_cancel(self.after_id)
            self.after_id = None

        for item in self.crypto_tree.get_children():
            self.crypto_tree.delete(item)

        self.start_fetching_data()
        self.update_pagination_controls()

    def next_page(self):
        if self.current_page < self.total_pages:
            self.current_page += 1
            self.change_page()

    def prev_page(self):
        if self.current_page > 1:
            self.current_page -= 1
            self.change_page()

    def on_widget_destroy(self):
        """Membersihkan sumber daya saat widget ditutup."""
        self.kernel.write_to_log(f"CryptoWidget: Widget list crypto dihancurkan. Membatalkan auto-refresh.", "INFO")
        if self.after_id:
            self.after_cancel(self.after_id)
            self.after_id = None
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################