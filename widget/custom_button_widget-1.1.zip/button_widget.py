####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################
import ttkbootstrap as ttk
from tkinter import StringVar
from flowork_kernel.api_contract import BaseDashboardWidget

class CustomButtonWidget(BaseDashboardWidget):
    """
    Sebuah widget tombol yang bisa dikonfigurasi untuk memicu alur kerja preset.
    """
    def __init__(self, parent, coordinator_tab, kernel, widget_id: str, **kwargs):
        super().__init__(parent, coordinator_tab, kernel, widget_id, **kwargs)

        self.config = {}
        self.is_configured = False

        self.button_text_var = StringVar()
        self.preset_var = StringVar()

        self.main_frame = ttk.Frame(self)
        self.main_frame.pack(fill='both', expand=True)

        self._load_state()
        self._update_view()

    def _load_state(self):
        """Memuat konfigurasi tersimpan dari StateManager."""
        self.config = self.kernel.state.get(f"widget_config_{self.widget_id}", {})
        self.is_configured = bool(self.config.get("preset_to_run"))

        self.button_text_var.set(self.config.get("button_text", self.loc.get('custom_button_not_configured')))
        self.preset_var.set(self.config.get("preset_to_run", ""))

    def _update_view(self):
        """Menampilkan UI yang sesuai (konfigurasi atau tombol final)."""
        for widget in self.main_frame.winfo_children():
            widget.destroy()

        if self.is_configured:
            self._create_button_ui()
        else:
            self._create_config_ui()

    def _create_config_ui(self):
        """Membuat UI untuk mode konfigurasi."""
        config_frame = ttk.Frame(self.main_frame, padding=10)
        config_frame.pack(fill='both', expand=True)

        ttk.Label(config_frame, text=self.loc.get('custom_button_text_label')).pack(anchor='w')
        ttk.Entry(config_frame, textvariable=self.button_text_var).pack(fill='x', pady=(0, 10))

        ttk.Label(config_frame, text=self.loc.get('custom_button_preset_label')).pack(anchor='w')

        preset_list = self.kernel.preset_manager.get_preset_list() # Memanggil manajer yang benar

        ttk.Combobox(config_frame, textvariable=self.preset_var, values=preset_list, state="readonly").pack(fill='x', pady=(0, 10))

        ttk.Button(config_frame, text=self.loc.get('save_config_button'), command=self._save_config, style="success.TButton").pack(fill='x')

    def _create_button_ui(self):
        """Membuat UI final (hanya tombol)."""
        button_frame = ttk.Frame(self.main_frame)
        button_frame.pack(fill='both', expand=True, padx=5, pady=5)

        self.final_button = ttk.Button(button_frame, text=self.config.get("button_text"), command=self._trigger_workflow)
        self.final_button.pack(fill='both', expand=True, ipady=10)

    def _save_config(self):
        """Menyimpan konfigurasi saat ini."""
        button_text = self.button_text_var.get()
        preset_to_run = self.preset_var.get()

        if not button_text or not preset_to_run:
            return

        self.config = {
            "button_text": button_text,
            "preset_to_run": preset_to_run
        }

        self.kernel.state.set(f"widget_config_{self.widget_id}", self.config)
        self.is_configured = True
        self._update_view()

    def _trigger_workflow(self):
        """Memicu eksekusi alur kerja yang telah dipilih."""
        preset_name = self.config.get("preset_to_run")
        button_text = self.config.get("button_text")
        if not preset_name:
            return

        self.kernel.write_to_log(
            self.loc.get('custom_button_executing_log', button_text=button_text, preset_name=preset_name),
            "INFO"
        )

        workflow_data = self.kernel.preset_manager.get_preset_data(preset_name) # Memanggil manajer yang benar

        if workflow_data:
            nodes = {node['id']: node for node in workflow_data.get('nodes', [])}
            connections = {conn['id']: conn for conn in workflow_data.get('connections', [])}
            initial_payload = {"triggered_by": self.widget_id, "button_text": button_text}

            self.coordinator_tab.run_workflow_from_preset(nodes, connections, initial_payload)

    def on_widget_destroy(self):
        """Membersihkan state saat widget dihapus."""
        self.kernel.state.delete(f"widget_config_{self.widget_id}")
        self.kernel.write_to_log(f"Konfigurasi untuk widget {self.widget_id} dibersihkan.", "DEBUG")
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################