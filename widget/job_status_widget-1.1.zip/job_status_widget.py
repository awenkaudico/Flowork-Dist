####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################

import ttkbootstrap as ttk
from tkinter import ttk as tk_ttk
import datetime
from flowork_kernel.api_contract import BaseDashboardWidget

class JobStatusWidget(BaseDashboardWidget):
    def __init__(self, parent, coordinator_tab, kernel, widget_id: str, **kwargs):
        super().__init__(parent, coordinator_tab, kernel, widget_id, **kwargs)

        self.colors = self.kernel.theme_manager.get_colors()
        self.configure(style='TFrame')

        self.create_treeview()
        self.refresh_data()

    def create_treeview(self):
        """Mempersiapkan Treeview untuk menampilkan data."""
        style = tk_ttk.Style(self)
        style.configure("LiveStatus.Treeview",
                        background=self.colors.get('dark'),
                        foreground=self.colors.get('fg'),
                        fieldbackground=self.colors.get('dark'),
                        borderwidth=0,
                        rowheight=25)
        style.configure("LiveStatus.Treeview.Heading",
                        background=self.colors.get('bg'),
                        foreground=self.colors.get('light'),
                        font=('Helvetica', 9, 'bold'))
        style.map('LiveStatus.Treeview',
                  background=[('selected', self.colors['selectbg'])],
                  foreground=[('selected', self.colors['selectfg'])])

        style.configure("Status.Succeeded.Treeview", foreground=self.colors.get('success'))
        style.configure("Status.Failed.Treeview", foreground=self.colors.get('danger'))
        style.configure("Status.Running.Treeview", foreground=self.colors.get('warning'))
        style.configure("Status.Queued.Treeview", foreground=self.colors.get('info'))


        container = ttk.Frame(self)
        container.pack(fill='both', expand=True)

        columns = ('id', 'preset', 'status', 'mulai')
        self.tree = tk_ttk.Treeview(container, columns=columns, show='headings', style="LiveStatus.Treeview")

        self.tree.heading('id', text='ID Pekerjaan')
        self.tree.heading('preset', text='Preset')
        self.tree.heading('status', text='Status')
        self.tree.heading('mulai', text='Waktu Mulai')

        self.tree.column('id', anchor='w', width=100)
        self.tree.column('preset', anchor='w', width=120)
        self.tree.column('status', anchor='center', width=80)
        self.tree.column('mulai', anchor='w', width=120)

        self.tree.tag_configure('SUCCEEDED', foreground=self.colors.get('success'))
        self.tree.tag_configure('FAILED', foreground=self.colors.get('danger'))
        self.tree.tag_configure('RUNNING', foreground=self.colors.get('warning'))
        self.tree.tag_configure('QUEUED', foreground=self.colors.get('info'))

        vsb = ttk.Scrollbar(container, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)

        vsb.pack(side='right', fill='y')
        self.tree.pack(side='left', fill='both', expand=True)

    def refresh_data(self):
        """Mengambil data dari kernel dan memperbarui treeview."""
        for item in self.tree.get_children():
            self.tree.delete(item)

        all_jobs = self.kernel.job_statuses.copy()

        sorted_jobs = sorted(all_jobs.items(), key=lambda item: item[1].get('queued_time', 0), reverse=True)[:15]

        for job_id, data in sorted_jobs:
            status = data.get('status', 'UNKNOWN')

            start_time_unix = data.get('start_time')
            if start_time_unix:
                start_time_str = datetime.datetime.fromtimestamp(start_time_unix).strftime('%H:%M:%S')
            else:
                start_time_str = "Menunggu..."

            self.tree.insert(
                '',
                'end',
                values=(
                    job_id[:8] + '...', # Ambil 8 karakter pertama ID
                    data.get('preset_name', '-'),
                    status,
                    start_time_str
                ),
                tags=(status,) # Gunakan status sebagai tag untuk pewarnaan
            )

        self.after(5000, self.refresh_data)
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################