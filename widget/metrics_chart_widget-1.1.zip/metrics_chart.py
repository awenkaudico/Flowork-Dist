####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################

import os
import json
import pandas as pd
import ttkbootstrap as ttk
from flowork_kernel.api_contract import BaseDashboardWidget

from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.dates as mdates

class MetricsChartWidget(BaseDashboardWidget):
    def __init__(self, parent, coordinator_tab, kernel, widget_id: str, **kwargs):
        super().__init__(parent, coordinator_tab, kernel, widget_id, **kwargs)
        self.history_file_path = os.path.join(self.kernel.data_path, "metrics_history.jsonl")

        self.colors = self.kernel.theme_manager.get_colors()
        self.bg_color = self.colors.get('bg', '#2C3E50')
        self.fg_color = self.colors.get('fg', '#ECF0F1')
        self.success_color = self.colors.get('success', '#2ECC71')
        self.danger_color = self.colors.get('danger', '#E74C3C')

        self.configure(style='TFrame')
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        self.fig = Figure(figsize=(5, 3), dpi=100, facecolor=self.bg_color)
        self.ax = self.fig.add_subplot(111)

        self.canvas = FigureCanvasTkAgg(self.fig, master=self)
        self.canvas_widget = self.canvas.get_tk_widget()
        self.canvas_widget.grid(row=0, column=0, sticky='nsew')

        self.update_chart()

    def update_chart(self):
        """Membaca data dan menggambar ulang grafik."""

        data = []
        if os.path.exists(self.history_file_path):
            with open(self.history_file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        log_entry = json.loads(line)
                        data.append({
                            'timestamp': log_entry['timestamp'],
                            'succeeded': log_entry['metrics'].get('workflows_succeeded', 0),
                            'failed': log_entry['metrics'].get('workflows_failed', 0)
                        })
                    except json.JSONDecodeError:
                        continue

        if not data:
            self.show_placeholder()
            return

        df = pd.DataFrame(data)
        df['datetime'] = pd.to_datetime(df['timestamp'], unit='s')

        self.ax.clear()

        self.ax.plot(df['datetime'], df['succeeded'], label='Sukses', color=self.success_color, marker='o', linestyle='-')
        self.ax.plot(df['datetime'], df['failed'], label='Gagal', color=self.danger_color, marker='x', linestyle='--')

        self.ax.set_facecolor(self.bg_color)
        self.ax.tick_params(axis='x', colors=self.fg_color, rotation=30)
        self.ax.tick_params(axis='y', colors=self.fg_color)
        self.ax.spines['bottom'].set_color(self.fg_color)
        self.ax.spines['left'].set_color(self.fg_color)
        self.ax.spines['top'].set_color(self.bg_color)
        self.ax.spines['right'].set_color(self.bg_color)
        self.ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))

        legend = self.ax.legend(facecolor=self.bg_color, labelcolor=self.fg_color)
        legend.get_frame().set_edgecolor(self.fg_color)

        self.canvas.draw()

        self.after(10000, self.update_chart)

    def show_placeholder(self):
        """Menampilkan pesan jika tidak ada data."""
        self.ax.clear()
        self.ax.text(0.5, 0.5, 'Menunggu data metrik...',
                     horizontalalignment='center', verticalalignment='center',
                     transform=self.ax.transAxes, color=self.fg_color, fontsize=12)
        self.ax.set_facecolor(self.bg_color)
        self.ax.spines['bottom'].set_color(self.bg_color)
        self.ax.spines['left'].set_color(self.bg_color)
        self.ax.spines['top'].set_color(self.bg_color)
        self.ax.spines['right'].set_color(self.bg_color)
        self.ax.get_xaxis().set_ticks([])
        self.ax.get_yaxis().set_ticks([])
        self.canvas.draw()
        self.after(5000, self.update_chart) # Coba lagi setelah 5 detik

    def on_widget_destroy(self):
        pass
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################