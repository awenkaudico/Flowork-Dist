####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################

import ttkbootstrap as ttk
import os
from tkinter import Menu, messagebox, Toplevel, Text, font
from flowork_kernel.api_contract import BaseDashboardWidget

class PluginToolboxWidget(BaseDashboardWidget):
    def __init__(self, parent, coordinator_tab, kernel, widget_id: str, **kwargs):
        super().__init__(parent, coordinator_tab, kernel, widget_id, **kwargs)
        self.columnconfigure(0, weight=1); self.rowconfigure(1, weight=1)
        self.search_var = ttk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.populate_plugin_toolbox(self.search_var.get()))
        search_entry = ttk.Entry(self, textvariable=self.search_var)
        search_entry.grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        self.tree = ttk.Treeview(self, selectmode="browse", style="Custom.Treeview")
        self.tree.grid(row=1, column=0, sticky="nsew")
        self.tree.tag_configure('paused', background='#424242', foreground='#9E9E9E')
        self.tooltip_window = None; self.last_hovered_item = None
        self.tree.bind("<ButtonPress-1>", self.on_drag_start)
        self.tree.bind("<B1-Motion>", self.on_drag_motion)
        self.tree.bind("<ButtonRelease-1>", self.on_drag_release)
        self.tree.bind("<Button-3>", self._show_context_menu)
        self.tree.bind('<Motion>', self._on_mouse_motion)
        self.tree.bind('<Leave>', self._hide_tooltip)
        self.populate_plugin_toolbox()

    def on_drag_start(self, event): self.coordinator_tab.on_drag_start(event)
    def on_drag_motion(self, event): self.coordinator_tab.on_drag_motion(event)
    def on_drag_release(self, event): self.coordinator_tab.on_drag_release(event)

    def populate_plugin_toolbox(self, search_filter=""):
        for item in self.tree.get_children(): self.tree.delete(item)
        search_query = search_filter.lower()
        all_plugins = []
        plugins_dir = os.path.normpath(self.kernel.module_manager.plugins_dir)
        for mod_id, data in self.kernel.module_manager.loaded_modules.items():
            module_path = os.path.normpath(data.get("path", ""))
            if not module_path or not module_path.startswith(plugins_dir):
                continue
            manifest = data.get("manifest", {})
            display_name = self.loc.get(manifest.get('name', mod_id)[4:], fallback=mod_id) if manifest.get('name', '').startswith('loc.') else manifest.get('name', mod_id)
            if search_query and search_query not in display_name.lower(): continue
            is_paused = self.kernel.module_manager.is_module_paused(mod_id)
            if is_paused:
                paused_prefix = self.loc.get('paused_prefix', fallback="[JEDA]")
                display_name = f"{paused_prefix} {display_name}"
            all_plugins.append((mod_id, display_name, is_paused))
        sorted_plugins = sorted(all_plugins, key=lambda x: x[1])
        for mod_id, display_name, is_paused in sorted_plugins:
            tags = ('module_item', 'paused' if is_paused else 'active')
            self.tree.insert("", "end", iid=mod_id, text=f" {display_name}", tags=tags)

    def _show_context_menu(self, event):
        item_id = self.tree.identify_row(event.y)
        if not item_id or 'module_item' not in self.tree.item(item_id, 'tags'): return
        self.tree.selection_set(item_id)
        is_paused = 'paused' in self.tree.item(item_id, 'tags')
        context_menu = Menu(self.tree, tearoff=0)
        if is_paused: context_menu.add_command(label=self.loc.get('context_menu_resume', fallback="Lanjutkan"), command=lambda: self._handle_pause_resume(item_id, False))
        else: context_menu.add_command(label=self.loc.get('context_menu_pause', fallback="Jeda"), command=lambda: self._handle_pause_resume(item_id, True))
        context_menu.add_separator()
        context_menu.add_command(label=self.loc.get('context_menu_uninstall', fallback="Hapus"), command=lambda: self._handle_uninstall(item_id))
        context_menu.tk_popup(event.x_root, event.y_root)

    def _handle_pause_resume(self, module_id, should_pause):
        self.kernel.module_manager.set_module_paused(module_id, should_pause)
        self.populate_plugin_toolbox(self.search_var.get())

    def _handle_uninstall(self, module_id):
        manifest = self.kernel.module_manager.get_manifest(module_id)
        module_name = self.loc.get(manifest.get('name', module_id)[4:], fallback=module_id)
        if messagebox.askyesno(self.loc.get('uninstall_confirm_title', fallback="Konfirmasi"), self.loc.get('uninstall_confirm_message', name=module_name, fallback=f"Yakin ingin hapus '{module_name}'?")):
            messagebox.showinfo("Info", f"Fitur Hapus untuk '{module_name}' belum ada di Kernel.")

    def _on_mouse_motion(self, event):
        item_id = self.tree.identify_row(event.y)
        if item_id and 'module_item' in self.tree.item(item_id, 'tags'):
            if self.last_hovered_item != item_id:
                self.last_hovered_item = item_id
                self._hide_tooltip()
                self._show_tooltip(event, item_id)
        else: self._hide_tooltip()

    def _show_tooltip(self, event, item_id):
        if self.tooltip_window: return
        manifest = self.kernel.module_manager.get_manifest(item_id)
        if not manifest: return
        name = self.loc.get(manifest.get('name', item_id)[4:], fallback=item_id)
        try: desc = self.loc.get(manifest.get('description', '')[4:], fallback='Tidak ada deskripsi.')
        except: desc = manifest.get('description', 'Tidak ada deskripsi.')
        try: tutor = self.loc.get(manifest.get('tutorial', '')[4:], fallback='')
        except: tutor = manifest.get('tutorial', '')
        label_desc = self.loc.get('tooltip_desc_label', fallback='Deskripsi')
        bg_color, title_color, heading_color, content_color = '#2B2B2B', '#82CFE8', '#FFFFFF', '#BDBDBD'
        self.tooltip_window = Toplevel(self.winfo_toplevel())
        self.tooltip_window.wm_overrideredirect(True)
        self.tooltip_window.wm_geometry(f"+{event.x_root + 20}+{event.y_root + 15}")
        self.tooltip_window.configure(background=bg_color)
        text_widget = Text(self.tooltip_window, wrap='word', borderwidth=1, relief='solid', background=bg_color, padx=8, pady=6, font=("Segoe UI", 9), highlightthickness=1, highlightbackground=heading_color)
        text_widget.pack()
        title_font = font.Font(family="Segoe UI", size=10, weight="bold")
        heading_font = font.Font(family="Segoe UI", size=9, weight="bold")
        text_widget.tag_configure("title", foreground=title_color, font=title_font)
        text_widget.tag_configure("heading", foreground=heading_color, font=heading_font)
        text_widget.tag_configure("content", foreground=content_color, font=("Segoe UI", 9))
        text_widget.insert('end', f"{name.upper()}\n", "title")
        text_widget.insert('end', "-" * 50 + "\n\n", "content")
        text_widget.insert('end', f"{label_desc}:\n", "heading")
        text_widget.insert('end', f"{desc}\n", "content")
        if tutor: text_widget.insert('end', f"\n{tutor}", "content")
        text_widget.config(state='disabled')

    def _hide_tooltip(self, event=None):
        if self.tooltip_window: self.tooltip_window.destroy()
        self.tooltip_window = None
        self.last_hovered_item = None
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################