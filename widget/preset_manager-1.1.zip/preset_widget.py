####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################

import ttkbootstrap as ttk
from tkinter import ttk as tk_ttk, messagebox, simpledialog, StringVar
import urllib.parse
from flowork_kernel.ui_shell.version_manager_popup import VersionManagerPopup
from flowork_kernel.api_contract import BaseDashboardWidget

class PresetWidget(BaseDashboardWidget):
    """
    Widget untuk mengelola Preset Alur Kerja, dengan daftar dinamis,
    tombol cerdas, dan kompatibilitas penuh dengan sistem.
    """
    def __init__(self, parent, coordinator_tab, kernel, widget_id: str, **kwargs):
        super().__init__(parent, coordinator_tab, kernel, widget_id, **kwargs)
        self.parent_tab = coordinator_tab
        self.loc = self.kernel.loc
        self.preset_var = StringVar()
        self.create_widgets()
        self.apply_styles(self.kernel.theme_manager.get_colors())
        self.populate_preset_dropdown()

    def apply_styles(self, colors):
        style = tk_ttk.Style(self)
        style.configure('Preset.TFrame', background=colors.get('bg'))
        style.configure('Preset.TLabel', background=colors.get('bg'), foreground=colors.get('fg'))
        style.configure('Preset.TButton', background=colors.get('bg'), foreground=colors.get('fg'))
        style.configure('Preset.TLabelframe', background=colors.get('bg'), relief="solid", borderwidth=1, bordercolor=colors.get('border'))
        style.configure('Preset.TLabelframe.Label', background=colors.get('bg'), foreground=colors.get('fg'), font=('Helvetica', 10, 'bold'))

    def create_widgets(self):
        self.container = ttk.LabelFrame(self, text=self.loc.get('preset_frame_title', fallback="Preset Alur Kerja"), padding=10)
        self.container.pack(fill='both', expand=True)

        preset_row = ttk.Frame(self.container)
        preset_row.pack(fill='x', expand=True)

        self.preset_combobox = ttk.Combobox(preset_row, textvariable=self.preset_var, state="readonly")
        self.preset_combobox.pack(side='left', fill='x', expand=True)

        self.preset_combobox.bind("<Button-1>", lambda event: self.populate_preset_dropdown())
        self.preset_combobox.bind("<<ComboboxSelected>>", self._on_preset_selected)

        self.manage_versions_button = ttk.Button(preset_row, text=self.loc.get('manage_versions_button', fallback="..."), style='primary-outline', command=self._open_version_manager)
        self.manage_versions_button.pack(side='right', padx=(5,0))

        buttons_row = ttk.Frame(self.container)
        buttons_row.pack(fill='x', expand=True, pady=(5,0))
        buttons_row.columnconfigure((0,1,2), weight=1)

        self.load_preset_button = ttk.Button(buttons_row, text=self.loc.get('load_workflow_button', fallback="Muat"), command=self.load_preset, style='primary.TButton', state="disabled")
        self.load_preset_button.grid(row=0, column=0, sticky="ew", padx=(0, 2))

        self.save_preset_button = ttk.Button(buttons_row, text=self.loc.get('save_as_preset', fallback="Simpan Sebagai..."), command=self._save_as_preset)
        self.save_preset_button.grid(row=0, column=1, sticky="ew", padx=2)

        self.delete_preset_button = ttk.Button(buttons_row, text=self.loc.get('delete_preset_button', fallback="Hapus"), command=self._delete_selected_preset, style='danger.TButton', state="disabled")
        self.delete_preset_button.grid(row=0, column=2, sticky="ew", padx=(2, 0))

        git_frame = ttk.LabelFrame(self.container, text="Kontrol Versi (Git)")
        git_frame.pack(fill='x', expand=True, pady=(10, 0))
        git_frame.columnconfigure((0,1,2), weight=1)

        self.git_commit_button = ttk.Button(git_frame, text="Commit", command=self._commit_changes)
        self.git_commit_button.grid(row=0, column=0, sticky="ew", padx=(0,2))
        self.git_pull_button = ttk.Button(git_frame, text="Pull", command=self._pull_from_remote)
        self.git_pull_button.grid(row=0, column=1, sticky="ew", padx=2)
        self.git_push_button = ttk.Button(git_frame, text="Push", command=self._push_to_remote)
        self.git_push_button.grid(row=0, column=2, sticky="ew", padx=(2,0))

        self.webhook_info_frame = ttk.Frame(self.container)
        self.webhook_url_var = StringVar()
        webhook_label = ttk.Label(self.webhook_info_frame, text="Webhook URL:", font="helvetica 8 bold")
        webhook_label.pack(side='left', anchor='w')
        webhook_entry = ttk.Entry(self.webhook_info_frame, textvariable=self.webhook_url_var, state="readonly")
        webhook_entry.pack(side='left', fill='x', expand=True, padx=5)
        copy_button = ttk.Button(self.webhook_info_frame, text="Salin", style="secondary-outline", command=self._copy_webhook_url)
        copy_button.pack(side='left')

    def populate_preset_dropdown(self):
        current_selection = self.preset_var.get()
        try:
            presets = self.kernel.preset_manager.get_preset_list()
            self.preset_combobox['values'] = presets
            if current_selection in presets:
                self.preset_var.set(current_selection)
            else:
                self.preset_var.set('')
        except Exception as e:
            self.kernel.write_to_log(f"Gagal memuat daftar preset: {e}", "ERROR")
            self.preset_combobox['values'] = []
        self._update_button_states()

    def _update_button_states(self, event=None):
        has_selection = bool(self.preset_var.get())
        state = "normal" if has_selection else "disabled"

        if hasattr(self, 'load_preset_button'): self.load_preset_button.config(state=state)
        if hasattr(self, 'delete_preset_button'): self.delete_preset_button.config(state=state)
        if hasattr(self, 'manage_versions_button'): self.manage_versions_button.config(state=state)

        is_repo = self.kernel.preset_manager.get_repo_status()
        git_state = "normal" if is_repo else "disabled"
        if hasattr(self, 'git_commit_button'): self.git_commit_button.config(state=git_state)
        if hasattr(self, 'git_pull_button'): self.git_pull_button.config(state=git_state)
        if hasattr(self, 'git_push_button'): self.git_push_button.config(state=git_state)

        if hasattr(self.parent_tab, 'on_preset_selected'):
            self.parent_tab.on_preset_selected(event)

    def _on_preset_selected(self, event=None):
        self._update_button_states(event)
        self._update_webhook_info() # Pindahkan ini ke sini agar URL update saat preset dipilih

    def load_preset(self):
        self.parent_tab.load_workflow(self.preset_var.get())

    def _save_as_preset(self):
        self.parent_tab.save_as_preset()

    def _delete_selected_preset(self):
        self.parent_tab._delete_selected_preset()

    def _open_version_manager(self):
        selected_preset = self.preset_var.get()
        if not selected_preset:
            messagebox.showwarning(self.loc.get('warning_title', fallback="Peringatan"), self.loc.get('select_preset_first_warning', fallback="Pilih sebuah preset terlebih dahulu."))
            return
        VersionManagerPopup(self, self.kernel, selected_preset, self)

    def _update_webhook_info(self):
        selected_preset = self.preset_var.get()
        webhook_server = self.kernel.webhook_server
        if selected_preset and webhook_server:
            host = '127.0.0.1'
            port = webhook_server.port
            encoded_preset = urllib.parse.quote(selected_preset)
            url = f"http://{host}:{port}/webhook/{encoded_preset}"
            self.webhook_url_var.set(url)
            self.webhook_info_frame.pack(fill='x', expand=True, pady=(5,0))
        else:
            self.webhook_info_frame.pack_forget()

    def _copy_webhook_url(self):
        url_to_copy = self.webhook_url_var.get()
        if url_to_copy:
            self.clipboard_clear()
            self.clipboard_append(url_to_copy)
            self.kernel.write_to_log(f"URL Webhook disalin ke clipboard: {url_to_copy}", "SUCCESS")

    def _commit_changes(self):
        commit_message = simpledialog.askstring("Commit Perubahan", "Masukkan pesan commit:")
        if commit_message:
            success, message = self.kernel.preset_manager.commit_changes(commit_message)
            if success:
                messagebox.showinfo("Sukses", message)
            else:
                messagebox.showerror("Error", message)

    def _push_to_remote(self):
        success, message = self.kernel.preset_manager.push_to_remote()
        if success:
            messagebox.showinfo("Sukses", message)
        else:
            messagebox.showerror("Error", message)

    def _pull_from_remote(self):
        success, message = self.kernel.preset_manager.pull_from_remote()
        if success:
            messagebox.showinfo("Sukses", message)
            self.populate_preset_dropdown() # Refresh daftar preset setelah pull
        else:
            messagebox.showerror("Error", message)

    def refresh_content(self):
        self.populate_preset_dropdown()
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################