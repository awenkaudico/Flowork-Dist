####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AWAL KODE) ########################################################################################


import ttkbootstrap as ttk
from tkinter import ttk as tk_ttk
from flowork_kernel.api_contract import BaseDashboardWidget
from flowork_kernel.ui_shell.custom_widgets.tooltip import ToolTip
from tkinter import StringVar


class WidgetToolboxWidget(BaseDashboardWidget):
    """
    Widget untuk menampilkan toolbox yang berisi semua widget yang tersedia
    yang dapat ditambahkan ke dashboard.
    """
    def __init__(self, parent, coordinator_tab, kernel, widget_id: str):
        super().__init__(parent, coordinator_tab, kernel, widget_id)
        self.coordinator_tab = coordinator_tab
        self.kernel = kernel
        self.loc = kernel.loc

        self.search_var = StringVar()
        self.search_var.trace_add("write", self._on_search)

        self._create_widgets()
        self.populate_widget_toolbox()

    def _create_widgets(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        search_frame = ttk.Frame(self)
        search_frame.grid(row=0, column=0, sticky="ew", padx=5, pady=5)
        search_frame.columnconfigure(1, weight=1)

        search_icon_label = ttk.Label(search_frame, text="", font=("Font Awesome 6 Free Solid", 9))
        search_icon_label.grid(row=0, column=0, padx=(0, 5))

        search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        search_entry.grid(row=0, column=1, sticky="ew")
        ToolTip(search_entry).update_text("Ketik untuk mencari widget...")

        ttk.Label(self, text=self.loc.get('available_widgets_header')).grid(row=1, column=0, sticky='w', padx=5, pady=(5,0))

        self.widget_tree = tk_ttk.Treeview(self, show="tree", selectmode="browse")
        self.widget_tree.grid(row=2, column=0, sticky='nsew', padx=5, pady=5)

        self.widget_tree.bind("<Double-1>", self._on_widget_select)

    def _on_search(self, *args):
        """Memicu pembaruan daftar widget berdasarkan query pencarian."""
        self.populate_widget_toolbox()

    def populate_widget_toolbox(self):
        filter_text = self.search_var.get().lower()

        for item in self.widget_tree.get_children():
            self.widget_tree.delete(item)

        dashboard_manager = self.coordinator_tab.dashboard_manager
        if not dashboard_manager:
            return

        widgets_to_display = []
        for key, info in dashboard_manager.available_widgets.items():
            widget_title = info.get('title', key)
            if filter_text in widget_title.lower():
                widgets_to_display.append((key, widget_title))

        sorted_widgets = sorted(widgets_to_display, key=lambda item: item[1].lower())

        for key, title in sorted_widgets:
            self.widget_tree.insert("", "end", iid=key, text=title)

    def _on_widget_select(self, event):
        item_id = self.widget_tree.focus()
        if item_id:
            dashboard_manager = self.coordinator_tab.dashboard_manager
            if dashboard_manager:
                dashboard_manager.add_widget_and_save(item_id, event.x, event.y)

    def refresh_content(self):
        """Dipanggil oleh MainWindow untuk menyegarkan daftar widget jika ada perubahan."""
        self.populate_widget_toolbox()
####################################################################### DEV : AWENK AUDICO / SAHIDINAOLA@GMAIL.COM (AKHIR DARI KODE) ########################################################################################